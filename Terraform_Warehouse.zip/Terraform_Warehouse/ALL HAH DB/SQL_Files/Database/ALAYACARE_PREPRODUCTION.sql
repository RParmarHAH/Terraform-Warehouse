DATABASE_NAME = ALAYACARE_PREPRODUCTION
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = This data share points to the Alayacare UAT/Pre-production environment https://hahus.uat.alayacare.com/
