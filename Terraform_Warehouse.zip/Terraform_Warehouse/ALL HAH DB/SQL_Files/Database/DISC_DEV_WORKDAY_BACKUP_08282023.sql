DATABASE_NAME = DISC_DEV_WORKDAY_BACKUP_08282023
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = Created by : Abhishek Sunil
Created on : 08/28/2023 (After dev run - till int layer)
Can be deleted after 10/2 after creater's discretion

