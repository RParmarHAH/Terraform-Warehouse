DATABASE_NAME = DW_PROD_BACKUP_20230905
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = unadjusted auth logic change for matrixcare
