DATABASE_NAME = AWS_LANDING_INGEST_DB_PROD
IS_TRANSIENT = NO
RETENTION_TIME = 0
COMMENT = database to hold objects for landing S3 ingestions
