DATABASE_NAME = FINANCE_LOOKBACK_DATA
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = Create DB to store historical payrol and service data --jigar
