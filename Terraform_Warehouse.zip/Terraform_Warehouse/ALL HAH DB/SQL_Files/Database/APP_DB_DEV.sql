DATABASE_NAME = APP_DB_DEV
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = Development database for application development. Schemas built per app
