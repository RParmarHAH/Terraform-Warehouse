DATABASE_NAME = DW_PROD_BACKUP_20240201
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = HHA systems : Enhancing authorization for improved accuracy deployment plan - 20240201 --RSUTHAR/NJAGNADE
