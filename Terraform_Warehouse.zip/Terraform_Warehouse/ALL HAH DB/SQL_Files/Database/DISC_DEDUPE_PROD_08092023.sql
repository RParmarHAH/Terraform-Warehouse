DATABASE_NAME = DISC_DEDUPE_PROD_08092023
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = Backup before moving generic dedupe in prod -- Jigar Prajapati
