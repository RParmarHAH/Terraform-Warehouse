DATABASE_NAME = AWS_LANDING_INGEST_DB_DEV
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = database to hold objects for landing S3 ingestions
