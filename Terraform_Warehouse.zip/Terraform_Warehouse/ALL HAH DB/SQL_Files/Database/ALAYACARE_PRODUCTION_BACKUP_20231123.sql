DATABASE_NAME = ALAYACARE_PRODUCTION_BACKUP_20231123
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = This data share points to the Alayacare Production environment https://hahus.alayacare.com/
