DATABASE_NAME = DISC_DEDUPE_DEV
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = This database contains structures to support deduplication of DISC_Dev data sources
