DATABASE_NAME = ALAYACARE_UAT
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = This data share points to the Alayacare UAT/Sandbox environment https://hah-us.uat.alayacare.com/
