DATABASE_NAME = LOAD_ALAYACARE_DEV
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = Development database used for building structures to load AlayaCare
