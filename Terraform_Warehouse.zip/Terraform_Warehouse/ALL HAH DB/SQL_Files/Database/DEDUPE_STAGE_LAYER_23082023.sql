DATABASE_NAME = DEDUPE_STAGE_LAYER_23082023
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = take backup to comapare logic change for survival record -- Jigar Prajapati
