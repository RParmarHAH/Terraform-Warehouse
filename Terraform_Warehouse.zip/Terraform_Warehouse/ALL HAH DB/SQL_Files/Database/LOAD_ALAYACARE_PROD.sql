DATABASE_NAME = LOAD_ALAYACARE_PROD
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = Production database used for building structures to load AlayaCare
