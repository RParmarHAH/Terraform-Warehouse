DATABASE_NAME = FINANCE
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = created database to store lookback finace data for workday --jigar prajapati
