CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.GET_STAGE_CARE_COORDINATION_OBSERVATION_RESPONSE_ANSWER("STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  RETURN_RESULT VARCHAR(1000);
BEGIN
--****************************************************************************************************************************
-- NAME:  GET_STAGE_CARE_COORDINATION_OBSERVATION_RESPONSE_ANSWER
--
-- PURPOSE: Creates one row per observation response answer
--
-- DEVELOPMENT LOG:
-- DATE        AUTHOR                               NOTES:
-- --------    -------------------                  ---------------------------------------------------------------------------

-- 04/11/2022  Paras Bhavnani                       Initial Development
-- 19/06/2023  Meet Hariyani                        added join with table GATOR_OLD_EXTERNAID to keep ''_V3'' ids. 
-- 19/06/2023  Meet Hariyani                        added COALESCE IN external_id 
--*****************************************************************************************************************************

INSERT OVERWRITE INTO CARE_COORDINATION_STAGE.ObservationResponseAnswer 
SELECT DISTINCT COALESCE(QMC.QUESTION_ID, SURVEY_QUESTION_KEY)  QUESTION_ID, 
                ANSWER ANSWER_VALUE, 
                NULL ANSWER_SCORE, 
                COALESCE(GATOR.EXTERNAL_ID,DSRH.RECORD_ID||''-''||FSRD.QUESTION_ID) EXTERNAL_ID, 
                DSRH.RECORD_ID OBSERVATION_ID, 
                 :STR_ETL_TASK_KEY AS ETL_TASK_KEY,
                 :STR_ETL_TASK_KEY AS ETL_INSERTED_TASK_KEY,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_INSERTED_DATE,
                CURRENT_USER AS ETL_INSERTED_BY,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_LAST_UPDATED_DATE,
                CURRENT_USER AS ETL_LAST_UPDATED_BY,
                0 AS ETL_DELETED_FLAG,
                TRUE as NEWLY_CREATED_OR_UPDATED_FLAG
FROM DW_PROD.HAH.FACT_SURVEY_RESPONSE_DETAIL FSRD
JOIN DW_PROD.HAH.DIM_SURVEY_RESPONSE_HEADER DSRH ON FSRD.SURVEY_RESPONSE_HEADER_KEY=DSRH.SURVEY_RESPONSE_HEADER_KEY
LEFT JOIN DISC_PROD.QUALTRICS_SURVEYS.RESPONSES_W_QUESTION_MEANING_CHANGE QMC 
    ON QMC.EXTERNAL_ID = DSRH.RECORD_ID||''-''||FSRD.QUESTION_ID
LEFT JOIN DISC_PROD.QUALTRICS_SURVEYS.GATOR_OLD_EXTERNAL_ID GATOR 
    ON GATOR.RECORD_ID||''-''||GATOR.QUESTION_ID = DSRH.RECORD_ID||''-''||FSRD.SURVEY_QUESTION_KEY 
WHERE FSRD.SURVEY_ID IN (''SV_9R11KQoz9btyWto'',''SV_8rhFLN1ZJEdKRds'');
	SELECT CONCAT (''MESSAGE : '',"number of rows inserted",'' Rows Inserted.'') into :return_result FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
	RETURN return_result;
    END;
    ';