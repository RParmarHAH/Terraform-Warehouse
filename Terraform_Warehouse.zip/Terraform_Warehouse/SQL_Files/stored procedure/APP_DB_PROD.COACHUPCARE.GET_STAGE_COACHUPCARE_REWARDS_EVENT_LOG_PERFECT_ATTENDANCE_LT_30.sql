CREATE OR REPLACE PROCEDURE APP_DB_PROD.COACHUPCARE.GET_STAGE_COACHUPCARE_REWARDS_EVENT_LOG_PERFECT_ATTENDANCE_LT_30("REWARD_MASTER_KEY" VARCHAR(16777216), "STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216), "WEEK_START" DATE, "WEEK_END" DATE)
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    REWARD_MSTR_KEY NUMBER(38,0);
    REWARD_MSTR_NAME VARCHAR;
    MSTR_POINT NUMBER(38,0);
    MSTR_POINT_KEY NUMBER(38,0);
    THRESHOLD NUMERIC(5, 0);
BEGIN
--*****************************************************************************************************************************
-- NAME:  COACHUPCARE.GET_STAGE_COACHUPCARE_REWARDS_EVENT_LOG_PERFECT_ATTENDANCE_LT_30
--
-- PURPOSE: Procedure to insert new records in REWARDS_EVENT_LOG table
--
-- DEVELOPMENT LOG:
-- DATE        AUTHOR                               NOTES:
-- --------    -------------------                 ---------------------------------------------------------------------------
-- 06/06/2023   MOIN SAIYED / HARSHALA KADAM       	Initial development
--*****************************************************************************************************************************
    
    SELECT REWARD_MASTER_KEY, NAME INTO :REWARD_MSTR_KEY, :REWARD_MSTR_NAME
	FROM 
        APP_DB_PROD.COACHUPCARE.REWARDS_MASTER
    WHERE 
        CURRENT_DATE() BETWEEN ACTIVATED_DATE AND IFNULL(INACTIVATED_DATE, ''9999-12-31'') 
        AND DELETED_FLAG = FALSE
        AND REWARD_MASTER_KEY = :REWARD_MASTER_KEY;
    
    IF ( COALESCE(REWARD_MSTR_KEY, 0) <> 0 AND COALESCE(UPPER(REWARD_MSTR_NAME), '''') = ''PERFECT ATTENDANCE <30'' ) THEN
        
        SELECT POINTS_VALUE, REWARD_MASTER_KEY, THRESHOLD INTO :MSTR_POINT, :MSTR_POINT_KEY, :THRESHOLD
        FROM 
            APP_DB_PROD.COACHUPCARE.REWARDS_MASTER_POINTS
        WHERE 
            CURRENT_DATE() BETWEEN POINTS_ACTIVATED_DATE AND IFNULL(POINTS_INACTIVATED_DATE, ''9999-12-31'') 
            AND DELETED_FLAG = FALSE
            AND REWARD_MASTER_KEY = :REWARD_MASTER_KEY;
        
        -- START OF INNER IF
        
        IF (COALESCE(MSTR_POINT, 0) <> 0 AND COALESCE(MSTR_POINT_KEY, 0) <> 0) THEN
            
            -- INSERT STATEMENT 
            
             INSERT INTO APP_DB_PROD.COACHUPCARE.rewards_event_log
                            ( -- REWARDS_EVENT_LOG_KEY, 
                                REWARD_MASTER_KEY, REWARD_POINT_KEY, AMS_EMPLOYEE_KEY, BRANCH_KEY, POINTS_VALUE, AWARD_ARTIFACT, AWARD_ELIGIBLE_TIMESTAMP, AWARDED_TIMESTAMP, AWARDED_BY_PROCESS, FULLFILLED_BY_PROCESS, FULLFILLED_TIMESTAMP, ETL_TASK_KEY, ETL_INSERTED_TASK_KEY, ETL_INSERTED_DATE, ETL_INSERTED_BY, ETL_LAST_UPDATED_DATE, ETL_LAST_UPDATED_BY, ETL_DELETED_FLAG, EMPLOYEE_ENTERPRISE_ID
                            )
            WITH WEEKLY_METRICS AS  --LIST OF EMPLOYEES
             (
                SELECT
                    :WEEK_START AS SERVICE_WEEK,
                    VISIT.EMPLOYEE_KEY ,
                    NVL(SUM(iff(VISIT.CONFIRMED_FLAG = ''YES'',VISIT.HOURS_SERVED,0)),0) 
                        AS TOTAL_HOURS_SERVED,
                    COUNT(iff(VISIT.CONFIRMED_FLAG = ''YES'', VISIT.VISIT_KEY, NULL))   
                        AS TOTAL_VISITS_COMPLETED,
                    COUNT(iff(VISIT.CONFIRMED_FLAG IN (''NO'',''UNKNOWN'') 
                                AND (VISIT.SERVICE_DATE <= CURRENT_DATE() AND NVL(VISIT.SCHEDULE_STATUS_NAME,''0'') <> ''Hold'' AND VISIT.VISIT_STATUS_NAME IS NULL)
                                , VISIT.VISIT_KEY, NULL))   
                        AS TOTAL_VISITS_MISSED,
                    COUNT(iff(VISIT.CONFIRMED_FLAG IN (''NO'',''UNKNOWN'') 
                                AND VISIT.SERVICE_DATE <= CURRENT_DATE() AND (VISIT.VISIT_STATUS_NAME = ''Did not happen'' OR VISIT.SCHEDULE_STATUS_NAME in (''Hold'',''Cancelled''))
                                ,VISIT.VISIT_KEY, NULL))   
                        AS TOTAL_VISITS_CANCELLED
                FROM DW_PROD.INTEGRATION.FACT_VISIT_MERGED VISIT
                WHERE VISIT.SERVICE_DATE BETWEEN :WEEK_START AND :WEEK_END
                GROUP BY 1, 2
                HAVING 
                    TOTAL_HOURS_SERVED >= :THRESHOLD AND TOTAL_HOURS_SERVED < 30 
                    AND TOTAL_VISITS_MISSED = 0 AND TOTAL_VISITS_CANCELLED = 0
            )
            , REWARDS_LOG AS   -- REWARDED WHEN HOURS_SERVED ARE >=30
             (
                SELECT S.EMPLOYEE_KEY, E.EMPLOYEE_ENTERPRISE_ID,
                    E.AMS_EMPLOYEE_KEY, SERVICE_WEEK, TOTAL_HOURS_SERVED, TOTAL_VISITS_MISSED, TOTAL_VISITS_MISSED
                    , TOTAL_VISITS_COMPLETED
                    , E.BRANCH_KEY
                FROM WEEKLY_METRICS S
                INNER JOIN APP_DB_PROD.COACHUPCARE.employee_feed E 
                    ON E.AMS_EMPLOYEE_KEY = S.EMPLOYEE_KEY
                INNER JOIN APP_DB_PROD.COACHUPCARE.BRANCH_COACHUPCARE_INSTANCE_XREF BR
                    ON E.BRANCH_KEY = BR.BRANCH_KEY 
                        --AND BR.BRANCH_ACTIVE = TRUE
                        AND BR.BRANCH_KEY IN (
                            ''ff4c0932c622859cbe18c6db95838369'',
                            ''3b97d90e34288cdb4ce34c1f654f247c'',
                            ''34aed39aa52dbf9c10f77ed1eaac9d7b''
                        )
            )
            SELECT
                DISTINCT
            	:REWARD_MASTER_KEY REWARD_MASTER_KEY,
                :MSTR_POINT_KEY REWARD_POINT_KEY,
                R.AMS_EMPLOYEE_KEY AMS_EMPLOYEE_KEY,
                R.BRANCH_KEY BRANCH_KEY,
                :MSTR_POINT POINTS_VALUE,
                CONCAT(''Perfect Attendance'', ''--'', R.AMS_EMPLOYEE_KEY, ''--'', R.SERVICE_WEEK) AWARD_ARTIFACT,
                R.SERVICE_WEEK AWARD_ELIGIBLE_TIMESTAMP,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AWARDED_TIMESTAMP,
--                DATEADD(''HOURS'',22,CONVERT_TIMEZONE(''UTC'', CURRENT_DATE-1 )::TIMESTAMP_NTZ) 
--				CURRENT_TIMESTAMP AWARDED_TIMESTAMP,
                ''Pipeline_Coachupcare_Nightly_process'' AWARDED_BY_PROCESS,
                NULL FULLFILLED_BY_PROCESS,
                NULL FULLFILLED_TIMESTAMP,
                :STR_ETL_TASK_KEY ETL_TASK_KEY,
                :STR_ETL_TASK_KEY ETL_INSERTED_TASK_KEY,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_INSERTED_DATE,
                CURRENT_USER AS ETL_INSERTED_BY,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_LAST_UPDATED_DATE,
                CURRENT_USER AS ETL_LAST_UPDATED_BY,
                0 AS ETL_DELETED_FLAG,
                R.EMPLOYEE_ENTERPRISE_ID EMPLOYEE_ENTERPRISE_ID
            FROM
                REWARDS_LOG R
            WHERE AWARD_ARTIFACT NOT IN (
                        SELECT AWARD_ARTIFACT FROM APP_DB_PROD.COACHUPCARE.rewards_event_log
                    );
            
            -- END OF INSERT STATEMENT
            
            
            RETURN ''SUCCESS : '' || SQLROWCOUNT || '' rows inserted'';
        ELSE
            RETURN ''FAILED: NO ACTIVE REWARD POINT FOUND'';
        END IF;
        
        -- END OF INNER IF
        
    ELSE
        RETURN ''FAILED: NO ACTIVE REWARD FOUND ASSOCIATED WITH REWARD MASTER KEY ''|| REWARD_MASTER_KEY;
	END IF;
END;
';