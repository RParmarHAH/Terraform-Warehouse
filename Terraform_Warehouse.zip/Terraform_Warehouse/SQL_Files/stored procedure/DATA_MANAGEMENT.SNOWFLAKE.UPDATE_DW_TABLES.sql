CREATE OR REPLACE PROCEDURE DATA_MANAGEMENT.SNOWFLAKE.UPDATE_DW_TABLES()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
        var sql = `
    INSERT INTO Data_Management.Snowflake.DW_Tables
SELECT * FROM (
SELECT CAST( Table_Catalog AS VARCHAR(200)) AS DB,
       CAST( Table_Schema AS VARCHAR(200)) AS Schema,
       CAST( Table_Name AS VARCHAR(200)) AS Table_Name,
       ''''''%'' || UPPER( Table_Name) || ''%'''''' AS Table_Name_For_In,
       CAST( Table_Owner AS VARCHAR(200)) AS Owner,
       CASE WHEN Table_Type = ''BASE TABLE'' THEN ''Table''
            ELSE ''View''
       END AS Object_Type,
       Row_Count,
       Bytes,
       Created AS Table_Create_Date,
       Last_Altered AS Table_DDL_Change_Date,
       CAST( Comment  AS VARCHAR(5000)) AS Comment,
       CURRENT_DATE AS Last_Update_Date
FROM Data_Management.Information_Schema.Tables
UNION
SELECT CAST( Table_Catalog AS VARCHAR(200)) AS DB,
       CAST( Table_Schema AS VARCHAR(200)) AS Schema,
       CAST( Table_Name AS VARCHAR(200)) AS Table_Name,
       ''''''%'' || UPPER( Table_Name) || ''%'''''' AS Table_Name_For_In,
       CAST( Table_Owner AS VARCHAR(200)) AS Owner,
       CASE WHEN Table_Type = ''BASE TABLE'' THEN ''Table''
            ELSE ''View''
       END AS Object_Type,
       Row_Count,
       Bytes,
       Created AS Table_Create_Date,
       Last_Altered AS Table_DDL_Change_Date,
       CAST( Comment  AS VARCHAR(5000)) AS Comment,
       CURRENT_DATE AS Last_Update_Date
FROM Disc_Dev.Information_Schema.Tables
UNION
SELECT CAST( Table_Catalog AS VARCHAR(200)) AS DB,
       CAST( Table_Schema AS VARCHAR(200)) AS Schema,
       CAST( Table_Name AS VARCHAR(200)) AS Table_Name,
       ''''''%'' || UPPER( Table_Name) || ''%'''''' AS Table_Name_For_In,
       CAST( Table_Owner AS VARCHAR(200)) AS Owner,
       CASE WHEN Table_Type = ''BASE TABLE'' THEN ''Table''
            ELSE ''View''
       END AS Object_Type,
       Row_Count,
       Bytes,
       Created AS Table_Create_Date,
       Last_Altered AS Table_DDL_Change_Date,
       CAST( Comment  AS VARCHAR(5000)) AS Comment,
       CURRENT_DATE AS Last_Update_Date
FROM Disc_Prod.Information_Schema.Tables
UNION
SELECT CAST( Table_Catalog AS VARCHAR(200)) AS DB,
       CAST( Table_Schema AS VARCHAR(200)) AS Schema,
       CAST( Table_Name AS VARCHAR(200)) AS Table_Name,
       ''''''%'' || UPPER( Table_Name) || ''%'''''' AS Table_Name_For_In,
       CAST( Table_Owner AS VARCHAR(200)) AS Owner,
       CASE WHEN Table_Type = ''BASE TABLE'' THEN ''Table''
            ELSE ''View''
       END AS Object_Type,
       Row_Count,
       Bytes,
       Created AS Table_Create_Date,
       Last_Altered AS Table_DDL_Change_Date,
       CAST( Comment  AS VARCHAR(5000)) AS Comment,
       CURRENT_DATE AS Last_Update_Date
FROM DW_Dev.Information_Schema.Tables
UNION
SELECT CAST( Table_Catalog AS VARCHAR(200)) AS DB,
       CAST( Table_Schema AS VARCHAR(200)) AS Schema,
       CAST( Table_Name AS VARCHAR(200)) AS Table_Name,
       ''''''%'' || UPPER( Table_Name) || ''%'''''' AS Table_Name_For_In,
       CAST( Table_Owner AS VARCHAR(200)) AS Owner,
       CASE WHEN Table_Type = ''BASE TABLE'' THEN ''Table''
            ELSE ''View''
       END AS Object_Type,
       Row_Count,
       Bytes,
       Created AS Table_Create_Date,
       Last_Altered AS Table_DDL_Change_Date,
       CAST( Comment  AS VARCHAR(5000)) AS Comment,
       CURRENT_DATE AS Last_Update_Date
FROM DW_Prod.Information_Schema.Tables
UNION
SELECT CAST( Table_Catalog AS VARCHAR(200)) AS DB,
       CAST( Table_Schema AS VARCHAR(200)) AS Schema,
       CAST( Table_Name AS VARCHAR(200)) AS Table_Name,
       ''''''%'' || UPPER( Table_Name) || ''%'''''' AS Table_Name_For_In,
       CAST( Table_Owner AS VARCHAR(200)) AS Owner,
       CASE WHEN Table_Type = ''BASE TABLE'' THEN ''Table''
            ELSE ''View''
       END AS Object_Type,
       Row_Count,
       Bytes,
       Created AS Table_Create_Date,
       Last_Altered AS Table_DDL_Change_Date,
       CAST( Comment  AS VARCHAR(5000)) AS Comment,
       CURRENT_DATE AS Last_Update_Date
FROM DW_UAT.Information_Schema.Tables
UNION
SELECT CAST( Table_Catalog AS VARCHAR(200)) AS DB,
       CAST( Table_Schema AS VARCHAR(200)) AS Schema,
       CAST( Table_Name AS VARCHAR(200)) AS Table_Name,
       ''''''%'' || UPPER( Table_Name) || ''%'''''' AS Table_Name_For_In,
       CAST( Table_Owner AS VARCHAR(200)) AS Owner,
       CASE WHEN Table_Type = ''BASE TABLE'' THEN ''Table''
            ELSE ''View''
       END AS Object_Type,
       Row_Count,
       Bytes,
       Created AS Table_Create_Date,
       Last_Altered AS Table_DDL_Change_Date,
       CAST( Comment  AS VARCHAR(5000)) AS Comment,
       CURRENT_DATE AS Last_Update_Date
FROM ETL_Management_Dev.Information_Schema.Tables
UNION
SELECT CAST( Table_Catalog AS VARCHAR(200)) AS DB,
       CAST( Table_Schema AS VARCHAR(200)) AS Schema,
       CAST( Table_Name AS VARCHAR(200)) AS Table_Name,
       ''''''%'' || UPPER( Table_Name) || ''%'''''' AS Table_Name_For_In,
       CAST( Table_Owner AS VARCHAR(200)) AS Owner,
       CASE WHEN Table_Type = ''BASE TABLE'' THEN ''Table''
            ELSE ''View''
       END AS Object_Type,
       Row_Count,
       Bytes,
       Created AS Table_Create_Date,
       Last_Altered AS Table_DDL_Change_Date,
       CAST( Comment  AS VARCHAR(5000)) AS Comment,
       CURRENT_DATE AS Last_Update_Date
FROM ETL_Management_Prod.Information_Schema.TABLES ) ORDER BY DB,SCHEMA ,TABLE_NAME ;`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                return "Succeeded.";   // Return a success/error indicator.
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  
          ';