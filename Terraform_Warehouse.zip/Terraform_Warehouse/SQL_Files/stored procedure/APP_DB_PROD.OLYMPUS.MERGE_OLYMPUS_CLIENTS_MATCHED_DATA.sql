CREATE OR REPLACE PROCEDURE APP_DB_PROD.OLYMPUS.MERGE_OLYMPUS_CLIENTS_MATCHED_DATA()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
BEGIN      
    --*****************************************************************************************************************************
-- NAME:  GET_OLYMPUS_CLIENTS_MATCHED_DATA
--
-- PURPOSE: The only purpose is to avoid the error in pipeline
--
-- DELOPMENT LOG:
-- DATE        AUTHOR                               NOTES:
-- --------    -------------------                  ---------------------------------------------------------------------------
-- 30/06/2022  Paras Bhavnani       	 	        Initial Delopment
--*****************************************************************************************************************************
--
return ''Message : Succeed'';
END;
';