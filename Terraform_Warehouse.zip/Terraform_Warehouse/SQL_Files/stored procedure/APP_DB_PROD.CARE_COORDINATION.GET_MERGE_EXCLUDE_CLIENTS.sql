CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.GET_MERGE_EXCLUDE_CLIENTS()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
	RETURN_RESULT VARCHAR(5000);
BEGIN

MERGE INTO APP_DB_PROD.CARE_COORDINATION.EXCLUDE_CLIENTS as target
USING (SELECT DISTINCT source.Client_Key, source.Source_System_ID, 
source.System_Code, 
''Dataflex'' AS Source_System_Name, source.System_Code AS State, 
cl.Primary_Branch_Key AS Branch_Key, br.Branch_Name AS Branch_Name, 
cl.Client_First_Name AS First_Name, cl.Client_Last_Name AS Last_Name, 
1,2 AS RULE_ID
    ,-1 AS ETL_TASK_KEY
    ,-1 AS ETL_INSERTED_TASK_KEY
    ,convert_timezone(''UTC'', CURRENT_TIMESTAMP)::timestamp_ntz as ETL_INSERTED_DATE
    ,CURRENT_USER as ETL_INSERTED_BY 
    ,convert_timezone(''UTC'', CURRENT_TIMESTAMP)::timestamp_ntz as ETL_LAST_UPDATED_DATE
    ,CURRENT_USER as ETL_LAST_UPDATED_BY
    ,0 as ETL_DELETED_FLAG
    ,0 AS ETL_INFERRED_MEMBER_FLAG
FROM DW_PROD.INTEGRATION.FACT_VISIT_MERGED AS source
INNER JOIN DW_PROD.Integration.DIM_Client_Merged AS cl ON
source.Client_Key = cl.Client_Key
LEFT OUTER JOIN DW_PROD.Integration.DIM_Branch_Merged AS br 
ON cl.Primary_Branch_Key = br.Branch_Key
WHERE Contract_Key IN (''f0123dafbc24c2ced3d43c649221e00a''
,''d10407bbf712416b370623ba35b04ebc'',''abed9b49dbcf3c85b60f9e67115d7beb''
,''0032920e806119ae09bc52377726bc5d'')
-- 92,825 Clients served under these four contracts all time
AND Service_Date >= CAST( ''2022-01-01'' AS DATE)
--27,960 Clients served under these four contracts in this time period
) source
ON target.Client_Key=source.Client_Key
WHEN MATCHED and 
            (target.Source_System_ID<>source.Source_System_ID or 
            target.System_Code <> source.System_Code or 
            target.Source_System_Name <> source.Source_System_Name or 
            target.State <> source.State or 
            target.Branch_Key <> source.Branch_Key or 
            target.Branch_Name <> source.Branch_Name or 
            target.Client_First_Name <> source.First_Name or 
            target.Client_Last_Name <> source.Last_Name)
THEN UPDATE SET 
    target.Client_Key = source.Client_Key,
    target.Source_System_ID = source.Source_System_ID,
    target.System_Code = source.System_Code,
    target.Source_System_Name = source.Source_System_Name,
    target.State = source.State,
    target.Branch_Key = source.Branch_Key,
    target.Branch_Name = source.Branch_Name,
    target.Client_First_Name = source.First_Name,
    target.Client_Last_Name = source.Last_Name,
    target.Rule_ID = source.Rule_ID,
    target.ETL_TASK_KEY=source.ETL_TASK_KEY,
    target.ETL_INSERTED_TASK_KEY=source.ETL_INSERTED_TASK_KEY,
    target.ETL_INSERTED_DATE=source.ETL_INSERTED_DATE,
    target.ETL_INSERTED_BY=source.ETL_INSERTED_BY,
    target.ETL_LAST_UPDATED_DATE=source.ETL_LAST_UPDATED_DATE,
    target.ETL_LAST_UPDATED_BY=source.ETL_LAST_UPDATED_BY,
    target.ETL_DELETED_FLAG=source.ETL_DELETED_FLAG,
    target.ETL_INFERRED_MEMBER_FLAG=source.ETL_INFERRED_MEMBER_FLAG,
    target.IS_UPDATED=1
WHEN NOT MATCHED
THEN INSERT (
    Client_Key, Source_System_ID,
    System_Code, Source_System_Name, State, Branch_Key, Branch_Name, 
    Client_First_Name, Client_Last_Name, Rule_ID,ETL_TASK_KEY
   ,ETL_INSERTED_TASK_KEY
   ,ETL_INSERTED_DATE
   ,ETL_INSERTED_BY
   ,ETL_LAST_UPDATED_DATE
   ,ETL_LAST_UPDATED_BY
   ,ETL_DELETED_FLAG
   ,ETL_INFERRED_MEMBER_FLAG
   ,IS_UPDATED
)
    VALUES (source.Client_Key, source.Source_System_ID, source.System_Code,
    source.Source_System_Name,source.State,source.Branch_Key,
    source.Branch_Name,
    source.First_Name, source.Last_Name, source.Rule_ID,
    source.ETL_TASK_KEY,
    source.ETL_INSERTED_TASK_KEY,
    source.ETL_INSERTED_DATE,
    source.ETL_INSERTED_BY,
    source.ETL_LAST_UPDATED_DATE,
    source.ETL_LAST_UPDATED_BY,
    source.ETL_DELETED_FLAG,
    source.ETL_INFERRED_MEMBER_FLAG,
    0
);

SELECT CONCAT(''Message >> Inserted : '',"number of rows inserted", '', Updated : '' ,"number of rows updated",'' Rows.'') into :return_result FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
return return_result;

END
';