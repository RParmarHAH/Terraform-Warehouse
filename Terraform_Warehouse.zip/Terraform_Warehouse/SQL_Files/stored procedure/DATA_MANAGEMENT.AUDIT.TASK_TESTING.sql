CREATE OR REPLACE PROCEDURE DATA_MANAGEMENT.AUDIT.TASK_TESTING()
RETURNS VARCHAR(100)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
BEGIN
	--created by rsuthar just for testing
	ALTER TASK data_management.audit.testing SUSPEND;
	ALTER TASK data_management.audit.testing SET schedule=''using cron 15 21 * * * UTC'';
	ALTER TASK data_management.audit.testing Resume;
END;
';