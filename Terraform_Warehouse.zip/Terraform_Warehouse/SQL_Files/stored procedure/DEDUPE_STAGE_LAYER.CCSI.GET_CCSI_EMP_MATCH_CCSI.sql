CREATE OR REPLACE PROCEDURE DEDUPE_STAGE_LAYER.CCSI.GET_CCSI_EMP_MATCH_CCSI("STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
        var sql = `
INSERT OVERWRITE INTO DISC_DEDUPE_PROD.CCSI.EMP_MATCH_CCSI
with dedupe_record_ids as 
(
select record_id,cluster_id,filename
from DISC_DEDUPE_PROD.CCSI.CCSI_EMP_DEDUPE_SOURCE
where cluster_id in (select cluster_id
from DISC_DEDUPE_PROD.CCSI.CCSI_EMP_DEDUPE_SOURCE
group by cluster_id
having count(cluster_id)>1
)
),
emp_Master as
(
select record_id,cluster_id,filename,ccsi_emp.UPDATED_DATE,
(ccsi_emp.RECORD_NUMBER::STRING || ''-'' || NVL(ccsi_emp.AREA,''C'')::STRING || ''-'' || ''CCSI'') MASTER_ID,
row_number() over(partition by dedupe.cluster_id order by to_date(ccsi_emp.UPDATED_DATE,''mm/dd/yy'') desc, 
																	  to_date(CREATED_DATE,''mm/dd/yy'') desc, 
																	  TRY_CAST(RECORD_NUMBER AS int) desc) Max_record_id
from DISC_DEDUPE_PROD.CCSI.CCSI_EMP_DEDUPE_SOURCE dedupe
INNER JOIN DISC_PROD.CCSI.employee1 ccsi_emp on
dedupe.record_id = ccsi_emp.RECORD_NUMBER||ccsi_emp.AREA
)
select dedupe.record_id original_record_id  --(can keep it short as org_record_id, we can decide the naming terminology)
		,M.MASTER_ID --(can be named as MASTER_KEY, MASTER_RECORD_ID etc)
        ,dedupe.cluster_id
        ,row_number() over(partition by dedupe.cluster_id order by to_date(ccsi_emp.UPDATED_DATE,''mm/dd/yy'') desc, 
																	  to_date(CREATED_DATE,''mm/dd/yy'') desc, 
																	  TRY_CAST(RECORD_NUMBER AS int) desc) record_order
		,ccsi_emp.RECORD_NUMBER
        ,ccsi_emp.AREA
        ,ccsi_emp.EMPLOYEE_NUMBER
		,nvl(ccsi_emp.HIRE_DATE,''19000101'') HIRE_DATE
		,nvl(ccsi_emp.TERMINATION_DATE,''20991231'') TERMINATION_DATE
        ,ccsi_emp.UPDATED_DATE
		,ccsi_emp.CREATED_DATE
        ,ccsi_emp.SS
        ,ccsi_emp.EMPLOYEE_NAME
        ,ccsi_emp.DATE_OF_BIRTH
        ,ccsi_emp.ADDRESS
		,ccsi_emp.STATE
		,ccsi_emp.ZIPCODE
		,ccsi_emp.INACTIVE_FIELD
		,ccsi_emp.ETL_LAST_UPDATED_DATE
		,case when len(ccsi_emp.EMPLOYEE_NUMBER)>4 then substring(ccsi_emp.EMPLOYEE_NUMBER,2) else ccsi_emp.EMPLOYEE_NUMBER end DIM_EMPLOYEE_NUMBER
		,UPPER(TRIM(REGEXP_REPLACE(ccsi_emp.EMPLOYEE_NAME, ''[d{0}d{1}d{2}d{3}d{4}d{5}d{6}d{7}d{8}d{9}]'', ''''))) DIM_EMPLOYEE_NAME
      from DISC_DEDUPE_PROD.CCSI.CCSI_EMP_DEDUPE_SOURCE dedupe
      inner join DISC_PROD.CCSI.employee1 ccsi_emp on
            dedupe.record_id = ccsi_emp.RECORD_NUMBER||ccsi_emp.AREA
      inner join dedupe_record_ids matches on
            matches.filename = dedupe.filename
            and matches.record_id = dedupe.record_id
            and matches.cluster_id = dedupe.cluster_id
      inner join emp_Master M on 
            M.cluster_id=matches.cluster_id
            and Max_record_id=1 
;`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                return "Succeeded.";   // Return a success/error indicator.
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  
          ';