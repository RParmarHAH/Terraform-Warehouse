CREATE OR REPLACE PROCEDURE DATA_MANAGEMENT.SNOWFLAKE.ABORT_SESSION()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '  
    var my_sql_command1 = "SELECT system$abort_session( 144177762833590 );";
    var statement1 = snowflake.createStatement( {sqlText: my_sql_command1} );
    var result_set1 = statement1.execute();
  return "Complete"; // Replace with something more useful.
  ';