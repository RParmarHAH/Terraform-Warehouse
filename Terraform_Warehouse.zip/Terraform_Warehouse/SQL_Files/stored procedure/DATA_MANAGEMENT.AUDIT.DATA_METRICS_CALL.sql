CREATE OR REPLACE PROCEDURE DATA_MANAGEMENT.AUDIT.DATA_METRICS_CALL("CON_ID" VARCHAR(16777216))
RETURNS TABLE ("BRANCH_ID" NUMBER(38,0), "MAX_VISIT_DATE" TIMESTAMP_NTZ(9))
LANGUAGE SQL
EXECUTE AS OWNER
AS '
declare
    CNT varchar;
    tloc varchar;
    res resultset;
BEGIN
    SELECT QUERY into :tloc FROM DATA_MANAGEMENT.AUDIT.VW_OB_DATA_METRICS WHERE OBJECT_key=:con_id;
    res:=(execute immediate tloc);
    return table(res);
end;
';