CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.SP_CC_GET_CARE_PROGRAM_CLIENTS("CARE_PROGRAM_ID" VARCHAR(16777216), "MAXROWSRETURNED" VARCHAR(16777216), "ENVIRONMENT" VARCHAR(16777216), "MARKASPROCESSED" VARCHAR(16777216))
RETURNS VARIANT
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

      const ROWS_LOWER_LIMIT = 1;
      const ROWS_UPPER_LIMIT = 65000;
	  const CARE_PROGRAM_IDS = [''HCPIL'',''PAHW'', ''HMIN'',''OHMPA'',''OHMIN'',''OSHIL'',''HMPACE'',''HMILMO'',''ALL''];
	  const COL_NAMES = [''care_program_id'',''client_key'',''last_name''];
	  var VALID_CARE_PROGRAM_ID = ''FALSE''
	  
	  for (var i = 0; i < CARE_PROGRAM_IDS.length; i++) {
          if (CARE_PROGRAM_ID == CARE_PROGRAM_IDS[i]) {
		     VALID_CARE_PROGRAM_ID = ''TRUE'';
			 break;
			 }
      }
      
if (MAXROWSRETURNED == '''')  MAXROWSRETURNED =  ROWS_UPPER_LIMIT;
if ((VALID_CARE_PROGRAM_ID == ''TRUE'') &&
    (MAXROWSRETURNED >= ROWS_LOWER_LIMIT ) &&  
    (MAXROWSRETURNED <= ROWS_UPPER_LIMIT) &&
    (ENVIRONMENT == ''DEV'' || ENVIRONMENT == ''PROD'') &&
    (MARKASPROCESSED == ''TRUE'' || MARKASPROCESSED == ''FALSE'')
   )
{ 
      var DB_NAME = ''APP_DB_DEV''
      var DW_NAME = ''DW_DEV''
      if (ENVIRONMENT == ''PROD'') { 
      DB_NAME = "APP_DB_PROD";
      DW_NAME = "DW_PROD";
      }
	  var row_as_json = {};   //hold a JSON data structure that holds ONE row
      var array_of_rows = []; //hold all the rows
      var table_as_json = {}; //hold a JSON data structure that we can return as a VARIANT (all rows in a single "value")
      
      var row_num = 1;
      var col_name = "";
      var col_value = ""; 

//HCPIL - HCP IL OSH
      if ((CARE_PROGRAM_ID == ''HCPIL'') || (CARE_PROGRAM_ID == ''ALL'')) {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " ''HCPIL'', " + "CLIENT_KEY, CLIENT_LAST_NAME FROM " + DB_NAME 
          + ".olympus.OLYMPUS_CLIENT_CAREGIVER_RELATIONSHIP " 
          + "where file_received_date = (select max(file_received_date) from " + DB_NAME 
		  + ".olympus.OLYMPUS_CLIENT_CAREGIVER_RELATIONSHIP) and olympus_zipcode in " 
          + "(''60617'', ''60628'', ''60649'', ''60621'', ''60620'', ''60616'', ''60653'', ''60633'', ''60627'', ''60619'', ''60643'', ''60637'', ''60655'', ''60636'')"
		  dbSelect();
      }
      
//PAHW - HCP PA Centene
      if ((CARE_PROGRAM_ID == ''PAHW'') || (CARE_PROGRAM_ID == ''ALL'')) {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " ''PAHW'', " + "CLIENT_KEY, LAST_NAME FROM " + DB_NAME 
          + ".CARE_COORDINATION.CLIENT " 
          + "where CONTRACT in (''PAHW'',''PAHW;HMPACE'')" 
		  dbSelect();
      }
      
//HMIN - HM IN HAH
      if ((CARE_PROGRAM_ID == ''HMIN'') || (CARE_PROGRAM_ID == ''ALL'')) {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " ''HMIN'', " + "CLIENT_KEY, LAST_NAME FROM " + DB_NAME 
          + ".CARE_COORDINATION.CLIENT " 
          + "where branch_key in (''3b97d90e34288cdb4ce34c1f654f247c'',''ff4c0932c622859cbe18c6db95838369'',''34aed39aa52dbf9c10f77ed1eaac9d7b'')" 
		  dbSelect();
          // H_GREENWOOD, H_INDY AVON, H_INDIANAPOLIS EAST
      }
      
//OHMPA - HM PA Pilot
      if ((CARE_PROGRAM_ID == ''OHMPA'') || (CARE_PROGRAM_ID == ''ALL'')) {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " ''OHMPA'', " + "a.CLIENT_KEY, b.CLIENT_LAST_NAME FROM " + DB_NAME 
          + ".CARE_COORDINATION.CLIENT_LIST_50 a, " + DW_NAME  
          + ".HAH.DIM_CLIENT b "
          + "where a.client_key = b.client_key "
          + "and b.client_state_code = ''PA''"
		  dbSelect();  
      }
      
 //OHMIN - HM IN Pilot
      if ((CARE_PROGRAM_ID == ''OHMIN'') || (CARE_PROGRAM_ID == ''ALL'')) {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " ''OHMIN'', " + "a.CLIENT_KEY, b.CLIENT_LAST_NAME FROM " + DB_NAME 
          + ".CARE_COORDINATION.CLIENT_LIST_50 a, " + DW_NAME  
          + ".HAH.DIM_CLIENT b "
          + "where a.client_key = b.client_key "
          + "and b.client_state_code = ''IN''"
		  dbSelect();  
      }     
           
//OSHIL    
       if ((CARE_PROGRAM_ID == ''OSHIL'') || (CARE_PROGRAM_ID == ''ALL'')) {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " ''OSHIL'', " + "CLIENT_KEY, CLIENT_LAST_NAME FROM " + DB_NAME 
          + ".olympus.OLYMPUS_CLIENT_CAREGIVER_RELATIONSHIP " 
          + "where file_received_date = (select max(file_received_date) from " + DB_NAME 
		  + ".olympus.OLYMPUS_CLIENT_CAREGIVER_RELATIONSHIP)" 
		  dbSelect();        
      }  

//HMPACE - HM PA Centene 
      if ((CARE_PROGRAM_ID == ''HMPACE'') || (CARE_PROGRAM_ID == ''ALL'')) {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " ''HMPACE'', " + "CLIENT_KEY, LAST_NAME FROM " + DB_NAME 
          + ".CARE_COORDINATION.CLIENT " 
          + "where CONTRACT in (''PAHW;HMPACE'')" 
		  dbSelect();
      }
	  
//HMILMO - HM IL Molina
      if ((CARE_PROGRAM_ID == ''HMILMO'') || (CARE_PROGRAM_ID == ''ALL'')) {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " ''HMILMO'', " + "CLIENT_KEY, LAST_NAME FROM " + DB_NAME 
          + ".CARE_COORDINATION.CLIENT " 
          + "where CONTRACT in (''HMILMO'')" 
		  dbSelect();
      }
          
      // Put the array in a JSON variable (so it looks like a VARIANT to
      // Snowflake).  The key is "CARE_PROGRAM_DATA", and the value is the array containing the rows
      table_as_json = { "CARE_PROGRAM_DATA" : array_of_rows };
      
      return table_as_json;  //return rows to Snowflake, which expects a JSON-compatible VARIANT
}
   else
{
   return "Failed: Parameter formatting error. call APP_DB_DEV.CARE_COORDINATION.SP_CC_GET_CARE_PROGRAM_CLIENTS(''ALL'','''',''DEV'',''TRUE'')" +
      " where Parm1: CLIENT || CAREGIVER" +
       " Parm2: integer between " + ROWS_LOWER_LIMIT + " and " + ROWS_UPPER_LIMIT + " or '''', which will default to " + ROWS_UPPER_LIMIT + " " +
        " Parm3: ''DEV'' || ''PROD''" +
         " Parm4: ''TRUE'' || ''FALSE''" +
          " Example: call APP_DB_DEV.CARE_COORDINATION.SP_CC_GET_CARE_PROGRAM_CLIENTS(''ALL'','''',''DEV'',''TRUE'')"
}

function dbSelect(){       
  try {
        var cmd1_dict = {sqlText: command};
        var stmt = snowflake.createStatement(cmd1_dict);
        var rs = stmt.execute();
              
        while (rs.next())  {  
        row_as_json = {};
        
        // For each column in the row...
        for (var col_num = 0; col_num < COL_NAMES.length; col_num++) {
          col_name = COL_NAMES[col_num];
          col_value = rs.getColumnValue(col_num + 1);
          row_as_json[col_name] = col_value
          }  

        // Add the row to the array of rows.
        array_of_rows.push(row_as_json);
        ++row_num;
        }
          }
      catch (err)  {
              return "Failed: Select unsuccessful.  Command = " + command
          } 
}
';