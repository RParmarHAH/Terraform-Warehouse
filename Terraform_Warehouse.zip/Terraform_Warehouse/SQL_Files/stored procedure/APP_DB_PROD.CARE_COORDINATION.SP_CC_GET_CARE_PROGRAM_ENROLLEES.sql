CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.SP_CC_GET_CARE_PROGRAM_ENROLLEES("CARE_PROGRAM_ID" VARCHAR(16777216), "MAXROWSRETURNED" VARCHAR(16777216), "ENVIRONMENT" VARCHAR(16777216), "MARKASPROCESSED" VARCHAR(16777216))
RETURNS VARIANT
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

      const ROWS_LOWER_LIMIT = 1;
      const ROWS_UPPER_LIMIT = 65000;
	  const CARE_PROGRAM_IDS = [''PAHW'', ''HMIN'',''OHMPA'',''OHMIN'',''HMPAAC'',''HMPACE'',''HMILMO'',''ALL''];
	  const COL_NAMES = [''program_code'',''client_key'',''last_name'',''met_roster_criteria'',''met_geography_criteria'',''met_care_active_criteria'',''status''];
      const SCHEMA_NAME = "CARE_COORDINATION";
	  var VALID_CARE_PROGRAM_ID = ''FALSE''
	  
	  for (var i = 0; i < CARE_PROGRAM_IDS.length; i++) {
          if (CARE_PROGRAM_ID == CARE_PROGRAM_IDS[i]) {
		     VALID_CARE_PROGRAM_ID = ''TRUE'';
			 break;
			 }
      }
      
if (MAXROWSRETURNED == '''')  MAXROWSRETURNED =  ROWS_UPPER_LIMIT;
if ((VALID_CARE_PROGRAM_ID == ''TRUE'') &&
    (MAXROWSRETURNED >= ROWS_LOWER_LIMIT ) &&  
    (MAXROWSRETURNED <= ROWS_UPPER_LIMIT) &&
    (ENVIRONMENT == ''DEV'' || ENVIRONMENT == ''PROD'') &&
    (MARKASPROCESSED == ''TRUE'' || MARKASPROCESSED == ''FALSE'')
   )
{ 
      var DB_NAME = ''APP_DB_DEV''
      var DW_NAME = ''DW_DEV''
      if (ENVIRONMENT == ''PROD'') { 
      DB_NAME = "APP_DB_PROD";
      DW_NAME = "DW_PROD";
      }
	  var row_as_json = {};   //hold a JSON data structure that holds ONE row
      var array_of_rows = []; //hold all the rows
      var table_as_json = {}; //hold a JSON data structure that we can return as a VARIANT (all rows in a single "value")
      
      var UPDATE_VALUES = [];
      var row_num = 1;
      var col_name = "";
      var col_value = ""; 

      if (CARE_PROGRAM_ID == ''ALL'') {
      	  command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " PROGRAM_CODE, CLIENT_KEY, CLIENT_LAST_NAME, MET_ROSTER_CRITERIA, MET_GEOGRAPHY_CRITERIA, MET_CARE_ACTIVE_CRITERIA, STATUS FROM " + DB_NAME + "." + SCHEMA_NAME 
          + ".CLIENT_PROGRAM_MEMBERSHIP_STATUS " 
          + "where newly_created_or_updated_flag = ''TRUE'' order by PROGRAM_CODE"
      }
      else
      {
          command = "SELECT DISTINCT TOP " + MAXROWSRETURNED + " PROGRAM_CODE, CLIENT_KEY, CLIENT_LAST_NAME, MET_ROSTER_CRITERIA, MET_GEOGRAPHY_CRITERIA, MET_CARE_ACTIVE_CRITERIA, STATUS FROM " + DB_NAME + "." + SCHEMA_NAME
          + ".CLIENT_PROGRAM_MEMBERSHIP_STATUS " 
          + "where newly_created_or_updated_flag = ''TRUE'' and program_code = ''" + CARE_PROGRAM_ID +"''"
      }
      
   try {
        var cmd1_dict = {sqlText: command};
        var stmt = snowflake.createStatement(cmd1_dict);
        var rs = stmt.execute();
        var found = ''FALSE''
  
        while (rs.next())  {  
        row_as_json = {};
        
        
        // For each column in the row...
        for (var col_num = 0; col_num < COL_NAMES.length; col_num++) {
          col_name = COL_NAMES[col_num];
          col_value = rs.getColumnValue(col_num + 1);

          row_as_json[col_name] = col_value
          
           //while we''re here, collect IN clause values for update (if applicable). 
           //depending upon the table, the col_name targeted will differ

           if (col_name == ''program_code'') {
              UPDATE_VALUES[row_num] = col_value;
              }
              
           if (col_name == ''client_key'') {
             UPDATE_VALUES[row_num] += "|" + col_value;
             }
         }
        // Add the row to the array of rows.
        array_of_rows.push(row_as_json);
        ++row_num;
        }
      }
      catch (err)  {
              return "Failed: Select unsuccessful.  Command = " + command + " / " + err;
          } 

      // Put the array in a JSON variable (so it looks like a VARIANT to
      // Snowflake).  The key is "CARE_PROGRAM_DATA", and the value is the array containing the rows
      table_as_json = { "CARE_PROGRAM_DATA" : array_of_rows };
      var all_update_command = "";
      //update the rows selected as having been processed (if desired)
      if (MARKASPROCESSED == ''TRUE'' && UPDATE_VALUES.length > 0)
      { 
          var i=1;
          while (i<UPDATE_VALUES.length)
          {
             curr_values = UPDATE_VALUES[i].split("|");
             hold_program_code = curr_values[0];

             update_command = "UPDATE " + DB_NAME + "." + SCHEMA_NAME + ".CLIENT_PROGRAM_MEMBERSHIP_STATUS SET newly_created_or_updated_flag = ''FALSE'' where program_code = ''" + curr_values[0] + "'' and client_key in (''" + curr_values[1] + "''"; 
             same_program_codes = ''TRUE'';            
                         
             while (same_program_codes == ''TRUE'' && i<UPDATE_VALUES.length)
             {   
                  i++;
                  if (i<UPDATE_VALUES.length)
                  { 
                    curr_values = UPDATE_VALUES[i].split("|");                   
                    if (hold_program_code == curr_values[0])
                    {
                       same_program_codes = ''TRUE'';
                       update_command += ", ''" + curr_values[1] + "''";
                    }
                    else 
                    {
                       same_program_codes = ''FALSE'';
                       hold_program_code = curr_values[0];
                       update_command += ") ";
                       all_update_command += update_command;
                       try
                       {
                             snowflake.execute ({sqlText: "begin transaction;"});
                             snowflake.execute ({sqlText: update_command});
                             snowflake.execute ({sqlText: "commit;"});
                       }
                       catch (err)  
                       {
                              return "Failed: Update unsuccessful.  Command = " + update_command;
                       }
                    }
                  }
                  else
                  {
                    update_command += ") ";
                    same_program_codes = ''FALSE'';
                    all_update_command += update_command;
                    try
                       {
                             snowflake.execute ({sqlText: "begin transaction;"});
                             snowflake.execute ({sqlText: update_command});
                             snowflake.execute ({sqlText: "commit;"});
                       }
                       catch (err)  
                       {
                              return "Failed: Update unsuccessful.  Command = " + update_command;
                       }
                  }
             }
         }
      }
      return table_as_json;  //return rows to Snowflake, which expects a JSON-compatible VARIANT
}
   else
{
   return "Failed: Parameter formatting error. APP_DB_DEV.CARE_COORDINATION.SP_CC_GET_CARE_PROGRAM_ENROLLEES(''Parm1'', ''Parm2'', ''Parm3'', ''Parm4'')" +
       " where Parm1: ''ALL'' or a valid, single quoted program code" +
       " Parm2: single quoted integer between " + ROWS_LOWER_LIMIT + " and " + ROWS_UPPER_LIMIT + " or '''' to signify no limit"
        " Parm3: DEV || PROD" +
         " Parm4: TRUE || FALSE" +
          " Example: call APP_DB_DEV.CARE_COORDINATION.SP_CC_GET_CARE_PROGRAM_ENROLLEES(''ALL'',''200'',''DEV'',''TRUE'');"
}
';