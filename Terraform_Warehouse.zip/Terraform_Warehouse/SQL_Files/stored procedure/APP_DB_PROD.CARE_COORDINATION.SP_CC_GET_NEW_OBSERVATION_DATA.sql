CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.SP_CC_GET_NEW_OBSERVATION_DATA("TYPE" VARCHAR(16777216), "MAXROWSRETURNED" VARCHAR(16777216), "ENVIRONMENT" VARCHAR(16777216), "MARKASPROCESSED" VARCHAR(16777216))
RETURNS VARIANT
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
      const ROWS_LOWER_LIMIT = 1;
      const ROWS_UPPER_LIMIT = 2000;
      const SCHEMA_NAME = "CARE_COORDINATION";
if ((TYPE == ''QUESTIONS'' || TYPE == ''RESPONSES'' || TYPE == ''ANSWERS'') &&
    (MAXROWSRETURNED >= ROWS_LOWER_LIMIT ) &&  
    (MAXROWSRETURNED <= ROWS_UPPER_LIMIT) &&
    (ENVIRONMENT == ''DEV'' || ENVIRONMENT == ''PROD'') &&
    (MARKASPROCESSED == ''TRUE'' || MARKASPROCESSED == ''FALSE'')
   )
{ 
      var DB_NAME = ''APP_DB_DEV''
      if (ENVIRONMENT == ''PROD'') DB_NAME = "APP_DB_PROD";
      var TABLE_NAME = '''';
      var COL_NAMES = new Array;
      switch (TYPE) {
        case ''QUESTIONS'': 
           TABLE_NAME = "OBSERVATIONQUESTIONCATALOG";
           COL_NAMES[0] = "question_id";
           COL_NAMES[1] = "question_text";
           COL_NAMES[2] = "question_category";
           COL_NAMES[3] = "is_active";
           COL_NAMES[4] = "source_question_id";
          break; 
        case ''RESPONSES'': 
           TABLE_NAME = "OBSERVATIONRESPONSE";
           COL_NAMES[0] = "observation_id";
           COL_NAMES[1] = "observation_version";
           COL_NAMES[2] = "external_id";
           COL_NAMES[3] = "client";
           COL_NAMES[4] = "date_recorded";
           COL_NAMES[5] = "start_date";
           COL_NAMES[6] = "end_date";
           COL_NAMES[7] = "duration";
           COL_NAMES[8] = "language";
           COL_NAMES[9] = "latitude";
           COL_NAMES[10] = "longitude";
           COL_NAMES[11] = "employee";
           COL_NAMES[12] = "survey_id";
           COL_NAMES[13] = "program_id";
           COL_NAMES[14] = "completed";
          break;  
        case ''ANSWERS'': 
           TABLE_NAME = "OBSERVATIONRESPONSEANSWER";
           COL_NAMES[0] = "question_id";
           COL_NAMES[1] = "answer_value";
           COL_NAMES[2] = "answer_score";
           COL_NAMES[3] = "external_id";
           COL_NAMES[4] = "observation_id";
          break;
      }

      var row_as_json = {};   //hold a JSON data structure that holds ONE row
      var array_of_rows = []; //hold all the rows
      var table_as_json = {}; //hold a JSON data structure that we can return as a VARIANT (all rows in a single "value")
      
      // construct the SELECT command
      var command = "SELECT TOP " + MAXROWSRETURNED + " "
      command += COL_NAMES[0]
      for (var col_num = 1; col_num < COL_NAMES.length; col_num++) {
          command += ", "
          command += COL_NAMES[col_num];
          }
          command += " FROM " + DB_NAME + "." + SCHEMA_NAME + "." + TABLE_NAME +  " WHERE "; 
          if (TYPE == ''RESPONSES'') { command += "observation_id in (select distinct observation_id from " + DB_NAME + "." + SCHEMA_NAME + ".OBSERVATIONRESPONSEANSWER) and ";}
          command += "NEWLY_CREATED_OR_UPDATED_FLAG = ''TRUE'';"
        
      try {
              var cmd1_dict = {sqlText: command};
              var stmt = snowflake.createStatement(cmd1_dict);
              var rs = stmt.execute();
          }
      catch (err)  {
              return "Failed: Select unsuccessful.  Command = " + command
          }
      
      var IN_CLAUSE_VALUES = new Array;  //hold all key values that will be used for batch update, as applicable
      var row_num = 1;
      var col_name = "";
      var col_value = "";
      
      // add values to the array to be returned
      while (rs.next())  {  
        row_as_json = {};
        
        // For each column in the row...
        for (var col_num = 0; col_num < COL_NAMES.length; col_num++) {
          col_name = COL_NAMES[col_num];
          col_value = rs.getColumnValue(col_num + 1);
          row_as_json[col_name] = col_value
          
          //while we''re here, collect IN clause values for update (if applicable). 
          //depending upon the table, the col_name targeted will differ
          switch (TYPE) {
          case ''QUESTIONS'': 
            if (col_name == ''question_id'') {IN_CLAUSE_VALUES[row_num] = col_value;}
            break; 
          case ''RESPONSES'': 
            if (col_name == ''observation_id'') {IN_CLAUSE_VALUES[row_num] = col_value;}
            break;  
          case ''ANSWERS'': 
            if (col_name == ''external_id'') {IN_CLAUSE_VALUES[row_num] = col_value;}
          }  
         }
        // Add the row to the array of rows.
        array_of_rows.push(row_as_json);
        ++row_num;
        }
        
      // Put the array in a JSON variable (so it looks like a VARIANT to
      // Snowflake).  The key is "OBSERVATION_DATA", and the value is the array containing the rows
      table_as_json = { "OBSERVATION_DATA" : array_of_rows };
      
      //update the rows selected as having been processed (if desired)
      if ((MARKASPROCESSED == ''TRUE'') && (IN_CLAUSE_VALUES.length > 0))
      {
          var update_command = "UPDATE " + DB_NAME + "." + SCHEMA_NAME + "." + TABLE_NAME + " SET newly_created_or_updated_flag = ''FALSE'' where ";
              update_command += "newly_created_or_updated_flag = ''TRUE'' and ";
          switch (TYPE) {
          case ''QUESTIONS'': 
            update_command += "question_id in ("; 
            break; 
          case ''RESPONSES'': 
            update_command += "observation_id in ("; 
            break;  
          case ''ANSWERS'': 
            update_command += "external_id in ("; 
          }  
          for (var i = 1; i < IN_CLAUSE_VALUES.length; i++) { 
            update_command += "''";
            update_command += IN_CLAUSE_VALUES[i];
            update_command += "''";
            if (i < IN_CLAUSE_VALUES.length-1) { update_command += ", "; }
            }
            update_command += ");"
            
          try {
               snowflake.execute ({sqlText: "begin transaction;"});
               snowflake.execute ({sqlText: update_command});
               snowflake.execute ({sqlText: "commit;"});
              }
          catch (err)  {
              return "Failed: Update unsuccessful.  Command = " + update_command
              }
      }
      return table_as_json;  //return rows to Snowflake, which expects a JSON-compatible VARIANT
}
   else
{
   return "Failed: Parameter formatting error. APP_DB_DEV.CARE_COORDINATION.SP_CC_GET_NEW_OBSERVATION_DATA(''Parm1'', ''Parm2'', ''Parm3'', ''Parm4'')" +
      " where Parm1: QUESTIONS || RESPONSES || ANSWERS" +
       " Parm2: integer between " + ROWS_LOWER_LIMIT + " and " + ROWS_UPPER_LIMIT +
        " Parm3: DEV || PROD" +
         " Parm4: TRUE || FALSE" +
          " Example: APP_DB_DEV.CARE_COORDINATION.SP_CC_GET_NEW_OBSERVATION_DATA(''ANSWERS'',''200'',''DEV'',''TRUE'')"
}
';