CREATE OR REPLACE PROCEDURE DATA_MANAGEMENT.AUDIT.GET_MASTER_FACT_DATABASE_USAGE_METRICS()
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
BEGIN
	INSERT INTO DATA_MANAGEMENT.AUDIT.FACT_DATABASE_USAGE_METRICS
	SELECT DATABASE_NAME, USAGE_DATE, average_database_bytes/1024/1024/1024 as db_size_gb, average_failsafe_bytes/1024/1024/1024 as failsafe_size_gb from table(information_schema.database_storage_usage_history(current_date(),current_date(), ''DW_DEV''))
	union all
	SELECT DATABASE_NAME, USAGE_DATE, average_database_bytes/1024/1024/1024 as db_size_gb, average_failsafe_bytes/1024/1024/1024 as failsafe_size_gb from table(information_schema.database_storage_usage_history(current_date(),current_date(), ''DW_PROD''))
	union all
	SELECT DATABASE_NAME, USAGE_DATE, average_database_bytes/1024/1024/1024 as db_size_gb, average_failsafe_bytes/1024/1024/1024 as failsafe_size_gb from table(information_schema.database_storage_usage_history(current_date(),current_date(), ''DISC_DEV''))
	union all
	SELECT DATABASE_NAME, USAGE_DATE, average_database_bytes/1024/1024/1024 as db_size_gb, average_failsafe_bytes/1024/1024/1024 as failsafe_size_gb from table(information_schema.database_storage_usage_history(current_date(),current_date(), ''DISC_PROD''));
END;
';