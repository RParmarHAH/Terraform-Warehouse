CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.GET_STAGE_CARE_COORDINATION_BRANCH("STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  RETURN_RESULT VARCHAR(1000);
BEGIN      
    --*****************************************************************************************************************************
-- NAME:  CARE_COORDINATION_BRANCH
--
-- PURPOSE: Creates one row per BRANCH
--
-- PRODELOPMENT LOG:
-- DATE        AUTHOR                               NOTES:
-- --------    -------------------                  ---------------------------------------------------------------------------
-- 20/06/2022  Manmohan Soni / Meet Hariyani      Initial PRODelopment
--*****************************************************************************************************************************
--

INSERT OVERWRITE INTO APP_DB_PROD.CARE_COORDINATION_STAGE.CARE_COORDINATION_BRANCH
WITH BRANCH AS(
	SELECT 
		DISTINCT 
			BRANCH_KEY "Branch Key",
			BRANCH_NAME "Branch Name",
			OFFICE_STATE_CODE "Branch State",
            TRIM(CONCAT(IFNULL(OFFICE_ADDRESS1, ''''), '' '', IFNULL(OFFICE_ADDRESS2, ''''))) "Branch Address",
			OFFICE_CITY "Office City",
			OFFICE_PHONE "Office Phone",
            OFFICE_ZIP "Office Zip",
	        :STR_ETL_TASK_KEY AS ETL_TASK_KEY,
            :STR_ETL_TASK_KEY AS ETL_INSERTED_TASK_KEY, 
        CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_INSERTED_DATE,
        CURRENT_USER AS ETL_INSERTED_BY,
        CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_UPDATED_DATE,
        CURRENT_USER AS ETL_LAST_UPDATED_BY,
        0 AS ETL_DELETED_FLAG,
        TRUE NEWLY_CREATED_OR_UPDATED_FLAG
    FROM DW_PROD.HAH.DIM_BRANCH
	WHERE ((SYSTEM_CODE = ''IL'' AND SOURCE_SYSTEM_ID = 3) --IL
		OR (SYSTEM_CODE = ''8485'' AND SOURCE_SYSTEM_ID = 4) --PA
		OR (SYSTEM_CODE = ''MATRIXCARE'' AND BRANCH_NAME LIKE ANY (''H_%'', ''A_%'') AND SOURCE_SYSTEM_ID = 7)--IN
        OR (SOURCE_SYSTEM_ID = 17 AND OFFICE_STATE_CODE in (''PA'', ''NY''))
      ) 
) 
SELECT * FROM BRANCH;
	SELECT CONCAT (''MESSAGE : '',"number of rows inserted",'' Rows Inserted.'') into :return_result FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
	RETURN return_result;
    END;
    ';