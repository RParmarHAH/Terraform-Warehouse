CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.GET_STAGE_CARE_COORDINATION_OBSERVATION_QUESTION_CATALOG("STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  RETURN_RESULT VARCHAR(1000);
BEGIN
--*****************************************************************************************************************************
-- NAME:  GET_STAGE_CARE_COORDINATION_OBSERVATION_QUESTION_CATALOG
--
-- PURPOSE: Creates one row per question
--
-- DEVELOPMENT LOG:
-- DATE        AUTHOR                               NOTES:
-- --------    -------------------                  ---------------------------------------------------------------------------
-- 04/11/2022  Paras Bhavnani                       Initial Development
-- 12/11/2023  Meet Hariyani                        Added QID and Primary_question_key
--*****************************************************************************************************************************

INSERT OVERWRITE INTO CARE_COORDINATION_STAGE.ObservationQuestionCatalog 
SELECT DISTINCT SURVEY_QUESTION_KEY QUESTION_ID, 
                QUESTION_TEXT, 
                QUESTION_CATEGORY,
                IS_ACTIVE,
                QUESTION_ID AS SOURCE_QUESTION_ID,
                :STR_ETL_TASK_KEY AS ETL_TASK_KEY,
                :STR_ETL_TASK_KEY AS ETL_INSERTED_TASK_KEY,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_INSERTED_DATE,
                CURRENT_USER AS ETL_INSERTED_BY,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_LAST_UPDATED_DATE,
                CURRENT_USER AS ETL_LAST_UPDATED_BY,
                0 AS ETL_DELETED_FLAG,
                TRUE as NEWLY_CREATED_OR_UPDATED_FLAG,
                QID AS SOURCE_QID,
                PRIMARY_QUESTION_KEY
FROM DW_PROD.HAH.FACT_SURVEY_QUESTION 
WHERE SURVEY_ID IN (''SV_9R11KQoz9btyWto'',''SV_8rhFLN1ZJEdKRds''); 
	SELECT CONCAT (''MESSAGE : '',"number of rows inserted",'' Rows Inserted.'') into :return_result FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
	RETURN return_result;
    END;
    ';