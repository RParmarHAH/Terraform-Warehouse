CREATE OR REPLACE PROCEDURE DATA_MANAGEMENT.SNOWFLAKE.GET_TABLE_QUERY_METRICS()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '  
    var my_sql_command1 = "SELECT DB, Schema, Table_Name, Table_Name_For_In FROM Data_Management.Snowflake.DW_Tables ORDER BY Schema, Table_Name";
    var statement1 = snowflake.createStatement( {sqlText: my_sql_command1} );
    var result_set1 = statement1.execute();
    // Loop through the results, processing one row at a time... 
    while (result_set1.next())  {
       // Do something with the retrieved values...
       var DB1 = result_set1.getColumnValue(1);
       var Schema1 = result_set1.getColumnValue(2);
       var Table_Name1 = result_set1.getColumnValue(3);
       var Table_Name_For_In1 = result_set1.getColumnValue(4);
       var my_sql_command2 = "SELECT ''" + DB1 + "'', ''" + Schema1 + "'', ''" + Table_Name1 + "'', TO_DATE( DATE_TRUNC( ''MONTH'', Start_Time))::TIMESTAMP_LTZ AS Query_Month, TO_DATE( MIN( Start_Time))::TIMESTAMP_LTZ AS First_Query_Time, "
                           +" TO_DATE( MAX( Start_Time))::TIMESTAMP_LTZ AS Last_Query_Time, COUNT(*) AS Query_Count, TO_DATE( CURRENT_DATE)::TIMESTAMP_LTZ AS Record_Create_Date"
                           +" FROM (SELECT * FROM Snowflake.Account_Usage.Query_History "
                           +" WHERE Query_Type = ''SELECT'' AND (UPPER( Database_Name) = ''DW_PROD'' OR UPPER( Query_Text) LIKE ''%DW_PROD%'') AND UPPER( Query_Text) LIKE ''%FROM%'' ORDER BY Start_Time) tbl "
                           +" WHERE Start_Time >= DATEADD( ''DAY'', 1, LAST_DAY( ADD_MONTHS( CURRENT_DATE, -2))) AND Start_Time < DATEADD( ''DAY'', 1, LAST_DAY( ADD_MONTHS( CURRENT_DATE, -1))) "
                           +" AND UPPER( Query_Text) LIKE " + Table_Name_For_In1 + " GROUP BY 1, 2, 3, 4";
       var statement2 = snowflake.createStatement( {sqlText: my_sql_command2} );
       var result_set2 = statement2.execute();
       if (result_set2.next())  {
          var DB2 = result_set2.getColumnValue(1);
          var schema2 = result_set2.getColumnValue(2);
          var table_name2 = result_set2.getColumnValue(3);
          var query_month2 = result_set2.getColumnValue(4);
          var first_time2 = result_set2.getColumnValue(5);
          var last_time2 = result_set2.getColumnValue(6);
          var query_count2 = result_set2.getColumnValue(7);
          var timestamp2 = result_set2.getColumnValue(8);
          
          //var my_sql_command3 = "INSERT INTO Data_Management.Snowflake.DW_Table_Monthly_Metrics VALUES( ''"+DB2+"'', ''"+schema2+"'', ''"+table_name2+"'', ''"+query_month2+"'', ''"+first_time2+"'', ''"+last_time2+"'', ''"+query_count2+"'', ''"+timestamp2+");";
          //var statement3 = snowflake.createStatement( {sqlText: my_sql_command3} );
          //var result_set3 = statement3.execute();

          var my_sql_command3 = "INSERT INTO Data_Management.Snowflake.DW_Table_Monthly_Metrics VALUES( :1, :2, :3, :4, :5, :6, :7, :8);";
          var result_set3 = snowflake.execute(
              {
              sqlText: my_sql_command3, 
              binds: [ DB2, schema2, table_name2, query_month2, first_time2, last_time2, query_count2, timestamp2]
              }
              );
              
          //var return_value2 = " DB=" + DB2 + " Schema=" + schema2 + " Table=" + table_name2 + " First=" + first_time2 + " Last=" + last_time2 + " Count=" + query_count2 + " sql=" + my_sql_command2;
          var return_value2 = " sql=" + my_sql_command2;
          var return_value3 = " sql=" + my_sql_command3;
          }
       var return_value = " sql=" + my_sql_command2;
       }
  return return_value + " return2= " + return_value2 + " return2= " + return_value3; // Replace with something more useful.
  ';