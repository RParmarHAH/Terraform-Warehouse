CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.SP_CC_GET_NEW_BRANCH_DATA("MAXROWSRETURNED" VARCHAR(16777216), "ENVIRONMENT" VARCHAR(16777216), "MARKASPROCESSED" VARCHAR(16777216), "STATELIST" VARCHAR(16777216))
RETURNS VARIANT
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
      var usStates = [''AL'',''AK'',''AS'',''AZ'',''AR'',''CA'',''CO'',''CT'',''DE'',''FL'',''GA'',''HI'',''ID'',''IL'',''IN'',''IA'',''KS'',''KY'',''LA'',''ME'',''MD'',''MA'',''MI'',''MN'',''MS'',''MO'',''MT'',''NE'',''NV'',''NH'',''NJ'',''NM'',''NY'',''NC'',''ND'',''OH'',''OK'',''OR'',''PA'',''RI'',''SC'',''SD'',''TN'',''TX'',''UT'',''VT'',''VA'',''WA'',''WV'',''WI'',''WY''];
      const ROWS_LOWER_LIMIT = 1;
      const ROWS_UPPER_LIMIT = 2000;
      const SCHEMA_NAME = "CARE_COORDINATION";
      const TABLE_NAME = "BRANCH";
      const COL_NAMES = [''branch_name'',''office_city'',''office_state_code'',''office_address'',''office_zip'',''office_phone'',''branch_key''];
      const SL_Array = STATELIST.split(",");
      STATELIST = "";
      INVALIDSTATELIST = ''FALSE'';
      var found = false;
      for (var j = 0; j < SL_Array.length; j++) { 
        found = false;    
        for (var k = 0; k < usStates.length; k++) {
           if (usStates[k] == SL_Array[j]) {
              found = true;
           break;
           }
        }
        if (found == false) { INVALIDSTATELIST = ''TRUE'';}
           STATELIST += "''";
           STATELIST += SL_Array[j];
           STATELIST += "''";
           if (j < SL_Array.length-1) { STATELIST += ", "; }
      }     
     
if ((MAXROWSRETURNED >= ROWS_LOWER_LIMIT ) &&  
    (MAXROWSRETURNED <= ROWS_UPPER_LIMIT) &&
    (ENVIRONMENT == ''DEV'' || ENVIRONMENT == ''PROD'') &&
    (MARKASPROCESSED == ''TRUE'' || MARKASPROCESSED == ''FALSE'') &&
    (INVALIDSTATELIST == ''FALSE'')
   )
{ 
      var DB_NAME = ''APP_DB_DEV''
      if (ENVIRONMENT == ''PROD'') DB_NAME = "APP_DB_PROD";

      var row_as_json = {};   //hold a JSON data structure that holds ONE row
      var array_of_rows = []; //hold all the rows
      var table_as_json = {}; //hold a JSON data structure that we can return as a VARIANT (all rows in a single "value")
      
      // construct the SELECT command
      var command = "SELECT TOP " + MAXROWSRETURNED + " "
      command += COL_NAMES[0]
      for (var col_num = 1; col_num < COL_NAMES.length; col_num++) {
          command += ", "
          command += COL_NAMES[col_num];
          }
      command += " FROM " + DB_NAME + "." + SCHEMA_NAME + "." + TABLE_NAME + " WHERE NEWLY_CREATED_OR_UPDATED_FLAG = ''TRUE''";
      command += " AND office_state_code in (" + STATELIST + ");"
       
      try {
              var cmd1_dict = {sqlText: command};
              var stmt = snowflake.createStatement(cmd1_dict);
              var rs = stmt.execute();
          }
      catch (err)  {
              return "Failed: Select unsuccessful.  Command = " + command
          }
      
      var IN_CLAUSE_VALUES = new Array;  //hold all key values that will be used for batch update, as applicable
      var row_num = 1;
      var col_name = "";
      var col_value = "";
      
      // add values to the array to be returned
      while (rs.next())  {  
        row_as_json = {};
        
        // For each column in the row...
        for (var col_num = 0; col_num < COL_NAMES.length; col_num++) {
          col_name = COL_NAMES[col_num];
          col_value = rs.getColumnValue(col_num + 1);
          row_as_json[col_name] = col_value
          
          //while we''re here, collect IN clause values for update (if applicable). 
          //depending upon the table, the col_name targeted will differ
            if (col_name == ''branch_key'') {IN_CLAUSE_VALUES[row_num] = col_value;} 
         }
        // Add the row to the array of rows.
        array_of_rows.push(row_as_json);
        ++row_num;
        }
        
      // Put the array in a JSON variable (so it looks like a VARIANT to
      // Snowflake).  The key is "BRANCH_DATA", and the value is the array containing the rows
      table_as_json = { "BRANCH_DATA" : array_of_rows };
      
      //update the rows selected as having been processed (if desired)
      if (MARKASPROCESSED == ''TRUE'' && IN_CLAUSE_VALUES.length > 0)
      {
          var update_command = "UPDATE " + DB_NAME + "." + SCHEMA_NAME + "." + TABLE_NAME + " SET newly_created_or_updated_flag = ''FALSE'' where ";
              update_command += "newly_created_or_updated_flag = ''TRUE'' and ";
              update_command += "branch_key in ("; 

          for (var i = 1; i < IN_CLAUSE_VALUES.length; i++) { 
            update_command += "''";
            update_command += IN_CLAUSE_VALUES[i];
            update_command += "''";
            if (i < IN_CLAUSE_VALUES.length-1) { update_command += ", "; }
            }
            update_command += ");"
          try {
               snowflake.execute ({sqlText: "begin transaction;"});
               snowflake.execute ({sqlText: update_command});
               snowflake.execute ({sqlText: "commit;"});
              }
          catch (err)  {
              return "Failed: Update unsuccessful.  Command = " + update_command
              }
      }
      return table_as_json;  //return rows to Snowflake, which expects a JSON-compatible VARIANT
}
   else
{
   return "Failed: Parameter formatting error. APP_DB_DEV.CARE_COORDINATION.SP_CC_GET_NEW_BRANCH_DATA(''Parm1'', ''Parm2'', ''Parm3'', ''Parm4'')" +
       " where Parm1: integer between " + ROWS_LOWER_LIMIT + " and " + ROWS_UPPER_LIMIT +
        " Parm2: DEV || PROD" +
         " Parm3: TRUE || FALSE" +
          " Parm4: Comma separated state list (upper case, no spaces)" +
          " Example: APP_DB_DEV.CARE_COORDINATION.SP_CC_GET_NEW_BRANCH_DATA(200'',''DEV'',''TRUE'',''PA,IL,IN'')"
}
';