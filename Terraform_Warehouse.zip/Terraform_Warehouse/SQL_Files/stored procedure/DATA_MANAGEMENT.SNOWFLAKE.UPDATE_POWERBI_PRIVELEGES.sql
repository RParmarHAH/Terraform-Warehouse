CREATE OR REPLACE PROCEDURE DATA_MANAGEMENT.SNOWFLAKE.UPDATE_POWERBI_PRIVELEGES()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '  
    var my_sql_command1 = "GRANT USAGE ON DATABASE Disc_Prod TO PowerBI";
    var statement1 = snowflake.createStatement( {sqlText: my_sql_command1} );
    var result1 = statement1.execute();

    var my_sql_command2 = "GRANT USAGE ON ALL SCHEMAS IN DATABASE Disc_Prod TO PowerBI";
    var statement2 = snowflake.createStatement( {sqlText: my_sql_command2} );
    var result2 = statement2.execute();

    var my_sql_command3 = "GRANT USAGE ON FUTURE SCHEMAS IN DATABASE Disc_Prod TO ROLE PowerBI";
    var statement3 = snowflake.createStatement( {sqlText: my_sql_command3} );
    var result3 = statement3.execute();

    var my_sql_command4 = "GRANT SELECT ON ALL TABLES IN DATABASE Disc_Prod TO PowerBI";
    var statement4 = snowflake.createStatement( {sqlText: my_sql_command4} );
    var result4 = statement4.execute();

    var my_sql_command5 = "GRANT SELECT ON FUTURE TABLES IN DATABASE Disc_Prod TO PowerBI";
    var statement5 = snowflake.createStatement( {sqlText: my_sql_command5} );
    var result5 = statement5.execute();

    var my_sql_command6 = "GRANT SELECT ON ALL VIEWS IN DATABASE Disc_Prod TO PowerBI";
    var statement6 = snowflake.createStatement( {sqlText: my_sql_command6} );
    var result6 = statement6.execute();

    var my_sql_command7 = "GRANT SELECT ON FUTURE VIEWS IN DATABASE Disc_Prod TO PowerBI";
    var statement7 = snowflake.createStatement( {sqlText: my_sql_command7} );
    var result7 = statement7.execute();

    var my_sql_command8 = "GRANT USAGE ON DATABASE DW_Prod TO PowerBI";
    var statement8 = snowflake.createStatement( {sqlText: my_sql_command8} );
    var result8 = statement8.execute();

    var my_sql_command9 = "GRANT USAGE ON ALL SCHEMAS IN DATABASE DW_Prod TO PowerBI";
    var statement9 = snowflake.createStatement( {sqlText: my_sql_command9} );
    var result9 = statement9.execute();

    var my_sql_command10 = "GRANT USAGE ON FUTURE SCHEMAS IN DATABASE DW_Prod TO ROLE PowerBI";
    var statement10 = snowflake.createStatement( {sqlText: my_sql_command10} );
    var result10 = statement10.execute();

    var my_sql_command11 = "GRANT SELECT ON ALL TABLES IN DATABASE DW_Prod TO PowerBI";
    var statement11 = snowflake.createStatement( {sqlText: my_sql_command11} );
    var result11 = statement11.execute();

    var my_sql_command12 = "GRANT SELECT ON FUTURE TABLES IN DATABASE DW_Prod TO PowerBI";
    var statement12 = snowflake.createStatement( {sqlText: my_sql_command12} );
    var result12 = statement12.execute();

    var my_sql_command13 = "GRANT SELECT ON ALL VIEWS IN DATABASE DW_Prod TO PowerBI";
    var statement13 = snowflake.createStatement( {sqlText: my_sql_command13} );
    var result13 = statement13.execute();

    var my_sql_command14 = "GRANT SELECT ON FUTURE VIEWS IN DATABASE DW_Prod TO PowerBI";
    var statement14 = snowflake.createStatement( {sqlText: my_sql_command14} );
    var result14 = statement14.execute();

    return result1 + result2 + result3 + result4 + result5 + result6 + result7 +result8 + result9 + result10 + result11 + result12 + result13 + result14 ; // Replace with something more useful.
  ';