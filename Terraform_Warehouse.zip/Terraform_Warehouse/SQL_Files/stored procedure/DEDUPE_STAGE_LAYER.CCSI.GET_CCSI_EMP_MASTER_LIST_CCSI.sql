CREATE OR REPLACE PROCEDURE DEDUPE_STAGE_LAYER.CCSI.GET_CCSI_EMP_MASTER_LIST_CCSI("STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
        var sql = `
INSERT OVERWRITE INTO DISC_DEDUPE_PROD.CCSI.EMP_MASTER_LIST_CCSI
with
  cte_matches as (
      select
          filename
          , cluster_id
          , count(0) cnt
      from  DISC_DEDUPE_PROD.CCSI.CCSI_EMP_DEDUPE_SOURCE
      group by
          filename
          , cluster_id
      having cnt > 1
  )
  ,
  cte_clusters as (
      select
          dedupe.record_id
          ,dedupe.cluster_id
    	  ,ccsi_emp.RECORD_NUMBER
          ,ccsi_emp.EMPLOYEE_NAME
          ,ccsi_emp.EMPLOYEE_NUMBER
          ,ccsi_emp.AREA
          , row_number() over(partition by dedupe.cluster_id order by to_date(ccsi_emp.UPDATED_DATE,''mm/dd/yy'') desc, 
																	  to_date(CREATED_DATE,''mm/dd/yy'') desc, 
																	  TRY_CAST(RECORD_NUMBER AS int) desc) record_order
      from disc_dedupe_prod.CCSI.CCSI_EMP_DEDUPE_SOURCE dedupe
      inner join DISC_PROD.CCSI.employee1 ccsi_emp on
            dedupe.record_id = ccsi_emp.RECORD_NUMBER||ccsi_emp.AREA
      inner join cte_matches matches on
            matches.filename = dedupe.filename
            and matches.cluster_id = dedupe.cluster_id
      order by dedupe.cluster_id
  )
SELECT (ccsi_emp.RECORD_NUMBER::STRING || ''-'' || NVL(ccsi_emp.AREA,''C'')::STRING || ''-'' || ''CCSI'') MASTER_ID,clusts.RECORD_NUMBER, clusts.EMPLOYEE_NUMBER, clusts.EMPLOYEE_NAME,
case when len(clusts.EMPLOYEE_NUMBER)>4 then substring(clusts.EMPLOYEE_NUMBER,2) else clusts.EMPLOYEE_NUMBER end DIM_EMPLOYEE_NUMBER,
UPPER(TRIM(REGEXP_REPLACE(clusts.EMPLOYEE_NAME, ''[d{0}d{1}d{2}d{3}d{4}d{5}d{6}d{7}d{8}d{9}]'', ''''))) DIM_EMPLOYEE_NAME,
--case when substring(clusts.EMPLOYEE_NAME,1,1) in (''1'',''2'',''3'',''4'',''5'',''6'',''7'',''8'',''9'',''0'') then substring(clusts.EMPLOYEE_NAME,2) 
--else clusts.EMPLOYEE_NAME END DIM_EMPLOYEE_NAME, 
HOURLY_RATE_SERVICE_TYPE_25, OVERTIME_RATE_TRAINING, SPECIAL_RATE_SERVICE_TYPE_21, 
ADDRESS, CITY, STATE, ZIPCODE, SS, PHONENUMBER, LEVEL_OF_TRAINING, PHYSICAL_DATE, TB_TEST_DATE, DISCIPLINARY_LEVEL, FEDERAL_DEDUCTIONS, 
STATE_DEDUCTIONS, DATE_OF_BIRTH, FIRST_DAY_OF_WORK_DATE, nvl(HIRE_DATE,''19000101'') HIRE_DATE, MAIL_CHECK_TO_EMPLOYEE, REHIRE, I_9, DESIRES_MORE_HOURS, 
REQUIRES_HOMEMAKER_DOCS, nvl(TERMINATION_DATE,''20991231'') TERMINATION_DATE, PROBATIONARY_EVALUATION, PERSONALCELL_OPT_IN, MARITAL_STATUS, FED_EXTRA, STATE_EXTRA, 
"POSITION", NEW_RECORD, WORKING_AS_HOMEMAKER, SUPERVISORY_DESK, CURRENCY_EXCHANGE_PREFERENCE, CLIENT_AM_PHONE, CLIENT_PM_PHONE, 
INACTIVE_FIELD, INACTIVE_DATE_AND_INFO, PHONE_RELEASE, INS_CODE, INS_AMT, PUBLIC_AID, PUBLIC_AID_OFFICE, NOTIFIED_TERMED, DLN, EXPIRES, 
AUTO_INS_EXPIRES, BACKGROUND_STATUS, UPLOAD_DATE, 
UPPER(TRIM(REGEXP_REPLACE(LAST_NAME, ''[d{0}d{1}d{2}d{3}d{4}d{5}d{6}d{7}d{8}d{9}]'', ''''))) LAST_NAME, 
UPPER(TRIM(REGEXP_REPLACE(FIRST_NAME, ''[d{0}d{1}d{2}d{3}d{4}d{5}d{6}d{7}d{8}d{9}]'', ''''))) FIRST_NAME, 
MIDDLE_INITIAL, SEX, RACE, CELLPHONE, FINGERPRINTED, FP_RESPONSE_DATE, 
FP_VERIFIED_DATE, RELOOK_FLAG, NOTPAID_COUNTER, FAMILY_CARE_GIVER, clusts.AREA, LAST_PAID, REGION, "CALL", INFLUENZA_SHOT, OTY, PRE_EMPID, HAS_SMARTPHONE, 
CREATED_DATE, CREATED_BY, UPDATED_DATE, UPDATED_BY, ETL_TASK_KEY, ETL_INSERTED_TASK_KEY, ETL_INSERTED_DATE, ETL_INSERTED_BY, ETL_LAST_UPDATED_DATE, 
ETL_LAST_UPDATED_BY, ETL_DELETED_FLAG
from DISC_PROD.CCSI.employee1 ccsi_emp
inner join cte_clusters clusts on clusts.record_id=ccsi_emp.RECORD_NUMBER||ccsi_emp.AREA
    and clusts.record_order = 1
--inner join cte_ids id on id.cluster_id = clusts.cluster_id and id.record_order=1
union
select (ccsi_emp.RECORD_NUMBER::STRING || ''-'' || NVL(ccsi_emp.AREA,''C'')::STRING || ''-'' || ''CCSI'') MASTER_ID,ccsi_emp.RECORD_NUMBER,ccsi_emp.EMPLOYEE_NUMBER,ccsi_emp.EMPLOYEE_NAME,
case when len(ccsi_emp.EMPLOYEE_NUMBER)>4 then substring(ccsi_emp.EMPLOYEE_NUMBER,2) else ccsi_emp.EMPLOYEE_NUMBER end DIM_EMPLOYEE_NUMBER,
UPPER(TRIM(REGEXP_REPLACE(ccsi_emp.EMPLOYEE_NAME, ''[d{0}d{1}d{2}d{3}d{4}d{5}d{6}d{7}d{8}d{9}]'', ''''))) DIM_EMPLOYEE_NAME,
--case when substring(ccsi_emp.EMPLOYEE_NAME,1,1) in (''1'',''2'',''3'',''4'',''5'',''6'',''7'',''8'',''9'',''0'') then substring(ccsi_emp.EMPLOYEE_NAME,2) 
--else ccsi_emp.EMPLOYEE_NAME END DIM_EMPLOYEE_NAME, 
ccsi_emp.HOURLY_RATE_SERVICE_TYPE_25,
ccsi_emp.OVERTIME_RATE_TRAINING,ccsi_emp.SPECIAL_RATE_SERVICE_TYPE_21,ccsi_emp.ADDRESS,ccsi_emp.CITY,ccsi_emp.STATE,ccsi_emp.ZIPCODE,ccsi_emp.SS,ccsi_emp.PHONENUMBER,
ccsi_emp.LEVEL_OF_TRAINING,ccsi_emp.PHYSICAL_DATE,ccsi_emp.TB_TEST_DATE,ccsi_emp.DISCIPLINARY_LEVEL,ccsi_emp.FEDERAL_DEDUCTIONS,ccsi_emp.STATE_DEDUCTIONS,
ccsi_emp.DATE_OF_BIRTH,ccsi_emp.FIRST_DAY_OF_WORK_DATE,nvl(ccsi_emp.HIRE_DATE,''19000101'') HIRE_DATE,ccsi_emp.MAIL_CHECK_TO_EMPLOYEE,ccsi_emp.REHIRE,ccsi_emp.I_9,ccsi_emp.DESIRES_MORE_HOURS,
ccsi_emp.REQUIRES_HOMEMAKER_DOCS,nvl(ccsi_emp.TERMINATION_DATE,''20991231'') TERMINATION_DATE,ccsi_emp.PROBATIONARY_EVALUATION,ccsi_emp.PERSONALCELL_OPT_IN,ccsi_emp.MARITAL_STATUS,ccsi_emp.FED_EXTRA,
ccsi_emp.STATE_EXTRA,ccsi_emp."POSITION",ccsi_emp.NEW_RECORD,ccsi_emp.WORKING_AS_HOMEMAKER,ccsi_emp.SUPERVISORY_DESK,ccsi_emp.CURRENCY_EXCHANGE_PREFERENCE,
ccsi_emp.CLIENT_AM_PHONE,ccsi_emp.CLIENT_PM_PHONE,ccsi_emp.INACTIVE_FIELD,ccsi_emp.INACTIVE_DATE_AND_INFO,ccsi_emp.PHONE_RELEASE,ccsi_emp.INS_CODE,ccsi_emp.INS_AMT,
ccsi_emp.PUBLIC_AID,ccsi_emp.PUBLIC_AID_OFFICE,ccsi_emp.NOTIFIED_TERMED,ccsi_emp.DLN,ccsi_emp.EXPIRES,ccsi_emp.AUTO_INS_EXPIRES,ccsi_emp.BACKGROUND_STATUS,
ccsi_emp.UPLOAD_DATE,
--ccsi_emp.LAST_NAME,
UPPER(TRIM(REGEXP_REPLACE(ccsi_emp.LAST_NAME, ''[d{0}d{1}d{2}d{3}d{4}d{5}d{6}d{7}d{8}d{9}]'', ''''))) LAST_NAME,
--ccsi_emp.FIRST_NAME,
UPPER(TRIM(REGEXP_REPLACE(ccsi_emp.FIRST_NAME, ''[d{0}d{1}d{2}d{3}d{4}d{5}d{6}d{7}d{8}d{9}]'', ''''))) FIRST_NAME,
ccsi_emp.MIDDLE_INITIAL,ccsi_emp.SEX,ccsi_emp.RACE,ccsi_emp.CELLPHONE,ccsi_emp.FINGERPRINTED,
ccsi_emp.FP_RESPONSE_DATE,ccsi_emp.FP_VERIFIED_DATE,ccsi_emp.RELOOK_FLAG,ccsi_emp.NOTPAID_COUNTER,ccsi_emp.FAMILY_CARE_GIVER,ccsi_emp.AREA,ccsi_emp.LAST_PAID,
ccsi_emp.REGION,ccsi_emp."CALL",ccsi_emp.INFLUENZA_SHOT,ccsi_emp.OTY,ccsi_emp.PRE_EMPID,ccsi_emp.HAS_SMARTPHONE,ccsi_emp.CREATED_DATE,ccsi_emp.CREATED_BY,
ccsi_emp.UPDATED_DATE,ccsi_emp.UPDATED_BY,ccsi_emp.ETL_TASK_KEY,ccsi_emp.ETL_INSERTED_TASK_KEY,ccsi_emp.ETL_INSERTED_DATE,ccsi_emp.ETL_INSERTED_BY,
ccsi_emp.ETL_LAST_UPDATED_DATE,ccsi_emp.ETL_LAST_UPDATED_BY,ccsi_emp.ETL_DELETED_FLAG
from DISC_PROD.CCSI.employee1 ccsi_emp
left join cte_clusters dups
    on dups.record_id=ccsi_emp.RECORD_NUMBER||ccsi_emp.AREA
where dups.record_id is null 
;`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                return "Succeeded.";   // Return a success/error indicator.
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  
          ';