CREATE OR REPLACE PROCEDURE DATA_MANAGEMENT.DATA_QUALITY.CV_EMPLOYEES_COASTAL_GREAT_PLAINS_MAPPING("STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
        var sql = `
--
-- Initial load of Carevoyant Employees
--
INSERT INTO Data_Management.Data_Quality.CV_Employees_Coastal_Great_Plains_Mapping
(CV_Employee_Key, CV_Source_System_ID, CV_DB, CV_NURSE_ID, CV_SSN, CV_FIRST_NAME, CV_LAST_NAME, CV_NAME, CV_UNIQUE_NAME, CV_ADDRESS, CV_CITY, CV_LOCATION_CODE, CV_PHONE, CV_ROW_ID)
WITH Emp_Latest_Updates AS
(
SELECT TRIM( UPPER( cve.DB)) AS DB, 
       TRIM( UPPER( cve.Nurse_ID)) AS Nurse_ID, 
       MAX( NVL( cve.Dex_Row_ID, -999)) AS Row_ID
FROM DISC_PROD.CostalSyncData.CV_Employees AS cve
GROUP BY 1, 2
),
CVE_Emp_Record AS
(
SELECT TRIM( UPPER( cve.DB)) AS DB, 
       TRIM( UPPER( cve.Nurse_ID)) AS Nurse_ID,
       TRIM( UPPER( cve.Social_Security_Number)) AS Social_Security_Number,
       TRIM( UPPER( cve.Location_Code)) AS Location_Code,
       MAX( Dex_Row_ID) AS Row_ID
FROM DISC_PROD.CostalSyncData.CV_Employees AS cve
INNER JOIN Emp_Latest_Updates AS elu ON elu.DB = TRIM( UPPER( cve.DB)) AND elu.Nurse_ID = TRIM( UPPER( cve.Nurse_ID)) AND TRIM( NVL( cve.Dex_Row_ID, -999)) = elu.Row_ID
GROUP BY 1, 2, 3, 4
),
Distinct_CVE_emp AS
(
SELECT DISTINCT MD5( TRIM( cve.DB) || ''-'' || UPPER( TRIM( cve.Nurse_ID)) || ''-'' || ''COSTALSYNCDATA'') AS Employee_Key,
       UPPER( TRIM( cve.Nurse_ID)) AS Employee_ID, -- TRIM( gpe.Employee_ID), 
       TRIM( cve.DB) AS System_Code, --cve.User_Code, 
       CASE WHEN TRIM( cve.DB) LIKE ''%SAVANNAH%'' THEN 2 ELSE 1 END AS Source_System_ID,
       CASE WHEN TRIM( cve.Social_Security_Number) IN (SELECT SSN FROM Data_Management.Data_Quality.Invalid_SSN) THEN CAST( NULL AS VARCHAR)
            WHEN TRIM( cve.Social_Security_Number) = ''NULL'' OR TRIM( cve.Social_Security_Number) = '''' THEN CAST( NULL AS VARCHAR) 
            ELSE TRIM( cve.Social_Security_Number) 
       END AS Social_Security_Number,
       TRIM( UPPER( cve.First_Name)) AS First_Name,
       TRIM( UPPER( cve.Last_Name)) AS Last_Name,
       TRIM( UPPER( cve.Last_Name))||'', ''||TRIM( UPPER( cve.First_Name)) AS Employee_Name,
       TRIM( UPPER( cve.Address)) AS Address,
       TRIM( UPPER( cve.City)) AS City,
       LEAST( NVL( TRY_TO_NUMBER( cve.Phone), 9999999999), NVL( TRY_TO_NUMBER( cve.Work_Phone), 9999999999), NVL( TRY_TO_NUMBER(cve.Emergency_Phone), 9999999999)) AS Phone,
       cer.DB,
       cer.Location_Code,
       cer.Row_ID,
       Employee_Name||'', ''||cer.DB||'', ''||cer.Location_Code AS Unique_Name
FROM DISC_PROD.CostalSyncData.CV_Employees AS cve
INNER JOIN CVE_Emp_Record AS cer ON cer.DB = TRIM( UPPER( cve.DB)) AND cer.Nurse_ID = TRIM( UPPER( cve.Nurse_ID)) AND  cve.Dex_Row_ID = cer.Row_ID
)
SELECT Employee_Key, Source_System_ID, System_Code, Employee_ID, Social_Security_Number,
       First_Name, Last_Name, Employee_Name, Unique_Name,
       Address, City, Location_Code,
       Phone,
       Row_ID
FROM Distinct_CVE_Emp AS cve
WHERE cve.System_Code||cve.Employee_ID NOT IN ( SELECT DISTINCT CV_DB||CV_Nurse_ID FROM Data_Management.Data_Quality.CV_Employees_Coastal_Great_Plains_Mapping WHERE CV_DB IS NOT NULL AND CV_Nurse_ID IS NOT NULL);

`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  

        sql = `
--
-- Match records based on CV_Nurse_ID = GP_Employee_ID, which is captured in the last line of the update statement
--
UPDATE Data_Management.Data_Quality.CV_Employees_Coastal_Great_Plains_Mapping AS cve
SET cve.GP_DB = gpe.DB, cve.GP_EMPLOYEE_ID = gpe.Employee_ID, cve.GP_SSN = gpe.SSN,
    cve.GP_FIRST_NAME = gpe.First_Name, cve.GP_LAST_NAME = gpe.Last_Name,
    cve.GP_ADDRESS = gpe.Address1, cve.GP_CITY = gpe.City, cve.GP_STATE_CODE = gpe.State, cve.GP_Zip = gpe.Zip,
    cve.GP_DEPARTMENT = gpe.Department, cve.GP_LOCATION = gpe.Office_Code,
    cve.GP_PHONE = gpe.Phone, cve.GP_DOB = DOB, cve.GP_HIRE_DATE = gpe.Hire_Date, cve.GP_TERMINATE_DATE = gpe.Terminate_Date, cve.GP_InActive = gpe.InActive,
    cve.Match_Type = ''Employee_ID''
FROM (
WITH Great_Plains_Employees_Distinct_SSN AS
(
SELECT gpe.DB, gpe.SSN, 
       MAX( NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)) AS Terminate_Date
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
WHERE TRIM( UPPER( gpe.DB)) || TRIM( UPPER( gpe.Employee_ID)) || TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.DB)) || TRIM( UPPER( gpe2.Employee_ID)) || TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
GROUP BY gpe.DB, gpe.SSN
),
Great_Plains_Employees AS
(
SELECT CASE WHEN TRIM( gpe.DB) = ''SHC'' THEN ''SHC_SAVANNAH'' ELSE ''SHC_ALTRUS'' END AS DB, 
       TRIM( UPPER( gpe.Employee_ID)) AS Employee_ID, 
       gpe.SSN,
       IFF( gpe.DOB=CAST( ''1900-01-01'' AS DATE), NULL, gpe.DOB) AS DOB, 
       CASE WHEN gpe.Hire_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Hire_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Hire_Date
       END AS Hire_Date, 
       CASE WHEN gpe.Terminate_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Terminate_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Terminate_Date
       END AS Terminate_Date, 
       gpe.InActive,
       TRIM( UPPER( gpe.First_Name)) AS First_Name, 
       TRIM( UPPER( gpe.Last_Name)) AS Last_Name, 
       TRIM( UPPER( gpe.Address1)) AS Address1, 
       TRIM( UPPER( gpe.City)) AS City, 
       st.State_ISO_Code AS State,
       gpe.Zip,
       LEAST( NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number), 0), 9999999999), NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number_2), 0), 9999999999)) AS Phone,
       gpe.Department, comp.Office_Code
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
INNER JOIN DISC_Prod.Stage.Coastal_Office_Mapping_Payroll AS comp ON comp.DB = gpe.DB AND comp.Department = gpe.Department
INNER JOIN Great_Plains_Employees_Distinct_SSN AS gpssn ON gpssn.DB = gpe.DB AND gpssn.SSN = gpe.SSN AND NVL( NULLIF( gpssn.Terminate_Date, ''1900-01-01''), CURRENT_DATE) = NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)
LEFT OUTER JOIN DW_PROD.HAH.DIM_State AS st ON TRIM( UPPER( gpe.State)) = st.State_ISO_Code
WHERE gpe.SSN NOT IN (SELECT SSN FROM Data_Management.Data_Quality.Invalid_SSN)
AND TRIM( UPPER( gpe.DB)) || TRIM( UPPER( gpe.Employee_ID)) || TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.DB)) || TRIM( UPPER( gpe2.Employee_ID)) || TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
)
SELECT *
FROM Great_Plains_Employees AS gpe ) gpe
WHERE cve.CV_DB = gpe.DB AND cve.CV_Nurse_ID = gpe.Employee_ID AND cve.GP_Employee_ID IS NULL;

`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  

        sql = `
--
-- Match records based on CV_SSN = GP_SSN, which is captured in the last line of the update statement
--
UPDATE Data_Management.Data_Quality.CV_Employees_Coastal_Great_Plains_Mapping AS cve
SET cve.GP_DB = gpe.DB, cve.GP_EMPLOYEE_ID = gpe.Employee_ID, cve.GP_SSN = gpe.SSN,
    cve.GP_FIRST_NAME = gpe.First_Name, cve.GP_LAST_NAME = gpe.Last_Name,
    cve.GP_ADDRESS = gpe.Address1, 
    cve.GP_CITY = gpe.City, 
    cve.GP_STATE_CODE = gpe.State, 
    cve.GP_Zip = gpe.Zip,
    cve.GP_DEPARTMENT = gpe.Department, cve.GP_LOCATION = gpe.Office_Code,
    cve.GP_PHONE = gpe.Phone, cve.GP_DOB = DOB, cve.GP_HIRE_DATE = gpe.Hire_Date, cve.GP_TERMINATE_DATE = gpe.Terminate_Date, cve.GP_InActive = gpe.InActive,
    cve.Match_Type = ''SSN''
FROM (
WITH Great_Plains_Employees_Distinct_SSN AS
(
SELECT gpe.DB, gpe.SSN, 
       MAX( NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)) AS Terminate_Date
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
WHERE TRIM( UPPER( gpe.DB)) || TRIM( UPPER( gpe.Employee_ID)) || TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.DB)) || TRIM( UPPER( gpe2.Employee_ID)) || TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
GROUP BY gpe.DB, gpe.SSN
),
Great_Plains_Employees AS
(
SELECT CASE WHEN TRIM( gpe.DB) = ''SHC'' THEN ''SHC_SAVANNAH'' ELSE ''SHC_ALTRUS'' END AS DB, 
       TRIM( UPPER( gpe.Employee_ID)) AS Employee_ID, 
       gpe.SSN,
       gpe.DOB,
       CASE WHEN gpe.Hire_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Hire_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Hire_Date
       END AS Hire_Date, 
       CASE WHEN gpe.Terminate_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Terminate_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Terminate_Date
       END AS Terminate_Date, 
       gpe.InActive,
       TRIM( UPPER( gpe.First_Name)) AS First_Name, 
       TRIM( UPPER( gpe.Last_Name)) AS Last_Name, 
       TRIM( UPPER( gpe.Address1)) AS Address1, 
       TRIM( UPPER( gpe.City)) AS City, 
       st.State_ISO_Code AS State,
       gpe.Zip,
       LEAST( NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number), 0), 9999999999), NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number_2), 0), 9999999999)) AS Phone,
       gpe.Department, comp.Office_Code
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
INNER JOIN DISC_Prod.Stage.Coastal_Office_Mapping_Payroll AS comp ON comp.DB = gpe.DB AND comp.Department = gpe.Department
INNER JOIN Great_Plains_Employees_Distinct_SSN AS gpssn ON gpssn.DB = gpe.DB AND gpssn.SSN = gpe.SSN AND NVL( NULLIF( gpssn.Terminate_Date, ''1900-01-01''), CURRENT_DATE) = NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)
LEFT OUTER JOIN DW_PROD.HAH.DIM_State AS st ON TRIM( UPPER( gpe.State)) = st.State_ISO_Code
WHERE gpe.SSN NOT IN (SELECT SSN FROM Data_Management.Data_Quality.Invalid_SSN)
AND TRIM( UPPER( gpe.DB)) || TRIM( UPPER( gpe.Employee_ID)) || TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.DB)) || TRIM( UPPER( gpe2.Employee_ID)) || TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
)
SELECT *
FROM Great_Plains_Employees AS gpe ) gpe
WHERE cve.CV_DB = gpe.DB AND cve.CV_SSN = gpe.SSN AND cve.GP_Employee_ID IS NULL;

`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  

        sql = `
--
-- Match records based on CV_First_Name = GP_First_Name and CV_Last_Name = GP_Last_Name, which is captured in the last line of the update statement
--
UPDATE Data_Management.Data_Quality.CV_Employees_Coastal_Great_Plains_Mapping AS cve
SET cve.GP_DB = gpe.DB, cve.GP_EMPLOYEE_ID = gpe.Employee_ID, cve.GP_SSN = gpe.SSN,
    cve.GP_FIRST_NAME = gpe.First_Name, cve.GP_LAST_NAME = gpe.Last_Name,
    cve.GP_ADDRESS = gpe.Address1, 
    cve.GP_CITY = gpe.City, 
    cve.GP_STATE_CODE = gpe.State, 
    cve.GP_Zip = gpe.Zip,
    cve.GP_DEPARTMENT = gpe.Department, cve.GP_LOCATION = gpe.Office_Code,
    cve.GP_PHONE = gpe.Phone, cve.GP_DOB = DOB, cve.GP_HIRE_DATE = gpe.Hire_Date, cve.GP_TERMINATE_DATE = gpe.Terminate_Date, cve.GP_InActive = gpe.InActive,
    cve.Match_Type = ''Name''
FROM (
WITH Great_Plains_Employees_Distinct_SSN AS
(
SELECT gpe.DB, gpe.SSN, 
       MAX( NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)) AS Terminate_Date
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
WHERE TRIM( UPPER( gpe.DB)) || TRIM( UPPER( gpe.Employee_ID)) || TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.DB)) || TRIM( UPPER( gpe2.Employee_ID)) || TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
GROUP BY gpe.DB, gpe.SSN
),
Great_Plains_Employees AS
(
SELECT CASE WHEN TRIM( gpe.DB) = ''SHC'' THEN ''SHC_SAVANNAH'' ELSE ''SHC_ALTRUS'' END AS DB, 
       TRIM( UPPER( gpe.Employee_ID)) AS Employee_ID, 
       gpe.SSN,
       gpe.DOB,
       CASE WHEN gpe.Hire_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Hire_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Hire_Date
       END AS Hire_Date, 
       CASE WHEN gpe.Terminate_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Terminate_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Terminate_Date
       END AS Terminate_Date, 
       gpe.InActive,
       TRIM( UPPER( gpe.First_Name)) AS First_Name, 
       TRIM( UPPER( gpe.Last_Name)) AS Last_Name, 
       TRIM( UPPER( gpe.Address1)) AS Address1, 
       TRIM( UPPER( gpe.City)) AS City, 
       st.State_ISO_Code AS State,
       gpe.Zip,
       LEAST( NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number), 0), 9999999999), NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number_2), 0), 9999999999)) AS Phone,
       gpe.Department, comp.Office_Code
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
INNER JOIN DISC_Prod.Stage.Coastal_Office_Mapping_Payroll AS comp ON comp.DB = gpe.DB AND comp.Department = gpe.Department
INNER JOIN Great_Plains_Employees_Distinct_SSN AS gpssn ON gpssn.DB = gpe.DB AND gpssn.SSN = gpe.SSN AND NVL( NULLIF( gpssn.Terminate_Date, ''1900-01-01''), CURRENT_DATE) = NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)
LEFT OUTER JOIN DW_PROD.HAH.DIM_State AS st ON TRIM( UPPER( gpe.State)) = st.State_ISO_Code
WHERE gpe.SSN NOT IN (SELECT SSN FROM Data_Management.Data_Quality.Invalid_SSN)
AND TRIM( UPPER( gpe.DB)) || TRIM( UPPER( gpe.Employee_ID)) || TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.DB)) || TRIM( UPPER( gpe2.Employee_ID)) || TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
)
SELECT *
FROM Great_Plains_Employees AS gpe ) gpe
WHERE cve.CV_DB = gpe.DB AND cve.CV_First_Name = gpe.First_Name AND cve.CV_Last_Name = gpe.Last_Name AND cve.GP_Employee_ID IS NULL;

`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  

        sql = `
  
--
-- Match records based on CV_Phone = GP_Phone, which is captured in the last line of the update statement
-- Note: the phone number used in comparison is the LEAST of all the recorded phone numbers
--
UPDATE Data_Management.Data_Quality.CV_Employees_Coastal_Great_Plains_Mapping AS cve
SET cve.GP_DB = gpe.DB, cve.GP_EMPLOYEE_ID = gpe.Employee_ID, cve.GP_SSN = gpe.SSN,
    cve.GP_FIRST_NAME = gpe.First_Name, cve.GP_LAST_NAME = gpe.Last_Name,
    cve.GP_ADDRESS = gpe.Address1, 
    cve.GP_CITY = gpe.City, 
    cve.GP_STATE_CODE = gpe.State, 
    cve.GP_Zip = gpe.Zip,
    cve.GP_DEPARTMENT = gpe.Department, cve.GP_LOCATION = gpe.Office_Code,
    cve.GP_PHONE = gpe.Phone, cve.GP_DOB = DOB, cve.GP_HIRE_DATE = gpe.Hire_Date, cve.GP_TERMINATE_DATE = gpe.Terminate_Date, cve.GP_InActive = gpe.InActive,
    cve.Match_Type = ''Phone''
FROM (
WITH Great_Plains_Employees_Distinct_SSN AS
(
SELECT gpe.DB, gpe.SSN, 
       MAX( NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)) AS Terminate_Date
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
WHERE TRIM( UPPER( gpe.Employee_ID))||TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.Employee_ID))||TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
GROUP BY gpe.DB, gpe.SSN
),
Great_Plains_Employees AS
(
SELECT CASE WHEN TRIM( gpe.DB) = ''SHC'' THEN ''SHC_SAVANNAH'' ELSE ''SHC_ALTRUS'' END AS DB, 
       TRIM( UPPER( gpe.Employee_ID)) AS Employee_ID, 
       gpe.SSN,
       gpe.DOB,
       CASE WHEN gpe.Hire_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Hire_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Hire_Date
       END AS Hire_Date, 
       CASE WHEN gpe.Terminate_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Terminate_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Terminate_Date
       END AS Terminate_Date, 
       gpe.InActive,
       TRIM( UPPER( gpe.First_Name)) AS First_Name, 
       TRIM( UPPER( gpe.Last_Name)) AS Last_Name, 
       TRIM( UPPER( gpe.Address1)) AS Address1, 
       TRIM( UPPER( gpe.City)) AS City, 
       st.State_ISO_Code AS State,
       gpe.Zip,
       LEAST( NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number), 0), 9999999999), NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number_2), 0), 9999999999)) AS Phone,
       gpe.Department, comp.Office_Code
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
INNER JOIN DISC_Prod.Stage.Coastal_Office_Mapping_Payroll AS comp ON comp.DB = gpe.DB AND comp.Department = gpe.Department
INNER JOIN Great_Plains_Employees_Distinct_SSN AS gpssn ON gpssn.DB = gpe.DB AND gpssn.SSN = gpe.SSN AND NVL( NULLIF( gpssn.Terminate_Date, ''1900-01-01''), CURRENT_DATE) = NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)
LEFT OUTER JOIN DW_PROD.HAH.DIM_State AS st ON TRIM( UPPER( gpe.State)) = st.State_ISO_Code
WHERE gpe.SSN NOT IN (SELECT SSN FROM Data_Management.Data_Quality.Invalid_SSN)
AND TRIM( UPPER( gpe.Employee_ID))||TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.Employee_ID))||TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
)
SELECT *
FROM Great_Plains_Employees AS gpe ) gpe
WHERE cve.CV_DB = gpe.DB AND cve.CV_Phone = gpe.Phone AND cve.CV_Phone <> 9999999999 AND gpe.Phone <> 9999999999 AND cve.CV_Location_Code = gpe.Office_Code AND SUBSTRING( cve.CV_Address, 1, 8) = SUBSTRING( gpe.Address1, 1, 8) AND cve.GP_Employee_ID IS NULL;


`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  

        sql = `
--
-- Match records based on location code and part of first name and part of address, which is captured in the last line of the update statement
--
UPDATE Data_Management.Data_Quality.CV_Employees_Coastal_Great_Plains_Mapping AS cve
SET cve.GP_DB = gpe.DB, cve.GP_EMPLOYEE_ID = gpe.Employee_ID, cve.GP_SSN = gpe.SSN,
    cve.GP_FIRST_NAME = gpe.First_Name, cve.GP_LAST_NAME = gpe.Last_Name,
    cve.GP_ADDRESS = gpe.Address1, 
    cve.GP_CITY = gpe.City, 
    cve.GP_STATE_CODE = gpe.State, 
    cve.GP_Zip = gpe.Zip,
    cve.GP_DEPARTMENT = gpe.Department, cve.GP_LOCATION = gpe.Office_Code,
    cve.GP_PHONE = gpe.Phone, cve.GP_DOB = DOB, cve.GP_HIRE_DATE = gpe.Hire_Date, cve.GP_TERMINATE_DATE = gpe.Terminate_Date, cve.GP_InActive = gpe.InActive,
    cve.Match_Type = ''First Name & Address''
FROM (
WITH Great_Plains_Employees_Distinct_SSN AS
(
SELECT gpe.DB, gpe.SSN, 
       MAX( NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)) AS Terminate_Date
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
WHERE TRIM( UPPER( gpe.DB)) || TRIM( UPPER( gpe.Employee_ID)) || TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.DB)) || TRIM( UPPER( gpe2.Employee_ID)) || TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
GROUP BY gpe.DB, gpe.SSN
),
Great_Plains_Employees AS
(
SELECT CASE WHEN TRIM( gpe.DB) = ''SHC'' THEN ''SHC_SAVANNAH'' ELSE ''SHC_ALTRUS'' END AS DB, 
       TRIM( UPPER( gpe.Employee_ID)) AS Employee_ID, 
       gpe.SSN,
       gpe.DOB,
       CASE WHEN gpe.Hire_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Hire_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Hire_Date
       END AS Hire_Date, 
       CASE WHEN gpe.Terminate_Date < CAST( ''1950-01-01'' AS DATE) OR gpe.Terminate_Date > DATEADD( ''YEAR'', 1, CURRENT_DATE) THEN NULL
            ELSE gpe.Terminate_Date
       END AS Terminate_Date, 
       gpe.InActive,
       TRIM( UPPER( gpe.First_Name)) AS First_Name, 
       TRIM( UPPER( gpe.Last_Name)) AS Last_Name, 
       TRIM( UPPER( gpe.Address1)) AS Address1, 
       TRIM( UPPER( gpe.City)) AS City, 
       st.State_ISO_Code AS State,
       gpe.Zip,
       LEAST( NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number), 0), 9999999999), NVL( NULLIF( TRY_TO_NUMBER( gpe.Phone_Number_2), 0), 9999999999)) AS Phone,
       gpe.Department, comp.Office_Code
FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe
INNER JOIN DISC_Prod.Stage.Coastal_Office_Mapping_Payroll AS comp ON comp.DB = gpe.DB AND comp.Department = gpe.Department
INNER JOIN Great_Plains_Employees_Distinct_SSN AS gpssn ON gpssn.DB = gpe.DB AND gpssn.SSN = gpe.SSN AND NVL( NULLIF( gpssn.Terminate_Date, ''1900-01-01''), CURRENT_DATE) = NVL( NULLIF( gpe.Terminate_Date, ''1900-01-01''), CURRENT_DATE)
LEFT OUTER JOIN DW_PROD.HAH.DIM_State AS st ON TRIM( UPPER( gpe.State)) = st.State_ISO_Code
WHERE gpe.SSN NOT IN (SELECT SSN FROM Data_Management.Data_Quality.Invalid_SSN)
AND TRIM( UPPER( gpe.DB)) || TRIM( UPPER( gpe.Employee_ID)) || TRIM( gpe.SSN) NOT IN (SELECT TRIM( UPPER( gpe2.DB)) || TRIM( UPPER( gpe2.Employee_ID)) || TRIM(gpe2.SSN) FROM DISC_PROD.CostalSyncData.GPAllEmployeesBase AS gpe2 WHERE TRIM( UPPER( gpe2.Reason_to_Term)) LIKE ANY ( ''%DUPLICATE%PROFILE%'', ''%WRONG%ID%'', ''%CODE%IN%USE%'', ''%WRONG%CODE%''))
)
SELECT *
FROM Great_Plains_Employees AS gpe ) gpe
WHERE cve.CV_DB = gpe.DB AND SUBSTRING( cve.CV_First_Name, 1, 5) = SUBSTRING( gpe.First_Name, 1, 5) AND cve.CV_Location_Code = gpe.Office_Code AND SUBSTRING( cve.CV_Address, 1, 8) = SUBSTRING( gpe.Address1, 1, 8) AND cve.GP_Employee_ID IS NULL;

`;
          try {
                snowflake.execute (
                    {sqlText: sql}
                    );
                return "Succeeded.";   // Return a success/error indicator.
                }
            catch (err)  {
                return "Failed: " + err;   // Return a success/error indicator.
                }  

          ';