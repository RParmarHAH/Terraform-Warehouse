CREATE OR REPLACE PROCEDURE APP_DB_PROD.COACHUPCARE.GET_STAGE_COACHUPCARE_REWARDS_EVENT_LOG_SURVEY_COMPLETED("REWARD_MASTER_KEY" VARCHAR(16777216), "STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
    REWARD_MSTR_KEY NUMBER(38,0);
    REWARD_MSTR_NAME VARCHAR;
    MSTR_POINT NUMBER(38,0);
    MSTR_POINT_KEY NUMBER(38,0);
BEGIN

--*****************************************************************************************************************************
-- NAME:  COACHUPCARE.GET_STAGE_COACHUPCARE_REWARDS_EVENT_LOG
--
-- PURPOSE: Procedure to insert new records in REWARDS_EVENT_LOG table
--
-- DEVELOPMENT LOG:
-- DATE        AUTHOR                               NOTES:
-- --------    -------------------                 ---------------------------------------------------------------------------
-- 16/01/2023   MOIN SAIYED / MANMOHAN SONI         Initial development
-- 07/02/2023   MOIN SAIYED / MANMOHAN SONI         Added new survey id for Healthy Match Caregiver Survey V3
-- 20/02/2023   MOIN SAIYED / MANMOHAN SONI         Added join with BRANCH_COACHUPCARE_INSTANCE_XREF table to filter active branch
--*****************************************************************************************************************************

    SELECT REWARD_MASTER_KEY, NAME INTO :REWARD_MSTR_KEY, :REWARD_MSTR_NAME
    FROM 
        APP_DB_PROD.COACHUPCARE.REWARDS_MASTER
    WHERE 
        CURRENT_DATE() BETWEEN ACTIVATED_DATE AND IFNULL(INACTIVATED_DATE, ''9999-12-31'') 
        AND DELETED_FLAG = FALSE
        AND REWARD_MASTER_KEY = :REWARD_MASTER_KEY;
    
    IF ( COALESCE(REWARD_MSTR_KEY, 0) <> 0 AND COALESCE(UPPER(REWARD_MSTR_NAME), '''') = ''SURVEY COMPLETED'' ) THEN
        
        
        SELECT POINTS_VALUE, REWARD_MASTER_KEY INTO :MSTR_POINT, :MSTR_POINT_KEY
        FROM 
            APP_DB_PROD.COACHUPCARE.REWARDS_MASTER_POINTS
        WHERE 
            CURRENT_DATE() BETWEEN POINTS_ACTIVATED_DATE AND IFNULL(POINTS_INACTIVATED_DATE, ''9999-12-31'') 
            AND DELETED_FLAG = FALSE
            AND REWARD_MASTER_KEY = :REWARD_MASTER_KEY;
        
        -- START OF INNER IF
        
        IF (COALESCE(MSTR_POINT, 0) <> 0 AND COALESCE(MSTR_POINT_KEY, 0) <> 0) THEN
            
            -- INSERT STATEMENT 
            
            INSERT INTO APP_DB_PROD.COACHUPCARE.rewards_event_log
                ( -- REWARDS_EVENT_LOG_KEY, 
                    REWARD_MASTER_KEY, REWARD_POINT_KEY, AMS_EMPLOYEE_KEY, BRANCH_KEY, POINTS_VALUE, AWARD_ARTIFACT, AWARD_ELIGIBLE_TIMESTAMP, AWARDED_TIMESTAMP, AWARDED_BY_PROCESS, FULLFILLED_BY_PROCESS, FULLFILLED_TIMESTAMP, ETL_TASK_KEY, ETL_INSERTED_TASK_KEY, ETL_INSERTED_DATE, ETL_INSERTED_BY, ETL_LAST_UPDATED_DATE, ETL_LAST_UPDATED_BY, ETL_DELETED_FLAG,
                    EMPLOYEE_ENTERPRISE_ID, CARE_COORDINATION_EMPLOYEE_KEY
                )
            WITH UNIQUE_SURVEY_IN_DAY AS (
                SELECT
                    EMPLOYEE_KEY,
                    CLIENT_KEY,
                    BRANCH_KEY,
                    SURVEY_KEY,
                    RECORD_ID,
                    RECORDED_DATE,
                    START_DATE,
                    END_DATE,
                    ROW_NUMBER() OVER (PARTITION BY CLIENT_KEY, EMPLOYEE_KEY, DATE(RECORDED_DATE) ORDER BY RECORDED_DATE DESC) R
                FROM
                    DW_PROD.HAH.DIM_SURVEY_RESPONSE_HEADER
                WHERE
                    SURVEY_ID in (''SV_9R11KQoz9btyWto'', ''SV_8rhFLN1ZJEdKRds'')
                    AND COMPLETED_FLAG = TRUE
                    AND RECORDED_DATE >= ''2023-01-09''
                    AND EMPLOYEE_KEY IS NOT NULL
                    QUALIFY R = 1
            )
            SELECT
                DISTINCT
                --NULL REWARDS_EVENT_LOG_KEY,
                :REWARD_MASTER_KEY REWARD_MASTER_KEY,
                :MSTR_POINT_KEY REWARD_POINT_KEY,
                E.AMS_EMPLOYEE_KEY AMS_EMPLOYEE_KEY,
                E.BRANCH_KEY BRANCH_KEY,
                :MSTR_POINT POINTS_VALUE,
                RECORD_ID AWARD_ARTIFACT,
                RECORDED_DATE AWARD_ELIGIBLE_TIMESTAMP,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AWARDED_TIMESTAMP,
                ''Pipeline_Coachupcare_Nightly_process'' AWARDED_BY_PROCESS,
                NULL FULLFILLED_BY_PROCESS,
                NULL FULLFILLED_TIMESTAMP,
                :STR_ETL_TASK_KEY ETL_TASK_KEY,
                :STR_ETL_TASK_KEY ETL_INSERTED_TASK_KEY,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_INSERTED_DATE,
                CURRENT_USER AS ETL_INSERTED_BY,
                CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_LAST_UPDATED_DATE,
                CURRENT_USER AS ETL_LAST_UPDATED_BY,
                0 AS ETL_DELETED_FLAG,
                E.EMPLOYEE_ENTERPRISE_ID EMPLOYEE_ENTERPRISE_ID,
                S.EMPLOYEE_KEY CARE_COORDINATION_EMPLOYEE_KEY
            FROM
                UNIQUE_SURVEY_IN_DAY S
            INNER JOIN 
                APP_DB_PROD.COACHUPCARE.employee_feed E
                    ON S.EMPLOYEE_KEY = E.CARE_COORDINATION_EMPLOYEE_KEY
            INNER JOIN 
                APP_DB_PROD.COACHUPCARE.BRANCH_COACHUPCARE_INSTANCE_XREF BR
                    ON E.BRANCH_KEY = BR.BRANCH_KEY AND BR.BRANCH_ACTIVE = TRUE
            WHERE S.RECORD_ID NOT IN (
                SELECT AWARD_ARTIFACT FROM APP_DB_PROD.COACHUPCARE.rewards_event_log
            )
            AND EXISTS (SELECT 1 FROM DW_PROD.INTEGRATION.DIM_EMPLOYEE_MERGED DM WHERE DM.EMPLOYEE_KEY = E.AMS_EMPLOYEE_KEY AND DM.EMPLOYEE_KEY = DM.ORIGINAL_EMPLOYEE_KEY);
            
            -- END OF INSERT STATEMENT
            
            
            RETURN ''SUCCESS : '' || SQLROWCOUNT || '' rows inserted'';
        ELSE
            RETURN ''FAILED: NO ACTIVE REWARD POINT FOUND'';
        END IF;
        
        -- END OF INNER IF
        
    ELSE
        RETURN ''FAILED: NO ACTIVE REWARD FOUND ASSOCIATED WITH SURVEY COMPLETED WITH REWARD MASTER KEY ''|| REWARD_MASTER_KEY;
    END IF;
END;
';