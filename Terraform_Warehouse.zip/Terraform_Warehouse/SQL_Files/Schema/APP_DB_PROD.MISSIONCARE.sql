DATABASE_NAME = APP_DB_PROD
SCHEMA_NAME = MISSIONCARE
IS_TRANSIENT = NO
IS_MANAGED_ACCESS = NO
RETENTION_TIME = 1
COMMENT = Contains structures to support the data feeds to Mission Care
