DATABASE_NAME = DISC_PROD
SCHEMA_NAME = HSX
IS_TRANSIENT = NO
IS_MANAGED_ACCESS = NO
RETENTION_TIME = 1
COMMENT = Health System Exchange - Pennsylvania Health Information Exchange
