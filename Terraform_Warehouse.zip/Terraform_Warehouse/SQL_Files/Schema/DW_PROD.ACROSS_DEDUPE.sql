DATABASE_NAME = DW_PROD
SCHEMA_NAME = ACROSS_DEDUPE
IS_TRANSIENT = NO
IS_MANAGED_ACCESS = NO
RETENTION_TIME = 1
COMMENT = Created schema for testing across dedupe. will delete once testing is done -- jigar prajapati
