DATABASE_NAME = DATA_MANAGEMENT
IS_TRANSIENT = NO
RETENTION_TIME = 1
COMMENT = Contains data structures used for data quality and managing Snowflake environment
