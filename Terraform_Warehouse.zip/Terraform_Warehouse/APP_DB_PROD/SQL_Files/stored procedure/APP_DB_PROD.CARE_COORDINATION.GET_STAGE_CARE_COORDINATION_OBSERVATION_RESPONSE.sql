CREATE OR REPLACE PROCEDURE APP_DB_PROD.CARE_COORDINATION.GET_STAGE_CARE_COORDINATION_OBSERVATION_RESPONSE("STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  RETURN_RESULT VARCHAR(1000);
BEGIN
    --*****************************************************************************************************************************
-- NAME:  GET_STAGE_CARE_COORDINATION_OBSERVATION_RESPONSE
--
-- PURPOSE: Creates one row per observation response 
--
-- DEVELOPMENT LOG:
-- DATE        AUTHOR                               NOTES:
-- --------    -------------------                  ---------------------------------------------------------------------------
-- 04/11/2022  Paras Bhavnani                       Initial Development
-- 11/09/2023  Pooja Deokate 						Changed into logic and added filter which will extract only records having associated answers in FACT_SURVEY_RESPONSE_DETAIL
-- 15/02/2024  Meet Hariyani                        Changed partner_key join to partner_contract_key and changed table dim partner to dim partner contract to populated program id
--*****************************************************************************************************************************

INSERT OVERWRITE INTO CARE_COORDINATION_STAGE.OBSERVATIONRESPONSE 
SELECT DISTINCT RECORD_ID OBSERVATION_ID, 
                 1 OBSERVATION_VERSION, 
                 RECORD_ID EXTERNAL_ID, 
                 COALESCE(CMD.OLD_KEY,CLIENT_KEY) CLIENT,
                 COMPLETED_FLAG COMPLETED, 
                 RECORDED_DATE DATE_RECORDED,
                 DSRH.START_DATE START_DATE,
                 DSRH.END_DATE END_DATE, 
                 DURATION_IN_SECONDS DURATION, 
                 LANGUAGE LANGUAGE, 
                 LATITUDE LATITUDE, 
                 LONGITUDE LONGITUDE, 
                 COALESCE(CAMD.OLD_KEY,EMPLOYEE_KEY) EMPLOYEE, 
                 SURVEY_ID SURVEY_ID,
                 DPC.CONTRACT_CODE PROGRAM_ID,
                 :STR_ETL_TASK_KEY AS ETL_TASK_KEY,
                 :STR_ETL_TASK_KEY AS ETL_INSERTED_TASK_KEY,
                 CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_INSERTED_DATE,
                 CURRENT_USER AS ETL_INSERTED_BY,
                 CONVERT_TIMEZONE(''UTC'', CURRENT_TIMESTAMP)::TIMESTAMP_NTZ AS ETL_LAST_UPDATED_DATE,
                 CURRENT_USER AS ETL_LAST_UPDATED_BY,
                 0 AS ETL_DELETED_FLAG,
                 TRUE as NEWLY_CREATED_OR_UPDATED_FLAG
FROM DW_PROD.HAH.DIM_SURVEY_RESPONSE_HEADER DSRH
LEFT JOIN DW_PROD.HAH.DIM_PARTNER_CONTRACT DPC ON DSRH.PARTNER_CONTRACT_KEY=DPC.PARTNER_CONTRACT_KEY AND DPC.SOURCE_SYSTEM_ID = 29
LEFT JOIN APP_DB_PROD.CARE_COORDINATION.CLIENT_MATCH_DEDUPE CMD ON DSRH.CLIENT_KEY=CMD.CURRENT_KEYS
LEFT JOIN APP_DB_PROD.CARE_COORDINATION.CAREGIVER_MATCH_DEDUPE CAMD ON DSRH.EMPLOYEE_KEY=CAMD.CURRENT_KEYS
WHERE SURVEY_ID IN (''SV_9R11KQoz9btyWto'',''SV_8rhFLN1ZJEdKRds'')
AND DSRH.SURVEY_RESPONSE_HEADER_KEY IN (SELECT DISTINCT SURVEY_RESPONSE_HEADER_KEY 
FROM DW_PROD.HAH.FACT_SURVEY_RESPONSE_DETAIL DETAIL 
WHERE DETAIL.SURVEY_ID in (''SV_9R11KQoz9btyWto'',''SV_8rhFLN1ZJEdKRds''));
	SELECT CONCAT (''MESSAGE : '',"number of rows inserted",'' Rows Inserted.'') into :return_result FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
	RETURN return_result;
    END;
    ';