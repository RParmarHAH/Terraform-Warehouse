CREATE OR REPLACE PROCEDURE APP_DB_PROD.PUBLIC.GET_STAGE_SANDATAIMPORT_DIM_CLIENT("STR_ETL_TASK_KEY" VARCHAR(16777216), "STR_CDC_START" VARCHAR(16777216), "STR_CDC_END" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE SQL
EXECUTE AS OWNER
AS '
DECLARE
  RETURN_RESULT VARCHAR(1000);
BEGIN       
       --*****************************************************************************************************************************
-- NAME:  SANDATAIMPORT_DIM_CLIENT
--
-- PURPOSE: Creates one row per client according to Sandata
--
-- DEVELOPMENT LOG:
-- DATE        AUTHOR                NOTES:
-- --------    -------------------   -----------------------------------------------------------------------------------------------
-- 02/13/20     Rachel Stewart         Initial Development
-- 03/18/20     Frank Noordover      Updated for Production rollout
-- 05/11/20     Frank Noordover      Updated logic for PID, DOB, Gender and Address
-- 06/15/20		Mir Ali				 Updated VISIT cte to use Fact_Visit + confirmed visits only
-- 21/12/20		Shraddha Sejpal		 Created hold_status cte to populate on_hold flag and cast nulls
-- 07/04/21     Prateek Bhatt		 Change DDL for DIM_CLIENT_DK and Cast nulls
-- 07/07/21		Mir Ali				 Added new attributes including email, fax number, salutation, and marital status
--07/11/2022    Mohan Kewlani		Added Medicaid_id column for PAHW
--*****************************************************************************************************************************

INSERT OVERWRITE INTO STAGE.SANDATAIMPORT_DIM_CLIENT
WITH VISIT AS (
    SELECT
        F.SYSTEM_CODE AS AGENCYID,
        F.CLIENT_NUMBER AS CLIENTID,
        MAX(F.SERVICE_DATE) AS LAST_TIMEOUT,
        MIN(F.SERVICE_DATE) AS FIRST_TIMEIN,
        MAX(F.ETL_LAST_UPDATED_DATE) AS ETL_LAST_UPDATED_DATE
    FROM HAH.FACT_VISIT F
	WHERE F.SYSTEM_CODE = ''8485'' AND 
 F.STATUS_CODE IN (''02'', ''03'',''04'', ''05'')
    GROUP BY 1,2
),
--added by mohan kewlani on 10-21-2022
 CA_PHW AS  (
SELECT IFF(ADMISSIONTYPE=''PHW'',1,2) AS TOD,*
FROM DISC_PROD.SANDATAIMPORT.SANDATA_CLIENTADMISSIONS WHERE AGENCYID=8485)
,
CA_CMB AS (
SELECT ROW_NUMBER() OVER (PARTITION BY T.CLIENTID ORDER BY TOD,MRN) AS RNUM,
		T.CLIENTID,
        T.AGENCYID,
        T.TOD,
        T.ADMISSIONTYPE,
        FIRST_VALUE(IFF(LENGTH (T.MRN)>0 ,LPAD(trim(t.MRN,''~''),10,''0''),'''')) OVER (PARTITION BY T.CLIENTID  ORDER BY T.TOD ASC,T.UPDATEDAT DESC) MRN,
        T.ROC AS ROC,
        t.SOC AS SOC,
		T.UPDATEDAT as UPDATEDAT,
        T.ID AS ID FROM CA_PHW T
       
        ) ,
 serv as (SELECT    
      	t.CLIENTID,
      	t.AGENCYID,
      	MIN(t.ROC) AS ROC,
     	MIN(t.SOC) AS SOC,
		MIN(t.MRN) AS MRN,
    	MAX(T.UPDATEDAT) as UPDATEDAT,
    	MAX(T.ID) AS max_ID     
      	FROM CA_CMB   t
      	GROUP BY t.CLIENTID,
     			 t.AGENCYID),
     
--serv as (
 --   SELECT
   --     t.CLIENTID,
    --    t.AGENCYID,
    --    MIN(t.ROC) AS ROC,
    --    MIN(t.SOC) AS SOC,
	--	MIN(t.MRN) AS MRN,
     --   MAX(UPDATEDAT) as UPDATEDAT,
     --   MAX(ID) AS max_ID
   -- FROM DISC_PROD.SANDATAIMPORT.SANDATA_CLIENTADMISSIONS t
   -- WHERE t.AGENCYID = 8485
   -- GROUP BY 1, 2
  --  ),

hold_status AS (
   SELECT * FROM (SELECT 
    a.CLIENTID,
    a.AGENCYID,
    a.ADMISSIONSTATUS AS STATUS_CODE,
    ETL_LAST_UPDATED_DATE,
    ROW_NUMBER() OVER (PARTITION BY CLIENTID ORDER BY ETL_LAST_UPDATED_DATE DESC) AS RN
   FROM DISC_PROD.SANDATAIMPORT.SANDATA_CLIENTADMISSIONS a 
   WHERE a.AGENCYID = 8485) WHERE RN=1
  ),
coord as (
    SELECT
        t.CLIENTID,
        t.AGENCYID,
        MAX(nvl(Coordinators.STAFFID::string, ''Unknown-'' || nvl(t.agencyID,''S''))) AS CURRENT_SUPERVISOR_CODE,
        MAX(TO_CHAR(Coordinators.LASTNAME) || '', '' || TO_CHAR(Coordinators.FIRSTNAME) || '' '' || TO_CHAR(Coordinators.MIDDLEINITIAL)) AS CURRENT_SUPERVISOR_NAME
    FROM DISC_PROD.SANDATAIMPORT.SANDATA_CLIENTADMISSIONS t
    INNER JOIN serv s
        on t.CLIENTID = s.CLIENTID
        and t.AGENCYID = s.AGENCYID
        and t.ID = s.max_ID
    LEFT JOIN DISC_PROD.SANDATAIMPORT.SANDATA_STAFFS Coordinators
        ON Coordinators.agencyID = t.agencyID
        AND Coordinators.staffID = t.CoordinatorID
    WHERE t.AGENCYID = 8485
    GROUP BY 1,2
    )
SELECT
     md5(C.AGENCYID || ''-'' || C.CLIENTID || ''-''  ||  ''SANDATAIMPORT'' ) AS CLIENT_KEY
    ,C.CLIENTID AS CLIENT_NUMBER --BK
    ,C.AGENCYID AS SYSTEM_CODE
    ,4 AS SOURCE_SYSTEM_ID
    ,md5( C.SSN) AS Client_PID
    ,c.DOB AS Client_DOB
	,NULL CLIENT_DATE_OF_DEATH 
--    ,c.Sex AS Client_Gender
    ,CASE WHEN TRIM( c.Sex) = ''1'' THEN ''MALE''
          WHEN TRIM( c.Sex) = ''2'' THEN ''FEMALE''
          ELSE NULL
     END AS Client_Gender
--	,NULL CLIENT_ETHNICITY
    ,CASE WHEN UPPER( TRIM( c.Ethnicity)) = ''NONE'' OR TRIM( c.Ethnicity) = '''' OR c.Ethnicity IS NULL THEN NULL
          WHEN TRIM( c.Ethnicity) LIKE ''Black%'' THEN ''Black or African American''
          WHEN TRIM( c.Ethnicity) LIKE ''White%'' THEN ''White''
          WHEN TRIM( c.Ethnicity) LIKE ''Asian%'' THEN ''Asian''
          WHEN TRIM( c.Ethnicity) LIKE ''Hispanic%'' THEN ''Hispanic or Latino''
          WHEN TRIM( c.Ethnicity) LIKE ''Indian%'' THEN ''Indian Sub-Continent or Pakistani''
          WHEN TRIM( c.Ethnicity) = ''American Indian or Alaskan Native (NHL)'' THEN ''American Indian or Alaskan Native''
          WHEN TRIM( c.Ethnicity) = ''Native Hawaiian or Other Pacific Islander (NHL)'' THEN ''Native Hawaiian or Pacific Islander''
          WHEN TRIM( c.Ethnicity) = ''Two or More Races (NHL)'' THEN ''Two or more races''
--          ELSE TRIM( c.Ethnicity)
          ELSE NULL
     END AS Client_Ethnicity
     ,NULLIF(TRIM(C.MARITAL), '''') AS CLIENT_MARITAL_STATUS
     ,CASE WHEN SEX = 1 THEN ''MR.'' 
			WHEN TRIM(NVL(C.TITLE, '''')) <> '''' AND TRY_CAST(C.TITLE AS INTEGER) IS NULL THEN UPPER(C.TITLE)
			WHEN SEX = 2 THEN ''MS.'' END AS CLIENT_SALUTATION
    ,c.FirstName AS Client_First_Name
    ,c.MiddleInitial AS Client_Middle_Name
    ,c.LastName AS Client_Last_Name
    ,TO_CHAR(C.LASTNAME) || '', '' || TO_CHAR(C.FIRSTNAME) || '' '' || TO_CHAR(C.MIDDLEINITIAL) AS CLIENT_NAME
    ,c.Address AS Client_Address1
    ,c.Address2 AS Client_Address2
    ,c.City AS Client_City
    ,CASE WHEN S.STATE_ISO_CODE IS NOT NULL THEN S.STATE_ISO_CODE ELSE ''PA'' END AS CLIENT_STATE_CODE
    ,c.Zip AS Client_Zip
	,NULL CLIENT_CLN_ADDRESS1
	,NULL CLIENT_CLN_ADDRESS2
	,NULL CLIENT_CLN_CITY
	,NULL CLIENT_CLN_STATE_CODE
	,NULL CLIENT_CLN_ZIP
	,NULL CLIENT_STD_ADDRESS1
	,NULL CLIENT_STD_ADDRESS2
	,NULL CLIENT_STD_CITY
	,NULL CLIENT_STD_STATE_CODE
	,NULL CLIENT_STD_ZIP
    ,c.HomePhone AS Client_Home_Phone
    ,c.MobilePhone AS Client_Cell_Phone
    ,c.WorkPhone AS Client_Work_Phone
    ,NULLIF(TRIM(C.FAX), '''') AS CLIENT_FAX_NUMBER
	,NULLIF(TRIM(C.EMAIL), '''') AS CLIENT_PERSONAL_EMAIL           
    ,serv.ROC  AS REFERRAL_DATE   
    ,datediff(day, serv.ROC, VISIT.FIRST_TIMEIN) AS DAYS_TO_SERVICE	
	,NULL CONTRACT_BEGIN_DATE     
	,NULL CONTRACT_END_DATE       
    ,VISIT.FIRST_TIMEIN AS FIRST_SERVICE_DATE
    ,COALESCE(VISIT.LAST_TIMEOUT,CASE WHEN VISIT.FIRST_TIMEIN < serv.SOC THEN VISIT.FIRST_TIMEIN ELSE serv.SOC END) AS LAST_SERVICE_DATE
    ,NULL AS BEGIN_DATE
    ,NULL AS END_DATE
    ,IFF (DATEDIFF(''day'',VISIT.LAST_TIMEOUT,CURRENT_DATE()) <= 30, ''TRUE'', ''FALSE'') AS ACTIVE_CLIENT_FLAG -- needs to change to look up last visit date
    --,CAST( NULL AS BOOLEAN) AS On_Hold_Flag
	,IFF(hold_status.STATUS_CODE =''03'',true,false) AS On_Hold_Flag
    ,CAST( NULL AS DATE) AS On_Hold_Start_Date
    ,CAST( NULL AS DATE) AS On_Hold_End_Date
	,NULL ACQUIRED_FROM_COMPANY_KEY       
	,NULL ACQUIRED_FROM_COMPANY_ID
	,NULL ACQUIRED_FROM_COMPANY_FULL_NAME
	,NULL ACQUISITION_DATE  
	,NULL ACQUISITION_FLAG                
	,NULL ADMISSION_DATE                  
	,NULL ADMISSION_FLAG     
	,CASE WHEN DAYS_TO_SERVICE <= 60 THEN 1 ELSE 0 END AS CLIENT_CONVERTED_FLAG   
	,NULL PRIMARY_SUPERVISOR_KEY          
	,NULL PRIMARY_SUPERVISOR_CODE         
	,NULL PRIMARY_SUPERVISOR_NAME         
	,NULL SECONDARY_SUPERVISOR_KEY        
	,NULL SECONDARY_SUPERVISOR_CODE
	,NULL SECONDARY_SUPERVISOR_NAME
	,NULL PRIMARY_BRANCH_KEY              
	,NULL PRIMARY_BRANCH_NAME             
	,NULL PRIMARY_BRANCH_STATE     
	,NULL GUARANTOR_NAME           
	,NULL NOTES
 	,serv.MRN AS MEDICAID_ID        
    ,TO_DATE(''1900-01-01'', ''YYYY-MM-DD'') AS EFFECTIVE_FROM_DATE
    ,TO_DATE(''9999-12-31'', ''YYYY-MM-DD'') AS EFFECTIVE_TO_DATE	    
   -- ,coord.CURRENT_SUPERVISOR_CODE AS CURRENT_SUPERVISOR_CODE
   -- ,coord.CURRENT_SUPERVISOR_NAME AS CURRENT_SUPERVISOR_NAME 
    --- ETL FIELDS ---
    ,-1 AS ETL_TASK_KEY
	,-1 AS ETL_INSERTED_TASK_KEY
    ,convert_timezone(''UTC'', CURRENT_TIMESTAMP)::timestamp_ntz as ETL_INSERTED_DATE
    ,CURRENT_USER as ETL_INSERTED_BY 
    ,convert_timezone(''UTC'', CURRENT_TIMESTAMP)::timestamp_ntz as ETL_LAST_UPDATED_DATE
    ,CURRENT_USER as ETL_LAST_UPDATED_BY
    ,0 as ETL_DELETED_FLAG
    ,0 AS ETL_INFERRED_MEMBER_FLAG
FROM DISC_PROD.SANDATAIMPORT.SANDATA_CLIENTS C
LEFT JOIN VISIT
    ON VISIT.AGENCYID = C.AGENCYID
    AND VISIT.CLIENTID = C.CLIENTID
LEFT JOIN serv serv
    ON serv.AGENCYID = C.AGENCYID
    AND serv.CLIENTID = C.CLIENTID
LEFT JOIN coord coord
        ON coord.AGENCYID = C.AGENCYID
    AND coord.CLIENTID = C.CLIENTID
LEFT JOIN hold_status
    ON hold_status.AGENCYID = C.AGENCYID
    AND hold_status.CLIENTID = C.CLIENTID
LEFT JOIN HAH.DIM_STATE S ON S.STATE_ISO_CODE=UPPER(TRIM(C.STATE))
WHERE C.AGENCYID = 8485
AND (C.ETL_LAST_UPDATED_DATE >= :STR_CDC_START::timestamp_ntz OR 
hold_status.ETL_LAST_UPDATED_DATE >= :STR_CDC_START::timestamp_ntz OR 
VISIT.ETL_LAST_UPDATED_DATE >= :STR_CDC_START::timestamp_ntz);
	SELECT CONCAT (''MESSAGE : '',"number of rows inserted",'' Rows Inserted.'') into :return_result FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));
	RETURN return_result;
    END;
    ';