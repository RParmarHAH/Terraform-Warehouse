create or replace view APP_DB_PROD.BROADSPIRE.VW_BROADSPIRE_WEEKLY_REPORT(
	SYSTEM_CODE,
	OFFICE_CODE,
	SOURCE_SYSTEM_ID,
	SYSTEM_DESCRIPTION,
	EMPLOYEE_KEY,
	CLIENT_ID,
	LAST_NAME,
	FIRST_NAME,
	MIDDLE_INIT,
	SSNO,
	DOB,
	GENDER,
	HIRE_DATE,
	EFFECTIVE_HIRE_DATE,
	MARITAL_STATUS,
	MAILING_ADDRESS_1,
	MAILING_ADDRESS_2,
	MAILING_ADDRESS_3,
	MAILING_CITY,
	MAILING_STATE,
	MAILING_ZIP_CODE,
	MAILING_ZIP_LAST_FOUR,
	COUNTRY,
	HOME_PHONE,
	BUSINESS_PHONE,
	PERSONAL_EMAIL,
	BUSIENSS_EMAIL,
	EMP_ID,
	UF,
	UNION_EMPLOYEE,
	UNION_NAME,
	JOB_TITLE,
	DEPARTMENT_NAME,
	LOCATION_CODE,
	WORK_STATE,
	EMPLOYER_CONTACT_NAME,
	EMPLOYER_CONTACT_PHONE,
	EMPLOYER_CONTACT_EMAIL,
	FLSA_STATUS,
	HOURS_SCHEDULED,
	PAYROLL_FREQUENCY,
	WAGES,
	WAGE_EFFECTIVE_DATE,
	WAGE_PERIOD,
	EMPLOYMENT_STATUS,
	EMPLOYEE_CLASSIFICATION,
	KEY_EMPLOYEE_FLAG,
	EMPLOYEE_PAY_GROUP,
	MOBILE_PHONE,
	SENIORITY,
	BONUS_AMOUNT,
	BONUS_UNIT,
	TOTAL_HOURS,
	CAL_HIREDATE,
	CAL_TERMDATE,
	IS_ACTIVE,
	MONTHS_OF_SERVICE,
	TERMINATION_REASON,
	TERMINATION_DATE,
	DEPARTURE_DATE,
	PREV_DEPARTURE_DATE,
	PREV_HIRE_DATE,
	DIVISION,
	WEEKLY_HOURS_WORKED,
	SPOUSE_EMPLOYEE_ID,
	SUPERVISOR_EMPLOYEE_ID,
	BENEFIT_IDENTIFICATION,
	LOCATION_NAME,
	POLICY,
	DIVISION_NAME,
	HR_REPRESENTATIVE_EMPLOYEEID,
	EMPLOYEE_TYPE,
	JOB_CODE,
	ADDITIONAL_COMMUNICATION_3,
	ADDITIONAL_COMMUNICATION_4,
	ADDITIONAL_COMMUNICATION_5,
	BUSINESS_REGION,
	BUSINESS_ORG,
	SECOND_HR_REPRESENTATIVE_EMPLOYEEID,
	ENTITY_DESCRIPTION,
	NCCI_JOB_CLASS_CODE,
	PAYROLL_FILE,
	BAD_DATA_FLAG,
	COMMENTS,
	CATEGORY,
	ACTIVE_EMPLOYEE_FLAG
) as
SELECT DISTINCT
 BSI.system_code,BSI.officecode,
 BSI.source_system_id,
 BSI.SYSTEM_DESCRIPTION,
 BSI.EMPLOYEE_KEY,
 BSI.client_Id , 
 BSI.last_name, 
 BSI.first_name, 
 BSI.middle_init, 
 BSI.ssno ,
 TO_VARCHAR( BSI.birth_date::DATE, 'YYYYMMDD') as dob,
 BSI.gender,
 TO_VARCHAR(BSI.original_hire_date::DATE, 'YYYYMMDD') as hire_date, 
 TO_VARCHAR(BSI.latest_hire_date :: DATE , 'YYYYMMDD') as effective_hire_date,
 BSI.marital_status, 
 SUBSTR(BSI.mailing_address_1,0,49) as mailing_address_1, 
 BSI.mailing_address_2,
 BSI.mailing_address_3,
 BSI.mailing_city,
 BSI.mailing_state, 
 BSI.mailing_zip_code, 
 BSI.mailing_zip_last_four, 
 BSI.country ,
 BSI.home_phone, 
 BSI.business_phone, 
 BSI.personal_email, 
 BSI.busienss_email, 
 BSI.emp_Id,
 BSI.uf,
 BSI.union_employee, 
 BSI.union_name, 

 BSI.job_title, 
 BSI.department_name , 
 BSI.location_code , 
 BSI.workstate, 
 BSI.employer_contact_Name, 
 BSI.employer_contact_Phone, 
 BSI.employer_contact_Email, 
 BSI.FLSA_status,
 CASE WHEN BSI.pay = 'SALARY' THEN 40 ELSE BSI.work_hours_scheduled END AS hours_scheduled ,
 BSI.payroll_frequency , 
 ROUND(BSI.wages,0) as wages, 
 TO_VARCHAR(BSI.wage_effective_date ::DATE ,'YYYYMMDD') as wage_effective_date,
 BSI.wage_period, 
 BSI.employment_status,
 BSI.employee_classification, 
 BSI.key_employee_flag,
 BSI.employee_pay_group, 
 BSI.mobile_phone, 
 BSI.seniority,
 ROUND(BSI.bonus_amount,2) as bonus_amount,
 BSI.bonus_unit, -- AS "Bonus Unit",
 ROUND(BSI.total_hours_worked,2) as total_hours, 
 BSI.cal_hiredate,
 BSI.cal_termdate,
 is_active,
 ROUND(BSI.months_of_service,2) as months_of_service ,
 BSI.termination_reason, 
 TO_VARCHAR(BSI.termination_date ::DATE ,'YYYYMMDD') as termination_date,
 TO_VARCHAR( BSI.departure_date :: DATE ,'YYYYMMDD') as departure_date,
 TO_VARCHAR( BSI.previous_departure_date ::DATE ,'YYYYMMDD') as prev_departure_date,
  TO_VARCHAR( BSI.previous_hire_date ::DATE ,'YYYYMMDD') as prev_hire_date,
 BSI.division, 
 ROUND(BSI.weekly_hours_worked,2) as weekly_hours_worked,
 BSI.spouse_employee_id, 
 BSI.supervisor_employee_id, 
 BSI.benefit_identification, 
 BSI.location_name, 
 BSI.policy, 
 BSI.division_name, 
 BSI.HR_representative_employeeid,
 BSI.employee_type, 
 BSI.job_code, 
 BSI.additional_communication_3,
 BSI.additional_communication_4, 
 BSI.additional_communication_5, 
 BSI.business_region, 
 BSI.business_org, 
 BSI.second_HR_representative_employeeId,
 BSI.entity_description,
 BSI.NCCI_job_class_code, 
 BSI.payroll_file,
 BSI.bad_data_flag,
 BSI.comments,
 BSI.cat,
BSI.ACTIVE_EMPLOYEE_FLAG

FROM (  

WITH MAX_DATE AS 
(
	SELECT ROW_NUMBER() OVER(PARTITION BY EMPLOYEE_KEY ORDER BY PAY_PERIOD_START_DATE DESC) AS RANK,
		   EMPLOYEE_KEY, PAY_PERIOD_START_DATE ,PAYROLL_DATE
	FROM DW_PROD.INTEGRATION.FACT_PAYROLL_MERGED
	QUALIFY RANK = 1 
),
  

HIRE_DATE AS
(
SELECT distinct EMPLOYEE_KEY,
		EMPLOYEE_ID, GREATEST(DERIVED_EMPLOYEE_HIRE_DATE::DATE, EMPLOYEE_HIRE_DATE::DATE, IFF(EMPLOYEE_REHIRE_DATE IS NULL,'01/01/1900' , EMPLOYEE_REHIRE_DATE), 
                              IFF(DERIVED_EMPLOYEE_REHIRE_DATE IS NULL,'01/01/1900' ,  DERIVED_EMPLOYEE_REHIRE_DATE)) as HIRE_DATE
   FROM DW_PROD.INTEGRATION. DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE WHERE SOURCE_SYSTEM_ID IN (5,6,10) 
),

  
ANNUAL_TOTAL_HOURS AS 
	(
		SELECT  distinct  pay.EMPLOYEE_ID,HEX_DECODE_STRING( emp.EMPLOYEE_PID) AS SSN,
			   SUM(GREATEST(NVL(pay.PAY_HOURS, 0), NVL(pay.SERVICE_HOURS, 0), NVL(pay.OVERTIME_HOURS, 0))
			     + GREATEST( NVL( pay.SICK_HOURS, 0), NVL( pay.VACATION_HOURS, 0))) AS TOTAL_HOURS
		FROM DW_PROD.INTEGRATION.FACT_PAYROLL_MERGED AS pay
        Inner join (SELECT * FROM DW_PROD.INTEGRATION. DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE WHERE  SOURCE_SYSTEM_ID IN (5,6,10) ) emp
		--ON (pay.EMPLOYEE_KEY) = (emp.EMPLOYEE_KEY) 
			ON TRIM(pay.EMPLOYEE_ID) = TRIM(emp.EMPLOYEE_ID)
			AND  pay.PAYROLL_DATE  >= ADD_MONTHS(current_date, -12)
		GROUP BY 1 ,2
	),
    
 WEEKLY_HOURS AS 
	(
	      
    SELECT DISTINCT 
		PAY.EMPLOYEE_KEY,
		PAY.EMPLOYEE_ID,
		SUM ( NVL(pay.SERVICE_HOURS , 0)+ NVL(pay.NON_SERVICE_UNITS, 0)) --SUM(GREATEST(NVL(pay.PAY_HOURS, 0), NVL(pay.SERVICE_HOURS, 0))+ NVL(pay.OVERTIME_HOURS, 0))
			 AS WEEK_HOURS
	FROM DW_PROD.INTEGRATION.FACT_PAYROLL_MERGED PAY
	WHERE PAY.PAYROLL_DATE >= DATEADD(DAY, -7, CURRENT_DATE()) AND SOURCE_SYSTEM_ID IN (5,6,10) 
	GROUP BY 1, 2
  
	),
    
UNION_FLAG AS (
  
  SELECT DISTINCT 
		EMP.EMPLOYEE_KEY,
		EMP.EMPLOYEE_ID,
		CASE WHEN EMP.SOURCE_SYSTEM_ID = 5 AND WORK_STATE IN ('IL') AND UPPER(EMPLOYEE_CATEGORY) NOT LIKE '%ADMIN%' THEN TRUE
			WHEN EMP.SOURCE_SYSTEM_ID = 5 AND WORK_STATE IN ('IN') AND MAX_DATE.PAY_PERIOD_START_DATE >= DATEADD(DAY, -90, CURRENT_DATE()) AND UPPER(EMPLOYEE_CATEGORY) NOT LIKE '%ADMIN%' THEN TRUE
			ELSE FALSE
		END AS UNION_FLAG,
		CASE WHEN EMP.SOURCE_SYSTEM_ID = 5 AND WORK_STATE IN ('IL') AND UPPER(EMPLOYEE_CATEGORY) NOT LIKE '%ADMIN%' THEN 'ILU'
			WHEN EMP.SOURCE_SYSTEM_ID = 5 AND WORK_STATE IN ('IN') AND MAX_DATE.PAY_PERIOD_START_DATE >= DATEADD(DAY, -90, CURRENT_DATE()) AND UPPER(EMPLOYEE_CATEGORY) NOT LIKE '%ADMIN%' THEN 'INU'
		END AS UNION_NAME
	FROM DW_PROD.INTEGRATION.DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE EMP
	LEFT JOIN MAX_DATE
		ON MAX_DATE.EMPLOYEE_KEY = EMP.EMPLOYEE_KEY
)  ,
  

STATUS AS (
	SELECT DISTINCT 
		EMPLOYEE_KEY,
		CASE WHEN (UPPER(EMP.JOB_TITLE) LIKE ANY('%NURSE%', 'LPN%', 'RN%', '%LPN', '%RN', 'PTA%', '%PTA', 'PT%', '%PT') 
			OR UPPER(EMP.JOB_DESCRIPTION) LIKE ANY('%NURSE%', 'LPN%', 'RN%', '%LPN', '%RN', 'PTA%', '%PTA', 'PT%', '%PT')
			OR EMP.EMPLOYEE_CATEGORY ILIKE ANY ('%ADMIN%', '%CORP%') OR EMP.CLASS_ID ILIKE '%EXEMPT%') -- ADMINS
		THEN 'ADMIN'
       	WHEN UPPER(EMP.EMPLOYEE_CATEGORY) IN ('FIELD') THEN 'FIELD'
		ELSE NULL
		END AS EMPLOYEE_STATUS
	FROM DW_PROD.INTEGRATION.DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE EMP 
) ,
    
  
TOTAL_MONTHS_WORKED AS (
   
	SELECT distinct empm.SYSTEM_CODE as SYCD,EMPLOYEE_KEY, empm.EMPLOYEE_ID ,
     COALESCE(empm.DERIVED_EMPLOYEE_REHIRE_DATE,empm.DERIVED_EMPLOYEE_HIRE_DATE), COALESCE (CASE WHEN To_Varchar(empm.DERIVED_EMPLOYEE_TERMINATE_DATE) = '1753-01-01' THEN NULL ELSE empm.DERIVED_EMPLOYEE_TERMINATE_DATE END ,CURRENT_DATE),
	 ROUND( DATEDIFF( MONTH, COALESCE(empm.DERIVED_EMPLOYEE_REHIRE_DATE,empm.DERIVED_EMPLOYEE_HIRE_DATE), COALESCE (CASE WHEN To_Varchar(empm.DERIVED_EMPLOYEE_TERMINATE_DATE) = '1753-01-01' THEN NULL ELSE empm.DERIVED_EMPLOYEE_TERMINATE_DATE END ,CURRENT_DATE)))
			 AS months_worked
	
	FROM  DW_PROD.INTEGRATION. DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE empm where ACTIVE_EMPLOYEE_FLAG = true and empm.SOURCE_SYSTEM_ID IN (5,6,10) 
		
    group by 1,2,3,4,5,6 order by months_worked
),
  
US_STATE AS
  (
    SELECT  E.EMPLOYEE_STATE_CODE,  E.EMPLOYEE_CITY,    E.EMPLOYEE_ZIP,    GEO.ZIP_CODE,    GEO.CITY_PRIMARY_NAME,    GEO.STATE_NAME,    GEO.STATE_ISO_CODE
    FROM     DW_PROD.INTEGRATION.DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE E LEFT JOIN DW_PROD.HAH.DIM_GEOGRAPHY GEO ON     LEFT(E.EMPLOYEE_ZIP,    5) = GEO.ZIP_CODE    AND GEO.ZIP_IS_ACTIVE = TRUE  
  ),
  
DISC_EMP_ADDRESS AS
  
  (
  select SSN ,ADDRESS1,CITY,STATE,ZIP from DISC_PROD.GPSYNCDATA.GPALLEMPLOYEESBASE
  union
  select EMPLOYEE_SSN as SSN,EMPLOYEE_ADDRESS1 as ADDRESS1,EMPLOYEE_CITY as CITY,EMPLOYEE_STATE_CODE as STATE,EMPLOYEE_ZIP as ZIP from  DISC_PROD.TRUSTPOINTDATA.EMPLOYEES where ACTIVE_EMPLOYEE_FLAG = TRUE
  union    
  select replace(SSN,'-','') as SSN, HOMEADDRESS_ADDRESS1 as ADDRESS1,HOMEADDRESS_CITY as CITY,HOMEADDRESS_STATE as STATE,HOMEADDRESS_POSTALCODE as ZIP from DISC_PROD.PAYLOCITY.EMPLOYEE_DETAILS
  ),
  
TP_LOCATIONCODE_ERROR AS
  (
//  SELECT DISTINCT EMPLOYEE_SSN AS SSN ,REPLACE(REPLACE(UPPER(p.BRANCH_NAME ),E.company,''),'-','') AS LOCATION FROM  DISC_PROD.TRUSTPOINTDATA.EMPLOYEES e
//  LEFT OUTER JOIN DISC_PROD.TRUSTPOINTDATA.HIST_PAYROLL p ON e.EMPLOYEE_NUMBER = p.EMPLOYEE_ID WHERE 
//  EMPLOYEE_SSN IN ( SELECT SSN FROM  APP_DB_PROD.BROADSPIRE.VW_BSI_ERROR_STATUS WHERE "Error status" LIKE '%Not%' AND "Comment" LIKE 'Missing Location Code') AND BRANCH_NAME IS NOT null 
  SELECT DISTINCT e.EMPLOYEE_SSN AS SSN ,EMPLOYEE_OFFICE_NUMBER, p.BRANCH_NAME as LOCATION_NAME  FROM  DISC_PROD.TRUSTPOINTDATA.EMPLOYEES e
  LEFT OUTER JOIN DISC_PROD.TRUSTPOINTDATA.PAYROLL p ON e.EMPLOYEE_NUMBER = p.EMPLOYEE_ID WHERE 
  EMPLOYEE_SSN IN (SELECT DISTINCT  HEX_DECODE_STRING(EMPLOYEE_PID) FROM DW_PROD.INTEGRATION. DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE e
  LEFT OUTER JOIN DW_PROD.HAH.DIM_BRANCH b ON e.PRIMARY_BRANCH_KEY=B.BRANCH_KEY
    
  WHERE  E.SOURCE_SYSTEM_ID IN (6) AND (ACTIVE_EMPLOYEE_FLAG = TRUE or EMPLOYEE_TERMINATE_DATE >= DATEADD(DAY,-30,CURRENT_DATE())) AND  B.BRANCH_KEY IS NULL) 
  AND (BRANCH_NAME IS NOT null OR UPPER(BRANCH_NAME) NOT LIKE '%UNKNOWN%')
    
      union all
  
  SELECT DISTINCT e.EMPLOYEE_SSN AS SSN ,EMPLOYEE_OFFICE_NUMBER, p.BRANCH_NAME as LOCATION_NAME  FROM  DISC_PROD.TRUSTPOINTDATA.EMPLOYEES e
  LEFT OUTER JOIN DISC_PROD.TRUSTPOINTDATA.PAYROLL p ON e.EMPLOYEE_NUMBER = p.EMPLOYEE_ID WHERE 
  EMPLOYEE_SSN IN (select SSN from "APP_DB_PROD"."BROADSPIRE"."VW_BSI_ERROR_STATUS" where "Error status" like '%Not%' and "Comment" like '%Location Code%')
  
  )

select distinct
emp.System_Code,
ss.SYSTEM_DESCRIPTION,
emp.EMPLOYEE_KEY,
emp.SOURCE_SYSTEM_ID ,
'HAH' AS client_Id,  --1
emp.Employee_Last_Name AS last_name,--2
emp.Employee_First_Name AS first_name, --3

TRANSLATE(LEFT( TRIM( EMPLOYEE_MIDDLE_NAME), 1),'`'',1234567890+.!@#$%^&*()-','') AS middle_init,--4
 RIGHT( '000000000'||REPLACE( TRIM( HEX_DECODE_STRING( emp.EMPLOYEE_PID)),'-',''),9) AS ssno,--5  
emp.EMPLOYEE_DOB AS birth_date,--6
CASE WHEN UPPER( TRIM( emp.EMPLOYEE_GENDER)) IN ('M','MALE') THEN 'M'
	 WHEN UPPER( TRIM( emp.EMPLOYEE_GENDER)) IN ('F','FEMALE') THEN 'F'
     ELSE 'U' END AS gender, --7
COALESCE(DERIVED_EMPLOYEE_HIRE_DATE, EMPLOYEE_HIRE_DATE)::DATE  AS original_hire_date, --8


COALESCE(EMP.EMPLOYEE_REHIRE_DATE, 
						CASE WHEN EMP.EMPLOYEE_BENEFIT_START_DATE <> EMP.EMPLOYEE_HIRE_DATE  AND EMP.EMPLOYEE_BENEFIT_START_DATE < CURRENT_DATE() THEN EMP.EMPLOYEE_BENEFIT_START_DATE ELSE NULL END,
						DERIVED_EMPLOYEE_HIRE_DATE, 
						EMP.EMPLOYEE_HIRE_DATE
						)::DATE
AS latest_hire_date,

CASE WHEN UPPER(emp.EMPLOYEE_MARITAL_STATUS) = 'SINGLE' THEN 'S'
     WHEN UPPER(emp.EMPLOYEE_MARITAL_STATUS) = 'MARRIED' THEN 'M'
     WHEN UPPER(emp.EMPLOYEE_MARITAL_STATUS) = 'DIVORCED,' THEN 'D'
     WHEN UPPER(emp.EMPLOYEE_MARITAL_STATUS) = 'WIDOWED,' THEN 'W'
     WHEN UPPER(emp.EMPLOYEE_MARITAL_STATUS) = 'SEPARATED,' THEN 'E'
  ELSE 'U' END AS marital_status,  --10
 
COALESCE(emp.EMPLOYEE_ADDRESS1,ad.ADDRESS1,b.OFFICE_ADDRESS1,'33 S. State St.') AS mailing_address_1, --11

emp.EMPLOYEE_ADDRESS2 AS mailing_address_2, --12
NULL AS mailing_address_3, --13
COALESCE(TRANSLATE(emp.EMPLOYEE_CITY,'.!@#$%^&*()-',''),ad.CITY,B.OFFICE_CITY,'CHICAGO')  AS mailing_city, --14
CASE WHEN emp.EMPLOYEE_STATE_CODE  IS NULL THEN zip.STATE_ISO_CODE ELSE emp.EMPLOYEE_STATE_CODE   END AS mailing_state,--15
COALESCE(emp.EMPLOYEE_ZIP,ad.ZIP, b.OFFICE_ZIP,'60603') AS mailing_zip_code, --16 

NULL as mailing_zip_last_four, --17
'USA' AS country, --18
  

COALESCE( NULLIF( emp.EMPLOYEE_HOME_PHONE,''), NULLIF( emp.EMPLOYEE_CELL_PHONE,'')) AS home_phone, --19
NULLIF( emp.EMPLOYEE_WORK_PHONE,'') AS business_phone, --20

CASE WHEN NULLIF( emp.EMPLOYEE_PERSONAL_EMAIL,'') NOT LIKE '%@%' THEN NULL
		 ELSE NULLIF( emp.EMPLOYEE_PERSONAL_EMAIL,'')
		END AS personal_email, --21
        
CASE WHEN  NULLIF( emp.EMPLOYEE_WORK_EMAIL,'') NOT LIKE '%@%' THEN NULL
		 ELSE COALESCE( emp.EMPLOYEE_WORK_EMAIL,personal_email)
		END AS busienss_email,--22
  
CASE WHEN emp.SYSTEM_CODE  = 'HAHIL' THEN 'HAHIL'
      WHEN emp.SYSTEM_CODE  ='ILL'	THEN 'ILL'
      WHEN emp.SYSTEM_CODE  ='MICH' THEN 'MICH'
      WHEN emp.SYSTEM_CODE  ='STW'	THEN 'STW'
      WHEN emp.SYSTEM_CODE  ='ALTRUS' THEN 'ALTRS'
      WHEN emp.SYSTEM_CODE  ='ANSWERCARE' THEN 'ANSWR'
      WHEN emp.SYSTEM_CODE  ='COASTAL' THEN 'COASTL'
      WHEN emp.SYSTEM_CODE  ='E3' THEN 'E3' 
      WHEN emp.SYSTEM_CODE  ='EXCEL' THEN 'EXCEL'
      WHEN emp.SYSTEM_CODE  ='HAHMI' THEN 'HAHMI' 
      WHEN emp.SYSTEM_CODE  ='PRIME' THEN 'PRM' 
      WHEN emp.SYSTEM_CODE  ='PRIMEHHA' THEN 'PRMHHA' 
      WHEN emp.SYSTEM_CODE  ='PRIMEMIDWAY' THEN 'PRMMID' 
      WHEN emp.SYSTEM_CODE  ='33978' THEN 'HOSP'
      WHEN emp.SYSTEM_CODE  ='B6150' THEN 'ADAPTV'
      WHEN emp.SYSTEM_CODE  ='ADP-ALLIANCE'	 THEN 'ADPALN'
      WHEN emp.SYSTEM_CODE  ='ADP-OPAL-ESH'	 THEN 'ADPOPE'
      WHEN emp.SYSTEM_CODE  ='NYL'	 THEN 'ADPNYL' 
      WHEN emp.SYSTEM_CODE  ='NAVISION'	 THEN 'NVSN' 
      WHEN emp.SYSTEM_CODE  ='EMPEONEDISON-3795' THEN 'EDSN95' 
      WHEN emp.SYSTEM_CODE  ='EMPEONEDISON-3795D' THEN 'EDSN95D' 
      WHEN emp.SYSTEM_CODE  ='EMPEONEDISON-3795O' THEN 'EDSN95O' 
      WHEN emp.SYSTEM_CODE  ='EMPEONPREFERRED-3806'	THEN 'PREF06' 
      WHEN emp.SYSTEM_CODE  ='EMPEONPREFERRED-3806A' THEN 'PREF06A' 
      WHEN emp.SYSTEM_CODE  ='EMPEONPREFERRED-3806F' THEN 'PREF06F' 
      WHEN emp.SYSTEM_CODE  ='EMPEONPREFERRED-7051E' THEN 'PREF51E'
      WHEN emp.SYSTEM_CODE  ='CARECOORDINATION' THEN 'CC' 
      WHEN emp.SYSTEM_CODE  ='HAHDELAWARE' THEN 'HAHDE'
      WHEN emp.SYSTEM_CODE  ='ADP-OPAL-9WA'	 THEN 'ADPOPW' END as system_pref,


  
(LEFT(TRIM(emp.EMPLOYEE_FIRST_NAME), 1)||RIGHT( TRIM(TO_VARCHAR( birth_date::DATE, 'YYYYMMDD')), 5) ||RIGHT( HEX_DECODE_STRING(TRIM(emp.EMPLOYEE_PID)), 5)) as emp_ID,
 
UPPER(EMP.EMPLOYEE_CATEGORY) as  cat,
CASE WHEN NULLIF( emp.JOB_TITLE,'') IS NULL AND NULLIF( emp.JOB_DESCRIPTION,'') IS NOT NULL THEN TRIM( emp.JOB_DESCRIPTION)
		 WHEN NULLIF( emp.JOB_DESCRIPTION,'') IS NULL AND NULLIF( emp.JOB_TITLE,'') IS NOT NULL THEN TRIM( emp.JOB_TITLE)
         WHEN UPPER(EMP.EMPLOYEE_CATEGORY) IN ('FIELD') and (EMP.JOB_TITLE is null or EMP.JOB_DESCRIPTION is null)  THEN 'Caregiver'
         WHEN UPPER(EMP.EMPLOYEE_CATEGORY) IN ('ADMIN') and (EMP.JOB_TITLE is null or EMP.JOB_DESCRIPTION is null)  THEN 'Admin'
		 ELSE TRIM( emp.JOB_TITLE) || ' - ' || TRIM( emp.JOB_DESCRIPTION)
		END AS job_title, --26
  
uf.UNION_FLAG as uf ,

CASE WHEN STATUS.EMPLOYEE_STATUS = 'ADMIN' THEN 0
       WHEN uf.UNION_FLAG = true then 1
		ELSE 0
	END AS union_employee, 
  
CASE WHEN STATUS.EMPLOYEE_STATUS = 'ADMIN' THEN NULL
		ELSE uf.UNION_NAME 
	END AS union_name,
           
NULL AS Department_Name,--27   

COALESCE(TO_CHAR( b.OFFICE_CODE),TO_CHAR(emp.EMPLOYEE_OFFICE_CODE)) AS officecode, 
  
 CASE 
    WHEN ssno IN ('303988112','305667076') THEN 'ADAPTV-4'
  WHEN ssno IN ('307961964') THEN 'ADAPTV-5'
  WHEN ssno IN ('313151383')THEN 'ADAPTV-2'
  WHEN TRIM(system_pref) = 'CC' THEN Concat(system_pref,REPLACE(b.BRANCH_NAME,'E3 - CCU ','') ,'-',TRANSLATE(officecode,'!@#$%^&*()-',''))
  WHEN TRIM(system_pref) = 'PRMHHA' THEN Concat(system_pref,substr(b.BRANCH_NAME,7,1) ,'-',TRANSLATE(officecode,'!@#$%^&*()-',''))
  WHEN TRIM(system_pref) = 'PRMMID' and officecode ='106' THEN Concat(system_pref,substr(b.BRANCH_NAME,10,1) ,'-',TRANSLATE(officecode,'!@#$%^&*()-',''))
  WHEN B.BRANCH_KEY IS NULL THEN Concat(system_pref,'-',COALESCE(ER.EMPLOYEE_OFFICE_NUMBER,emp.EMPLOYEE_OFFICE_CODE))
  ELSE Concat(system_pref,'-',TRANSLATE(officecode,'!@#$%^&*()-','')) END AS Location_Code, --28
  
TRIM(b.REGION_NAME) as location_Region,  
  
CASE WHEN emp.SOURCE_SYSTEM_ID IN (10)  THEN 'IN'
     WHEN ssno IN  ('066506271','048945977','131709678','044908725','096801200','066720220') THEN 'NY'
     ELSE TRIM(emp.WORK_STATE) END AS workstate,--29 2 charactor abbreviation

NULL AS Employer_Contact_Name, --30 leave blank
NULL as Employer_Contact_Phone,--31
NULL AS Employer_contact_Email,--32
   
CASE WHEN UPPER( TRIM( emp.CLASS_ID)) = 'EXEMPT' THEN 'E' ELSE 'N'	END AS FLSA_status, --33
    
CASE WHEN emp.EMPLOYEE_CATEGORY IN ('Corp','Admin') THEN '40' ELSE NULL END /* NVL( ROUND( ah.WEEK_HOURS,2), 0)*/ AS work_hours_scheduled,--34

'WEEKLY' AS Payroll_Frequency ,--35

CASE WHEN UPPER( TRIM( emp.CLASS_ID)) = 'EXEMPT' THEN 'SALARY' ELSE 'HOURLY' END AS pay,
--wg.WAGE  AS "Wage",--36
NULL  AS wages,--36
        
NULL AS wage_effective_date, --37
NULL AS wage_period, --38
  
NVL( ROUND( ah.WEEK_HOURS,2), 0) AS scheduled_hrs,
CASE --status.EMPLOYEE_STATUS = 'ADMIN' THEN '1'
  WHEN UPPER(emp.EMPLOYEE_TYPE) LIKE '%FULL TIME%'  THEN '1'
        WHEN  UPPER(emp.EMPLOYEE_TYPE) LIKE '%PART TIME%'OR UPPER(emp.EMPLOYEE_TYPE) ='PRN' THEN '2'
        WHEN  UPPER(emp.EMPLOYEE_TYPE) in ('TEMPORARY') THEN '8' 
        WHEN  UPPER(emp.EMPLOYEE_TYPE) in ('INTERN') THEN 'A' --exclude intern
        WHEN (emp.EMPLOYEE_TYPE IS NULL or UPPER(emp.EMPLOYEE_TYPE) ='') AND status.EMPLOYEE_STATUS = 'ADMIN' THEN '1' --Fulltime , --39
        WHEN (emp.EMPLOYEE_TYPE IS NULL or UPPER(emp.EMPLOYEE_TYPE) ='') AND scheduled_hrs < 30 THEN '2' 
        WHEN (emp.EMPLOYEE_TYPE IS NULL or UPPER(emp.EMPLOYEE_TYPE) ='') AND scheduled_hrs > 30 THEN '1' END
             AS Employee_classification, --39
  
NULL AS key_employee_flag,--40
NULL AS employee_pay_group,--41
emp.EMPLOYEE_CELL_PHONE AS mobile_phone,--42
NULL AS seniority,--43  
NULL AS bonus_amount,--44
NULL AS bonus_unit,--45

CASE   
  WHEN emp.ACTIVE_EMPLOYEE_FLAG = TRUE AND DATEDIFF( DAY, emp.EMPLOYEE_LAST_CHECK_DATE::DATE, CURRENT_DATE()) < 60 THEN 'A'
  WHEN emp.ACTIVE_EMPLOYEE_FLAG = TRUE AND /* emp.EMPLOYEE_LAST_CHECK_DATE */tdt.LAST_PAY_DATE <  dateadd(day, -30, current_date) THEn 'T'
  WHEN emp.ACTIVE_EMPLOYEE_FLAG = FALSE THEN 'T'
  WHEN COALESCE(DERIVED_EMPLOYEE_TERMINATE_DATE, EMPLOYEE_TERMINATE_DATE) IS NOT NULL then 'T'
  WHEN COALESCE(DERIVED_EMPLOYEE_TERMINATE_DATE, EMPLOYEE_TERMINATE_DATE,CURRENT_DATE()) = CURRENT_DATE  then 'A'
  ELSE 'A'	END AS employment_status,
  
  
CASE WHEN employment_status = 'A' and employee_classification = '1' THEN 1250 
  WHEN employment_status = 'A' and employee_classification = '2' THEN 1 ELSE NULL END   AS total_hours_worked,--46

hd.HIRE_DATE as cal_hiredate,
  
COALESCE(DERIVED_EMPLOYEE_TERMINATE_DATE, EMPLOYEE_TERMINATE_DATE /*, CURRENT_DATE()*/) as cal_termdate,

  
CASE WHEN employment_status = 'T' THEN emp.REASON_TO_TERMINATE ELSE NULL END AS termination_reason,--48

CASE WHEN emp.EMPLOYEE_TERMINATE_DATE::DATE > CURRENT_DATE THEN NULL
  WHEN employment_status = 'T' and emp.EMPLOYEE_TERMINATE_DATE::DATE is not null THEN emp.EMPLOYEE_TERMINATE_DATE::DATE
  WHEN employment_status = 'T' and emp.EMPLOYEE_TERMINATE_DATE::DATE is  null THEN   COALESCE(DERIVED_EMPLOYEE_TERMINATE_DATE, EMPLOYEE_TERMINATE_DATE)
  WHEN  COALESCE(DERIVED_EMPLOYEE_TERMINATE_DATE, EMPLOYEE_TERMINATE_DATE) is not null then  COALESCE(DERIVED_EMPLOYEE_TERMINATE_DATE, EMPLOYEE_TERMINATE_DATE)
  --WHEN  tdt.LAST_PAY_DATE  >= dateadd(day, -30, current_date ) THEN   tdt.LAST_PAY_DATE ::DATE   
   WHEN employment_status = 'T' and emp.EMPLOYEE_TERMINATE_DATE::DATE is  null  and   COALESCE(DERIVED_EMPLOYEE_TERMINATE_DATE, EMPLOYEE_TERMINATE_DATE) is null then tdt.LAST_PAY_DATE ::DATE 
  --WHEN  tdt.LAST_PAY_DATE is not null then   tdt.LAST_PAY_DATE ::DATE 
  
	ELSE NULL
		END AS termination_date,--49 
        
//  DATEDIFF('MONTHS', latest_hire_date , 
//			COALESCE(termination_date, CURRENT_DATE())
//			) AS months_of_service, --47
  
CASE WHEN DATEDIFF('MONTHS', latest_hire_date , COALESCE(termination_date, CURRENT_DATE())	) >=1 THEN DATEDIFF('MONTHS', latest_hire_date , COALESCE(termination_date, CURRENT_DATE())) 
     WHEN DATEDIFF('DAY', latest_hire_date , COALESCE(termination_date, CURRENT_DATE())	) >1 and DATEDIFF('DAY', latest_hire_date , COALESCE(termination_date, CURRENT_DATE())	) <30 --and employment_status = 'A' 
      THEN 1 END AS months_of_service, --47
  
 
        NULL as departure_date,--50
case WHEN employment_status = 'T' THEN FALSE 
  when emp.ACTIVE_EMPLOYEE_FLAG = TRUE and termination_date is null  then TRUE
  WHEN COALESCE(DERIVED_EMPLOYEE_TERMINATE_DATE, EMPLOYEE_TERMINATE_DATE) IS NOT NULL then FALSE
   
  when termination_date is not null then FALSE END as is_active,
  
  emp.ACTIVE_EMPLOYEE_FLAG, 
NULL AS previous_departure_date,--51

NULL AS  previous_hire_date,--52

      
NULL /*"Status"*/ AS division,--53 --Admin/field not needed
  
CASE WHEN scheduled_hrs >168 then 168 else scheduled_hrs END as weekly_hours_worked,--54 
NULL as spouse_employee_id,--55
NULL AS supervisor_employee_id,--56

CASE WHEN status.EMPLOYEE_STATUS /* e_status*/ LIKE '%ADMIN%' THEN 'HAH Admin'
     WHEN status.EMPLOYEE_STATUS /* e_status*/ in ('FIELD') and union_employee = 1 THEN 'HAH Caregivers Union'
     WHEN status.EMPLOYEE_STATUS /* e_status*/ in ('FIELD') and union_employee = 0 THEN 'HAH Caregivers Non Union'
     ELSE NULL END AS  benefit_identification,--57
 
CASE
  WHEN SSNO IN ('303988112','305667076') THEN 'Jasper'
  WHEN SSNO IN ('307961964') THEN 'Bedford'
  WHEN SSNO IN ('313151383')THEN 'Colombus'
  WHEN TRIM(Location_Code)  = 'ALTRS-953' THEN 'COASTAL - CORE ALTRUS'
  WHEN TRIM(Location_Code)  = 'COASTL-804' THEN 'COASTAL - CORE'
  WHEN TRIM(Location_Code)  = 'COASTL-811' THEN 'COASTAL - SCL ADMIN'
  WHEN TRIM(Location_Code)  = 'COASTL-812' THEN 'COASTAL - CHC CORE - ADMIN FIELD OPS'
 WHEN B.BRANCH_NAME IS NULL THEN ER.LOCATION_NAME
ELSE TO_CHAR( b.BRANCH_NAME)	END AS location_name,--58  

'036759 HAH' as policy,--59   

NULL AS division_name,--60,
NULL AS HR_representative_employeeid, --61

CASE WHEN UPPER( TRIM( emp.CLASS_ID)) = 'EXEMPT' THEN 'SALARY'
		ELSE 'HOURLY'
		END  AS employee_type,--62
  
NULL AS job_code,--63 

NULL AS additional_communication_3,--64
NULL AS additional_communication_4,--65
NULL AS additional_communication_5,--66
  
CASE WHEN TRIM(rmp.REGION_NAME/*$2*/) IS NOT NULL THEN REPLACE(TRIM(rmp.REGION_NAME/*$2*/),' - ' ,' ')
     ELSE REPLACE(TRIM(b.REGION_NAME/*$2*/),' - ' ,' ') END AS business_region,--67 

NULL AS business_org,--68
NULL AS second_HR_representative_employeeId,--69
NULL AS entity_description,--70
NULL AS NCCI_job_class_code,--71
NULL AS payroll_file,--72

CASE WHEN  original_hire_date IS NULL THEN 1
     WHEN  ssno like '%[^0-9]%' or ssno is NULL THEN 1
     WHEN birth_date IS NULL or (birth_date :: DATE ) > DATEADD( YEAR, -17, CURRENT_DATE())  THEN 1  
     WHEN gender IS NULL then 1
     WHEN mailing_address_1 IS NULL OR Try_to_Number(EMPLOYEE_ADDRESS1) not like '[a-zA-Z]' THEN 1
     WHEN mailing_city  IS NULL or  TRY_TO_NUMBER(mailing_city) not like '%[^0-9]%' THEN 1
     WHEN mailing_state  IS NULL THEN 1
     WHEN mailing_zip_code IS NULL THEN 1
     WHEN emp_Id IS NULL THEN 1
     WHEN location_code  IS NULL or location_code = '-1' THEN 1
     WHEN workstate is NULL THEN 1
     WHEN employee_classification IS NULL THEN 1
     WHEN termination_date :: DATE > CURRENT_DATE THEN 1
     WHEN months_of_service is NULL or months_of_service < 1 THEN 1
     WHEN weekly_hours_worked <0 then 1
     WHEN  employment_status = 'A'and is_active = true and employee_classification in('1','2') and total_hours_worked Not in (1250,1) THEN 1
     WHEN union_employee = 1 and union_name is NULL  then 1
     WHEN TERMINATION_REASON = 'DUPLICATE' THEN 1
   --  WHEN UPPER(last_name)  like '%TEST%' or  UPPER(first_name)  like '%TEST%' THEN 1 
      ELSE 0 END AS bad_data_flag ,
  
CASE WHEN  original_hire_date IS NULL THEN 'Missing Hire date'
     WHEN  ssno like '%[^0-9]%'  THEN ('Bad SSN  : '|| ssno)
     WHEN   ssno IS NULL then 'Missing SSN'
     WHEN  birth_date IS NULL THEN 'Missing Birth date'
     WHEN (birth_date:: DATE ) > DATEADD( YEAR, -17, CURRENT_DATE()) THEN ('Invalid Birth Date : '|| birth_date)
     WHEN  gender IS NULL then 'Missing Gender'
     WHEN mailing_address_1 IS NULL OR Try_to_Number(EMPLOYEE_ADDRESS1) not like '[a-zA-Z]' THEN ('Missing Mailing Address : '|| mailing_address_1)
     WHEN mailing_city  IS NULL or  TRY_TO_NUMBER(mailing_city) not like '%[^0-9]%' THEN ('Missing/Invalid City : '|| mailing_city)
     WHEN mailing_state  IS NULL THEN 'Missing State'
     WHEN mailing_zip_code IS NULL THEN 'Missing Zipcode'
     WHEN emp_Id IS NULL THEN 'Missing Employee ID'
     WHEN location_code  IS NULL or location_code = '-1' THEN 'Missing Location Code'
     WHEN workstate is NULL THEN 'Missing Work State'
     WHEN weekly_hours_worked <0 then ('Negative weekly hours: '|| weekly_hours_worked)
     WHEN employee_classification IS NULL THEN 'Missing Employee classification'
     WHEN  termination_date :: DATE > CURRENT_DATE THEN ('Future Termination Date: '|| termination_date)
     WHEN months_of_service IS NULL or months_of_service < 1 THEN ('Invalid Month of service : '|| months_of_service)
     WHEN union_employee = 1 and union_name is NULL  then 'Missing Union Name'
    -- WHEN UPPER(last_name)  like '%TEST%' or  UPPER(first_name)  like '%TEST%' THEN 'TEST DATA'
     WHEN   employment_status = 'A' and employee_classification in('1','2') and total_hours_worked Not in (1250,1) THEN 'Invalid Total Hours Worked'
     WHEN TERMINATION_REASON = 'DUPLICATE' THEN 'Duplicate Records'
     ELSE NULL END AS comments ,
  
 EMP.ACTIVE_EMPLOYEE_FLAG  AS active
 
  
FROM  (SELECT * FROM DW_PROD.INTEGRATION. DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE WHERE  SOURCE_SYSTEM_ID IN (5,6,10)
       AND (ACTIVE_EMPLOYEE_FLAG = TRUE or EMPLOYEE_TERMINATE_DATE >= DATEADD(DAY,-30,CURRENT_DATE())) )  emp
INNER JOIN DW_PROD.INTEGRATION.FACT_PAYROLL_MERGED pay on emp.EMPLOYEE_KEY = pay.EMPLOYEE_KEY
LEFT OUTER JOIN WEEKLY_HOURS ah
		ON ah.EMPLOYEE_KEY = emp.EMPLOYEE_KEY 
LEFT OUTER JOIN DW_PROD.HAH.DIM_BRANCH b 
	ON emp.PRIMARY_BRANCH_KEY = b.BRANCH_KEY
LEFT OUTER JOIN UNION_FLAG uf
	ON uf.EMPLOYEE_KEY = emp.EMPLOYEE_KEY 
//LEFT OUTER JOIN TOTAL_MONTHS_WORKED tmw
//     ON ( emp.SYSTEM_CODE) = ( tmw.SYCD) AND emp.EMPLOYEE_KEY =tmw.EMPLOYEE_KEY 
LEFT OUTER JOIN HIRE_DATE hd
  ON hd.EMPLOYEE_KEY = emp.EMPLOYEE_KEY
LEFT JOIN (SELECT distinct EMPLOYEE_KEY,EMPLOYEE_ID, MAX(PAYROLL_DATE) as LAST_PAY_DATE 
	FROM DW_PROD.INTEGRATION.FACT_PAYROLL_MERGED where SOURCE_SYSTEM_ID IN (5,6,10) group by 1,2
	 ) tdt ON emp.EMPLOYEE_KEY = tdt.EMPLOYEE_KEY

LEFT OUTER JOIN DW_PROD.INTEGRATION.DIM_BRANCH_MERGED /*@DW_DEV.Stage.AZStage/CSV_Files/REGION_MAPPING (file_format => DW_DEV.PUBLIC.CSV_Format)*/ rmp 
  ON emp.PRIMARY_BRANCH_KEY = TRIM(rmp.BRANCH_KEY) --$4)
LEFT OUTER JOIN  US_STATE zip 
ON TRIM(emp.EMPLOYEE_ZIP) = TRIM(zip.ZIP_CODE) 
LEFT JOIN STATUS  ON STATUS.EMPLOYEE_KEY = EMP.EMPLOYEE_KEY
  LEFT OUTER JOIN DW_PROD.HAH.DIM_SOURCE_SYSTEM ss  on emp.SOURCE_SYSTEM_ID = ss.SOURCE_SYSTEM_ID 
  LEFT OUTER JOIN DISC_EMP_ADDRESS ad on hex_decode_string(emp.employee_PID) = ad.SSN 
   LEFT OUTER JOIN TP_LOCATIONCODE_ERROR ER ON hex_decode_string(emp.employee_PID) = ER.SSN 
    
WHERE employee_classification in ('1','2')  AND emp.SOURCE_SYSTEM_ID IN (5,6,10)   AND (is_active = TRUE /*emp.ACTIVE_EMPLOYEE_FLAG = TRUE*/ or termination_date  >= dateadd(day, -30, current_date) )
--  AND ( UPPER(last_name) Not like '%TEST%' or  UPPER(first_name) Not like '%TEST%')  
  
  )BSI  ;