create or replace view APP_DB_PROD.EQUIFAX.VW_EQUIFAX_EMPLOYEE(
	"EmployeeUniqueIdentifier",
	"ControlledGroupCode",
	"EffectiveDateTime",
	"DataSource",
	"IsInvalid",
	"TransactionType",
	SSN,
	"Status",
	"FirstName",
	"LastName",
	"MiddleName",
	"Suffix",
	"HomeAddressLine1",
	"HomeAddressLine2",
	"HomeAddressCity",
	"HomeAddressState",
	"HomeAddressZIP",
	"HomeAddressCountry",
	"ACAEmployeeDesignationCode",
	"ACAEmployeeCategoryCode",
	"DateOfBirth",
	"UserID",
	"DefaultPIN",
	"AdjustedHireDate",
	"WorkNumberDivision",
	"EmailAddress",
	"PrimaryPhoneNumber"
) as
WITH QA AS(
WITH UNIQUE_PID AS
(   
	SELECT DISTINCT e.SOURCE_SYSTEM_ID, TRIM(HEX_DECODE_STRING(EMPLOYEE_PID)) AS EmployeeUniqueIdentifier,
		   FIRST_VALUE( EMPLOYEE_KEY) IGNORE NULLS OVER( PARTITION BY EMPLOYEE_PID ORDER BY ACTIVE_EMPLOYEE_FLAG DESC NULLS LAST, 
		   NVL( EMPLOYEE_LAST_CHECK_DATE, '1900-01-01') DESC, 
		   NVL( EMPLOYEE_HIRE_DATE, '1900-01-01') DESC, EMPLOYEE_NUMBER) AS EMPLOYEE_KEY
	FROM DW_PROD.INTEGRATION.DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE AS E
--	FROM DW_PROD.HAH.DIM_EMPLOYEE AS E
	WHERE(E.SOURCE_SYSTEM_ID IN (1,2,4,34) 
--	OR (E.SOURCE_SYSTEM_ID IN (5) AND E.WORK_STATE NOT IN ('GA','SC','PA'))
	OR (E.SOURCE_SYSTEM_ID IN (6) AND E.SYSTEM_CODE = 'EXCEL')
	OR (e.SOURCE_SYSTEM_ID IN (22)
			AND (UPPER(TRIM(e.EMPLOYEE_CATEGORY)) IN ('CORP','ADMIN','LPN NURSES','RN NURSES') 
				OR e.JOB_TITLE IN  ('Nurs-Manor', 'Client Services Coordinator', 'Nurs-Comm', 'Nurse-GOLD','Nurse-PDN', 'Nursing')
				OR (E.JOB_TITLE ILIKE ANY('%Nurse%','%NURSE%', 'LPN%', 'RN%', '%LPN', '%RN', 'PTA%', '%PTA', 'PT%', '%PT') OR E.JOB_DESCRIPTION ILIKE ANY('%Nurse%', '%NURSE%', 'LPN%', 'RN%', '%LPN', '%RN', 'PTA%', '%PTA', 'PT%', '%PT')))
			AND (e.ACTIVE_EMPLOYEE_FLAG = TRUE 
				OR ((e.SYSTEM_CODE ILIKE '%EMPEONPREFERRED%' AND e.EMPLOYEE_TERMINATE_DATE >= '11/01/2022'::DATE) 
					OR (e.SYSTEM_CODE ILIKE '%EMPEONEDISON%' AND e.EMPLOYEE_TERMINATE_DATE >= '01/01/2023'::DATE)
					)
				)
		)		
	)
	AND NVL(UPPER(TRIM(E.EMPLOYEE_FIRST_NAME)),'TEST') <> 'TEST' AND NVL(UPPER(TRIM(E.EMPLOYEE_LAST_NAME)),'TEST') <> 'TEST'
	AND NVL(UPPER(TRIM(E.EMPLOYEE_FIRST_NAME)),'PAYSTUB') NOT LIKE '%PAYSTUB%' AND NVL(UPPER(TRIM(E.EMPLOYEE_LAST_NAME)),'PAYSTUB') NOT LIKE '%PAYSTUB%'
),
EFFECTIVE_DATES AS
(
	SELECT DISTINCT UPID.*,
	       NULLIF(E.EMPLOYEE_HIRE_DATE, '1900-01-01') AS EffectiveDateTime_HireDate,
		   NULLIF(E.EMPLOYEE_REHIRE_DATE, '1900-01-01') AS EffectiveDateTime_RehireDate,
		   NULLIF(E.EMPLOYEE_TERMINATE_DATE, '1900-01-01') AS EffectiveDateTime_TermDate,
		   CASE WHEN (EffectiveDateTime_RehireDate < '2020-06-15'::DATE OR EffectiveDateTime_HireDate < '2020-06-15'::DATE)
				AND NVL(EffectiveDateTime_TermDate, CURRENT_DATE()) >= '2020-06-15' THEN 'Y'
				ELSE NULL 
			END AS ACAempCatCode_FLAG
	FROM UNIQUE_PID AS UPID
	LEFT JOIN DW_PROD.INTEGRATION.DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE AS E
		ON UPID.EMPLOYEE_KEY = E.EMPLOYEE_KEY
),
TRANSACTION_TYPE AS (
	(SELECT EmployeeUniqueIdentifier, 
        EMPLOYEE_KEY, 
        EffectiveDateTime_HireDate AS EffectiveDateTime, 
        'HIR' AS TransactionType,
		CASE WHEN EffectiveDateTime_HireDate < '2020-06-15'::DATE THEN 'EC1' 
		     ELSE 'EC2' 
		END AS ACAEmployeeCategoryCode
	FROM EFFECTIVE_DATES 
	WHERE EffectiveDateTime_HireDate IS NOT NULL AND EffectiveDateTime_HireDate < CURRENT_DATE()) 
	UNION ALL 	
	(SELECT EmployeeUniqueIdentifier, 
        EMPLOYEE_KEY, 
        EffectiveDateTime_REhireDate AS EffectiveDateTime, 
        'RHR' AS TransactionType,
		CASE WHEN NVL( EffectiveDateTime_RehireDate,'2020-06-15') < '2020-06-15'::DATE THEN 'EC1' 
		     ELSE 'EC2' 
		END AS ACAEmployeeCategoryCode
	FROM EFFECTIVE_DATES 
	WHERE EffectiveDateTime_RehireDate IS NOT NULL AND EffectiveDateTime_RehireDate < CURRENT_DATE()
	 	AND DATEADD( DAY, 1, EffectiveDateTime_TermDate::DATE) < EffectiveDateTime_RehireDate AND EffectiveDateTime_TermDate IS NOT NULL) 
	UNION ALL
	(SELECT EmployeeUniqueIdentifier, 
        EMPLOYEE_KEY, 
        DATEADD( DAY, 1, EffectiveDateTime_TermDate::DATE) AS EffectiveDateTime, 
        'TER' AS TransactionType,
		CASE WHEN EffectiveDateTime_TermDate < '2020-06-15'::DATE THEN 'EC1' 
		     ELSE 'EC2' 
		END AS ACAEmployeeCategoryCode
	FROM EFFECTIVE_DATES 
	WHERE EffectiveDateTime_TermDate IS NOT NULL AND EffectiveDateTime_TermDate < CURRENT_DATE()) 
	UNION ALL
	(SELECT EmployeeUniqueIdentifier, 
        EMPLOYEE_KEY, 
        '2020-06-15'::DATE AS EffectiveDateTime, 
        'JOB' AS TransactionType,
		'EC2' AS ACAEmployeeCategoryCode
	FROM EFFECTIVE_DATES 
	WHERE EffectiveDateTime_HireDate < '2020-06-15'::DATE
		AND (EffectiveDateTime_TermDate > '2020-06-15'::DATE OR NULLIF( EffectiveDateTime_TermDate, '1900-01-01') IS NULL)
		AND (NULLIF( EffectiveDateTime_RehireDate,'1900-01-01') IS NULL OR EffectiveDateTime_RehireDate <> '2020-06-15'::DATE))
),
PAYROLL_DATES AS
(   
	SELECT SOURCE_SYSTEM_ID, 
		   TRIM( SYSTEM_CODE) AS SYSTEM_CODE, 
		   TRIM( EMPLOYEE_ID) AS EMPLOYEE_ID,
		   NVL( MIN( PAYROLL_DATE), 
		   MIN( PAY_PERIOD_END_DATE)) AS FIRST_PAYROLL_DATE
	FROM DW_PROD.INTEGRATION.FACT_PAYROLL_MERGED
	WHERE SOURCE_SYSTEM_ID IN (1,2,4,5,22,34) OR (SOURCE_SYSTEM_ID = 6 AND SYSTEM_CODE = 'EXCEL')
	GROUP BY 1,2,3
),
CORP_ADDRESS AS 
(
	SELECT DISTINCT REGEXP_REPLACE(UPPER(LEFT(NULLIF(TRIM(OFFICE_ADDRESS1),''), 75)), '\\,|', '') AS EMPLOYEE_ADDRESS1,
					REGEXP_REPLACE(UPPER(LEFT(NULLIF(TRIM(OFFICE_ADDRESS2),''), 75)), '\\,|', '') AS EMPLOYEE_ADDRESS2,
					REGEXP_REPLACE(UPPER(LEFT(NULLIF(TRIM(OFFICE_CITY),''), 40)), '\\,|', '') AS EMPLOYEE_CITY,
					REGEXP_REPLACE(UPPER(LEFT(NULLIF(TRIM(OFFICE_STATE_CODE),''), 2)), '\\,|', '') AS EMPLOYEE_STATE_CODE,
					REGEXP_REPLACE(UPPER(LEFT(NULLIF(TRIM(OFFICE_ZIP),''), 5)), '\\,|', '') AS EMPLOYEE_ZIP
	FROM DW_PROD.HAH.DIM_BRANCH WHERE OFFICE_NUMBER = '0'
)
SELECT DISTINCT ED.EmployeeUniqueIdentifier AS EmployeeUniqueIdentifier,
	   'CG1' AS ControlledGroupCode,
	   TT.TransactionType AS TransactionType,
--	   	CASE WHEN TransactionType = 'HIR' AND (EffectiveDateTime IS NULL OR EffectiveDateTime > PD.FIRST_PAYROLL_DATE)
--			 THEN PD.FIRST_PAYROLL_DATE			-- Making sure hire isn't after first payroll
--			 ELSE EffectiveDateTime 
--	   END AS EffectiveDateTime, -- Remaining
--	   CASE WHEN TRIM(E.SYSTEM_CODE) ILIKE '%EMPEONPREFERRED%' THEN  '11/01/2022'	 
	   CASE WHEN TransactionType = 'HIR' AND (EffectiveDateTime IS NULL OR EffectiveDateTime > PD.FIRST_PAYROLL_DATE) THEN PD.FIRST_PAYROLL_DATE	
 	 		ELSE EffectiveDateTime 
		END AS EffectiveDateTime,
	   CASE WHEN TRIM(E.SYSTEM_CODE) = '8485' THEN 'EXCEL'
	        WHEN TRIM(E.SYSTEM_CODE) ILIKE ANY('%EMPEONEDISON%','%EMPEONPREFERRED%') THEN REPLACE(SPLIT_PART(E.SYSTEM_CODE, '-', 0), 'EMPEON', '')
	        ELSE TRIM(E.SYSTEM_CODE)
	   END AS DataSource,
	   'No' AS IsInvalid,
	   HEX_DECODE_STRING(E.EMPLOYEE_PID) AS SSN, 
	   CASE WHEN E.ACTIVE_EMPLOYEE_FLAG = TRUE THEN 'A'
	   		ELSE 'T'
	   END AS Status,
	   TRIM(UPPER(E.EMPLOYEE_FIRST_NAME)) AS FirstName,
	   TRIM(UPPER(E.EMPLOYEE_MIDDLE_NAME)) AS MiddleName,
	   TRIM(UPPER(E.EMPLOYEE_LAST_NAME)) AS LastName,
	   TRIM(UPPER(E.EMPLOYEE_SUFFIX)) AS Suffix,
	   COALESCE(TRIM(UPPER(E.EMPLOYEE_ADDRESS1)), TRIM(UPPER(CA.EMPLOYEE_ADDRESS1))) AS HomeAddressLine1,
	   TRIM(UPPER(E.EMPLOYEE_ADDRESS2)) AS HomeAddressLine2,
	   COALESCE(TRIM(UPPER(E.EMPLOYEE_CITY)), TRIM(UPPER(CA.EMPLOYEE_CITY))) AS HomeAddressCity,
	   COALESCE(TRIM(UPPER(E.EMPLOYEE_STATE_CODE)), TRIM(UPPER(CA.EMPLOYEE_STATE_CODE))) AS HomeAddressState,
	   COALESCE(TRIM(E.EMPLOYEE_ZIP), TRIM(CA.EMPLOYEE_ZIP)) AS HomeAddressZip,
	   'US' AS Country,
	   CASE WHEN UPPER(e.EMPLOYEE_CATEGORY) = 'FIELD' THEN 'V'
	   		ELSE 'FT'
	   END AS ACAEmployeeDesignationCode,
	   TT.ACAEmployeeCategoryCode AS ACAEmployeeCategoryCode,
	   COALESCE(E.EMPLOYEE_DOB, '1970-01-01') AS DateOfBirth,
	   ED.EmployeeUniqueIdentifier AS UserID,
--	   RIGHT('0000000' || ROW_NUMBER() OVER (ORDER BY ED.EmployeeUniqueIdentifier), 8)::VARCHAR AS DefaultPIN,
	   NULL AS AdjustedHireDate,
	   NULL AS WorkNumberDivision,
--	   COALESCE(NULLIF(E.EMPLOYEE_WORK_EMAIL, ''), NULLIF(E.EMPLOYEE_PERSONAL_EMAIL, '')) AS EmailAddress,
--	   CASE WHEN COALESCE(NULLIF(E.EMPLOYEE_WORK_EMAIL,''), NULLIF(E.EMPLOYEE_PERSONAL_EMAIL,'')) NOT LIKE '%@%' THEN NULL
--			 ELSE COALESCE(NULLIF(E.EMPLOYEE_WORK_EMAIL,''), NULLIF(E.EMPLOYEE_PERSONAL_EMAIL,''))
--		END AS EmailAddress,
	   CASE WHEN LENGTH(SPLIT_PART(COALESCE(NULLIF(E.EMPLOYEE_WORK_EMAIL,''), NULLIF(E.EMPLOYEE_PERSONAL_EMAIL,'')), '@', 0)) < 2  OR COALESCE(NULLIF(E.EMPLOYEE_WORK_EMAIL,''), NULLIF(E.EMPLOYEE_PERSONAL_EMAIL,'')) NOT LIKE '%@%' THEN UPPER('invalid@invalid.com')
			ELSE REPLACE(TRIM(UPPER(COALESCE(COALESCE(NULLIF(E.EMPLOYEE_WORK_EMAIL,''), NULLIF(E.EMPLOYEE_PERSONAL_EMAIL,'')), NULLIF( s.$6,''), 'invalid@invalid.com'))),' ','')
	   END AS EmailAddress,
--	   COALESCE(E.EMPLOYEE_WORK_PHONE, E.EMPLOYEE_HOME_PHONE) AS PrimaryPhoneNumer
--	   COALESCE(
--		 NULLIF(NULLIF(REPLACE(REPLACE(REGEXP_REPLACE(TRIM(E.EMPLOYEE_WORK_PHONE), '\\-|\\)|\\(|',''),' ',''),'O','0'), '0000000000'), ''),
--		 NULLIF(NULLIF(REPLACE(REPLACE(REGEXP_REPLACE(TRIM(E.EMPLOYEE_HOME_PHONE), '\\-|\\)|\\(|',''),' ',''),'O','0'), '0000000000'), '')
--		 ) AS PrimaryPhoneNumber
	   NULLIF(NULLIF(REPLACE(REPLACE(REGEXP_REPLACE(
			CASE WHEN LEN(COALESCE(E.EMPLOYEE_WORK_PHONE, E.EMPLOYEE_HOME_PHONE)) <> 10 THEN '5555555555'
		 		 WHEN DQPN.PHONE_NUMBER IS NOT NULL THEN '5555555555'
		  		 WHEN LEFT(COALESCE(E.EMPLOYEE_WORK_PHONE, E.EMPLOYEE_HOME_PHONE), 1) = '0' OR LEFT(COALESCE(E.EMPLOYEE_WORK_PHONE, E.EMPLOYEE_HOME_PHONE), 3) = '000' THEN '5555555555'
		 		 ELSE COALESCE(NULLIF(COALESCE(E.EMPLOYEE_WORK_PHONE, E.EMPLOYEE_HOME_PHONE), '0'), '5555555555')
			END , '\\-|\\)|\\(|',''),' ',''),'O','0'), '0000000000'), '') AS PrimaryPhoneNumber
FROM EFFECTIVE_DATES AS ED
LEFT JOIN DW_PROD.INTEGRATION.DIM_EMPLOYEE_PAYROLL_MERGE_DEDUPE AS E
	ON ED.EMPLOYEE_KEY = E.EMPLOYEE_KEY 
LEFT JOIN CORP_ADDRESS AS CA
	ON NULLIF(e.EMPLOYEE_ADDRESS1,'') IS NULL OR /*NULLIF(e.EMPLOYEE_ADDRESS2,'') IS NULL OR*/ NULLIF(e.EMPLOYEE_CITY,'') IS NULL OR NULLIF(e.EMPLOYEE_STATE_CODE,'') IS NULL OR NULLIF(e.EMPLOYEE_ZIP,'') IS NULL
LEFT JOIN TRANSACTION_TYPE AS TT 
	ON ED.EMPLOYEE_KEY = TT.EMPLOYEE_KEY
LEFT JOIN PAYROLL_DATES AS PD
		ON E.SOURCE_SYSTEM_ID = PD.SOURCE_SYSTEM_ID AND TRIM(E.SYSTEM_CODE) = PD.SYSTEM_CODE AND TRIM(E.EMPLOYEE_ID) = PD.EMPLOYEE_ID
LEFT OUTER JOIN (SELECT s.$3, s.$6 FROM @DW_PROD.Stage.AZStage/CSV_Files/HAH_Emails_SISCO_20201006 (file_format => DW_PROD.PUBLIC.CSV_Format) s
				 WHERE s.$6 IS NOT NULL AND s.$6 NOT LIKE '%\\_@%' ESCAPE '\\') s
	ON HEX_DECODE_STRING(E.EMPLOYEE_PID) = TRIM(s.$3)
LEFT OUTER JOIN DATA_MANAGEMENT.DATA_QUALITY.INVALID_SSN DQSSN
	ON HEX_DECODE_STRING(E.EMPLOYEE_PID) = DQSSN.SSN
LEFT OUTER JOIN DATA_MANAGEMENT.DATA_QUALITY.INVALID_PHONE_NUMBER DQPN
	ON COALESCE(E.EMPLOYEE_WORK_PHONE,E.EMPLOYEE_HOME_PHONE) = DQPN.PHONE_NUMBER
WHERE (LastName IS NOT NULL OR FirstName IS NOT NULL)
	AND TRIM(HEX_DECODE_STRING(E.EMPLOYEE_PID)) NOT IN ('000000000','123456789')
	AND DQSSN.SSN IS NULL
)SELECT 
EmployeeUniqueIdentifier AS"EmployeeUniqueIdentifier",
	ControlledGroupCode AS "ControlledGroupCode",
		CASE WHEN DataSource = 'PREFERRED' THEN  '11/01/2022'
			 WHEN DataSource = 'EDISON' THEN '01/01/2023'
			 WHEN DataSource IN ('HH8','PLU','PN5') THEN '07/01/2023'
			 ELSE EffectiveDateTime 
		END AS "EffectiveDateTime",
	DataSource AS "DataSource",
	IsInvalid AS "IsInvalid",
	TransactionType AS "TransactionType",
	SSN AS "SSN",
	Status AS "Status",
	FirstName AS "FirstName",
	LastName AS "LastName",
	MiddleName AS "MiddleName",
	Suffix AS "Suffix",
	HomeAddressLine1 AS "HomeAddressLine1",
	HomeAddressLine2 AS "HomeAddressLine2",
	HomeAddressCity AS "HomeAddressCity",
	HomeAddressState AS "HomeAddressState",
	HomeAddressZip AS "HomeAddressZIP",
	Country AS "HomeAddressCountry",
	ACAEmployeeDesignationCode AS "ACAEmployeeDesignationCode",
	ACAEmployeeCategoryCode AS "ACAEmployeeCategoryCode",
	DateOfBirth AS "DateOfBirth",
	UserID AS "UserID",
	RIGHT( '0000000'||ROW_NUMBER() OVER( ORDER BY EmployeeUniqueIdentifier), 8)::VARCHAR AS "DefaultPIN",
	AdjustedHireDate AS "AdjustedHireDate",
	WorkNumberDivision AS "WorkNumberDivision",
	EmailAddress AS "EmailAddress",
	PrimaryPhoneNumber AS "PrimaryPhoneNumber"
FROM QA;