create or replace view APP_DB_PROD.BROADSPIRE.VW_BSI_ERROR_STATUS(
	"Comment",
	SSN,
	"First Name",
	"Last Name",
	"Source System",
	"System Name",
	"Job Title",
	"Current Error Date",
	"First Error Date",
	"Error status"
) as

with errorData as (
SELECT 
    "Comment",
    "File Run Date",
    "Source System",
    "System Name",
    "Last Name",
    "First Name",
    "Social Security Number" as SSN,
    "Employee ID" as "Broadspire EEId",
    "Job Title",
    "Termination Date",
    RANK() OVER (
    PARTITION BY "Social Security Number","Comment"
        ORDER BY "File Run Date" desc
    ) as RANK
FROM   APP_DB_PROD.BROADSPIRE.TBL_BROADSPIRE_BADDATA 


  )
  
select "Comment",SSN, "First Name","Last Name", "Source System","System Name","Job Title",MAX("File Run Date") as "Current Error Date",--MAX(RANK),DATEADD( DAY, -6, CURRENT_DATE()),
MIN("File Run Date") as "First Error Date",
Case when MAX("File Run Date") BETWEEN DATEADD( DAY, -6, CURRENT_DATE()) AND CURRENT_DATE() AND MAX(RANK)>1 THEN 'OLD ERROR-Not Resolved'
 when MAX("File Run Date") <= DATEADD( DAY, -7, CURRENT_DATE())  AND MAX(RANK) >= 1 THEN 'RESOLVED'

else 'NEW ERROR-Not Resolved' END as "Error status"
from errorData

group by 1,2,3,4,5,6,7 order by MAX("File Run Date") desc,SSN;